// Autor: Lukáš Gronich - xgronil00
#ifndef SYMTABLE_H
#define SYMTABLE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tree.h"

// Typy symbolů
typedef enum
{
    VAR,
    CONST,
    FUNC
} SymbolType;

// Struktura parametru
typedef struct Parameter
{
    char *id;
    TYPE dataType;
    struct Parameter *next;
} Parameter;

// Struktura symbolu
typedef struct Symbol
{
    char *id;
    SymbolType type;
    TYPE dataType;
    Parameter *parameters;
    bool used;
    bool changed;
    bool ret;
    unsigned int symbol_scope_cnt;
} Symbol;

// Struktura tabulky symbolů
typedef struct AVLNode
{
    Symbol *symbol;
    struct AVLNode *left;
    struct AVLNode *right;
    int height;
} AVLNode;

// Struktura scopů, pro rozsahy proměnných
typedef struct ScopeNode
{
    AVLNode *symbolTree;
    struct ScopeNode *next;
    unsigned int scope_cnt;
} ScopeNode;

int max(int a, int b);                                                          // Funkce pro vrácení větší hodnoty, využívá se pro vyváženost stromu
int height(AVLNode *node);                                                      // Funkce pro vrácení výšky uzlu
AVLNode *createAVLNode(Symbol *symbol);                                         // Funkce pro vytvoření uzlu stromu
AVLNode *rightRotate(AVLNode *y);                                               // Pravá rotace
AVLNode *leftRotate(AVLNode *x);                                                // Levá rotace
int getBalance(AVLNode *node);                                                  // Funkce pro vrácení vyváženosti stromu
AVLNode *insert(AVLNode *node, Symbol *symbol);                                 // Funkce pro vložení uzlu do stromu
Symbol *find(AVLNode *node, const char *id);                                    // Funkce pro hledání symbolu v tabulce symbolů
Parameter *findParameter(Parameter *param, const char *name);                   // Funkce pro hledání parametru v tabulce symbolů
Symbol *createSymbol(const char *id, SymbolType type, TYPE dataType);           // Funkce pro vytvoření uzlu symbolu
void addParameter(Symbol *funcSymbol, const char *paramid, TYPE paramDataType); // Funkce pro přidání parametru do tabulky symbolů
void printParameters(Parameter *param);                                         // Funkce pro vytisknutí parametů
void printSymbol(Symbol *symbol);                                               // Funkce pro vytisknutí symbolu
void insertToCurrentScope(Symbol *symbol, ScopeNode *scopeStack);               // Funkce pro vložení symbolu do danného scopu
ScopeNode *pushScope(ScopeNode *scopeStack);                                    // Funkce pro přidání scopu do zásobníku
ScopeNode *popScope(ScopeNode *scopeStack);                                     // Funkce pro oddělání scopu ze zásobníku
Symbol *findInScopes(const char *name, ScopeNode *scopeStack);                  // Funkce pro hledání symbolu podle id v danném scopu
void printSymbolTree(AVLNode *node, int level);                                 // Funkce pro vytisknutí tabulky symbolů
void printScopes(ScopeNode *scope);                                             // Funkce pro vytisknutí scopů

#endif // SYMTABLE_H