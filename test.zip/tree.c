// Autor: Lukáš Gronich - xgronil00
#include "tree.h"
#include <stdio.h>
#include <stdlib.h>
#include "sem_analysis.h"

Node *createNode(NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    return node;
}

Node *createFunctionNode(char *id, TYPE return_type, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.function.id = id;
    node->data.function.return_type = return_type;
    node->data.function.params = NULL;
    return node;
}

Node *createParameterNode(char *id, TYPE type, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.parameter.id = id;
    node->data.parameter.type = type;
    return node;
}

Node *createVarDeclarationNode(char *id, TYPE type, Node *expression, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.varDecl.id = id;
    node->data.varDecl.type = type;

    node->children = expression;
    return node;
}

Node *createVarInitializationNode(char *id, TYPE type, Node *expression, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.varDecl.id = id;
    node->data.varDecl.type = type;

    node->data.varDecl.expression = expression;
    return node;
}

Node *createExpressionNode(OPERATOR_TYPE operator, Node * leftOperand, Node *rightOperand, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.expressionNode.operator= operator;
    node->children = leftOperand;

    if (leftOperand != NULL) // Pokud levý operad není prázdný, jeho sourozenec bude pravý operand
    {
        leftOperand->sibling = rightOperand;
    }

    return node;
}

Node *createIfNode(Node *condition, Node *exp_more, char *id_more, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    static unsigned int cnt = -1; // Nastavení statického counteru na -1, aby počítaní začalo od 0
    cnt++;                        // Counter slouží k zanořenosti

    node->data.ifNode.condition = condition;
    node->data.ifNode.exp_null = exp_more;
    node->data.ifNode.id_null = id_more;
    node->data.ifNode.cnt = cnt;
    return node;
}

Node *createIfBodyNode(NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    static unsigned int cnt = -1; // Nastavení statického counteru na -1, aby počítaní začalo od 0
    cnt++;                        // Counter slouží k zanořenosti
    node->data.ifBody.cnt = cnt;
    return node;
}

Node *createElseBodyNode(NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.elseBody.cnt = 0; // Counter se řeší až později v programu
    return node;
}

// Function to create a new while node
Node *createWhileNode(Node *condition, Node *exp_more, char *id_more, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    static unsigned int cnt = -1; // Nastavení statického counteru na -1, aby počítaní začalo od 0
    cnt++;                        // Counter slouží k zanořenosti
    node->data.whileNode.cnt = cnt;

    node->data.whileNode.condition = condition;
    node->data.whileNode.exp_null = exp_more;
    node->data.whileNode.id_null = id_more;
    return node;
}

// Function to create a new return node
Node *createReturnNode(NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;
    node->data.returnNode.expression = NULL;
    return node;
}

// Function to create a new call node
Node *createCallNode(char *id, bool buildin, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.callNode.id = id;
    node->data.callNode.isBuildin = buildin;
    node->data.callNode.args = NULL;
    return node;
}

// Function to create a new condition node
Node *createConditionNode(Node *leftExpression, OPERATOR_TYPE operator, Node * rightExpression, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.conditionNode.leftExpression = leftExpression;
    node->data.conditionNode.operator= operator;
    node->data.conditionNode.rightExpression = rightExpression;
    return node;
}

// Function to create a new factor node
Node *createFactorNode(char *id, int i32, double f64, char *u8, TYPE factorType, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    // Inicializace dat
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.factorNode.id = id;
    node->data.factorNode.factorType = factorType;
    if (factorType == TYPE_I32)
    {
        node->data.factorNode.value.i32 = i32;
    }
    else if (factorType == TYPE_F64)
    {
        node->data.factorNode.value.f64 = f64;
    }
    else if (factorType == TYPE_U8)
    {
        node->data.factorNode.value.u8 = strdup(u8);
    }
    return node;
}

bool InsertNode(Node *parent, Node *child)
{
    if (!parent || !child)
    {
        return false;
    }

    if (!parent->children)
    {
        // Pokud rodič ještě nemá dítě, vložíme uzel jako dítě rodiče
        parent->children = child;
    }
    else
    {
        // Pokud rodič už dítě má, vložíme ulez na konec seznamu dětí jako sourozenec posledního dítěte
        Node *current = parent->children;
        while (current->sibling)
        {
            current = current->sibling;
        }
        current->sibling = child;
    }

    return true;
}

bool InsertParamNode(Node *function, Node *param)
{
    if (!function || function->type != NODE_FUNCTION || !param || param->type != NODE_PARAMETER)
    {
        return false;
    }

    if (!function->data.function.params)
    {
        // Pokud funkce ještě nemá parametr, vložíme uzel do parametru
        function->data.function.params = param;
    }
    else
    {
        // Pokud funkce už parametry má, vložíme ulez na konec seznamu parametrů jako sourozenec posledního parametru
        Node *current = function->data.function.params;
        while (current->sibling)
        {
            current = current->sibling;
        }
        current->sibling = param;
    }

    return true;
}

bool InsertCallArgument(Node *callNode, Node *arg)
{
    if (!callNode || callNode->type != NODE_CALL || !arg)
    {
        return false;
    }

    if (!callNode->data.callNode.args)
    {
        // Pokud volání funkce ještě nemá argument, vložíme uzel do argumentu
        callNode->data.callNode.args = arg;
    }
    else
    {
        // Pokud volání funkce už argumenty má, vložíme ulez na konec seznamu argumentů jako sourozenec posledního argumentu
        Node *current = callNode->data.callNode.args;
        while (current->sibling)
        {
            current = current->sibling;
        }
        current->sibling = arg;
    }

    return true;
}
