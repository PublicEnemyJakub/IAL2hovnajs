#include "lex_analysis.h"
#include "tree.h"
#include "sem_analysis.h"
#include <stdbool.h>

#define STACK_MAX_SIZE 500

// Funkce pro LL rekurzi, kopírují LL pravidla
void advance();
void unexpToken();
void match(TokenType expected, KeyType expected2);
void matchKey(KeyType expected);
bool check(TokenType expected, KeyType expected2);
bool checkKey(KeyType expected);
void parse_prolog();
void parse_code();
void parse_f_def();
void parse_params_in();
void parse_param();
void parse_next_params();
void parse_type();
void parse_next_param();
void parse_ret_type();
void parse_line();
void parse_var_dec();
void parse_re_type();
void parse_expression();
void parse_precedence_expression();
void parse_ifj_call();
void parse_fac_call();
void parse_param_send();
void parse_next_send();
void parse_call();
void parse_if();
void parse_while();
void parse_return();
void parse_condition();

// Typ symbolu podle precedenční tabulky
typedef enum
{
    VALUE,      // i
    PLUS,       // +
    MINUS,      // -
    MULTIPLY,   // *
    DIVIDE,     // /
    LPAREN,     // (
    RPAREN,     // )
    DOLLAR,     // $ imaginární token konce a začátku
    ALL_SYMBOLS // Počet symbolů (pro indexování)
} SymbolType;

// Ruzny hodnoty i at vim typ
typedef enum
{
    INT,
    FLOAT,
    ID,
} ValueType;

// Jeden symbol zasobniku
typedef struct
{
    SymbolType type;
    union
    {
        int int_value;
        double float_value;
        char *id_value;
    };
    bool stop;
    bool skip;
    ValueType val_type;
} StackSymbol;

// Precedence
typedef enum
{
    EQUAL,
    LESS,
    GREATER,
    INVALID,
} Precedence;

// Upravená precedenční tabulka
Precedence precedenceTable[ALL_SYMBOLS][ALL_SYMBOLS] = {
    ////////////     i        +         -         *         /         (         )         $   /////////////////////////
    /* i      */ {INVALID, GREATER, GREATER, GREATER, GREATER, INVALID, GREATER, GREATER},
    /* +      */ {LESS, GREATER, GREATER, LESS, LESS, LESS, GREATER, GREATER},
    /* -      */ {LESS, GREATER, GREATER, LESS, LESS, LESS, GREATER, GREATER},
    /* *      */ {LESS, GREATER, GREATER, GREATER, GREATER, LESS, GREATER, GREATER},
    /* /      */ {LESS, GREATER, GREATER, GREATER, GREATER, LESS, GREATER, GREATER},
    /* (      */ {LESS, LESS, LESS, LESS, LESS, LESS, EQUAL, INVALID},
    /* )      */ {INVALID, GREATER, GREATER, GREATER, GREATER, INVALID, GREATER, GREATER},
    /* $      */ {LESS, LESS, LESS, LESS, LESS, LESS, INVALID, EQUAL}};

Precedence checkPrecedence(SymbolType row, SymbolType column);
// Zasobnik pro precedenci a funkce pro operaci s nim
typedef struct
{
    Node *nodes[STACK_MAX_SIZE];
    int latest;
} Current_StateStack;

typedef struct
{
    StackSymbol data[STACK_MAX_SIZE];
    int top;
} PrecedenceStack;

void stack_init(PrecedenceStack *stack);
int stack_is_empty(PrecedenceStack *stack);
int stack_is_full(PrecedenceStack *stack);
void stack_push(PrecedenceStack *stack, StackSymbol symbol);
StackSymbol stack_pop(PrecedenceStack *stack);
SymbolType stack_get_first_symbol(PrecedenceStack *stack);
StackSymbol stack_top(PrecedenceStack *stack);
void print_stack(PrecedenceStack *stack);
// Zasobnik zanorenosti/kam nahravat potomky u AST
void StateStack_init();
void StateStack_pop();
void StateStack_push(Node *node);
void AutoInsertNode(Node *node);
void swap_tokens();