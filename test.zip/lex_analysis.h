
/*
Lexikalni analyzator
Autor: Jakub Smička (xsmickj00)

*/

typedef enum
{
    KEY_IF,
    KEY_ELSE,
    KEY_WHILE,
    KEY_RETURN,
    KEY_CONST,
    KEY_VAR,
    KEY_FN,
    KEY_I32,
    KEY_F64,
    KEY_NULL,
    KEY_PUB,
    KEY_U8,
    KEY_VOID,
    KEY_IFJ,
    KEY_IMPORT,
    NOT_KEY,
} KeyType;

typedef enum
{
    // Klíčová slova
    TOKEN_KEY,
    // Identifikátory
    TOKEN_IDENTIFIER,
    // Literály
    TOKEN_INTEGER,
    TOKEN_FLOAT,
    TOKEN_STRING,
    // Operátory
    TOKEN_PLUS,          // +
    TOKEN_MINUS,         // -
    TOKEN_STAR,          // *
    TOKEN_SLASH,         // /
    TOKEN_EQUAL,         // =
    TOKEN_NOT_EQUAL,     // !=
    TOKEN_LESS,          // <
    TOKEN_GREATER,       // >
    TOKEN_LESS_EQUAL,    // <=
    TOKEN_GREATER_EQUAL, // >=
    TOKEN_NOT,           // !
    TOKEN_DOUBLE_EQUAL,  // ==
                         // Oddělovače
    TOKEN_LEFT_PAREN,    // (
    TOKEN_RIGHT_PAREN,   // )
    TOKEN_LEFT_BRACE,    // {
    TOKEN_RIGHT_BRACE,   // }
    TOKEN_LEFT_BRACKET,  // [
    TOKEN_RIGHT_BRACKET, // ]
    TOKEN_VERTICAL_BAR,  // |
    TOKEN_COMMA,         // ,
    TOKEN_DOT,           // .
    TOKEN_DOUBLE_DOT,    // :
    TOKEN_SEMICOLON,     // ;
    TOKEN_AT,            // @
    TOKEN_QMARK,         // ?
                         // Konec souboru
    TOKEN_EOF,
} TokenType;

typedef struct
{
    TokenType type; // Typ tokenu
    union
    {
        int int_value;      // Pro celá čísla
        double float_value; // Pro desetinná čísla
        char *value;        // Hodnota tokenu jako řetězec (pro identifikátory, řetězce atd.)
        KeyType key_value;  // Typ klíčového slova
    };
} Token;

Token *getToken();
