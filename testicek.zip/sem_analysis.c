/*
Autoři:
Jakub Smička - xsmickj00
Lukáš Gronich - xgronil00
Ondřej Šustr - xsustro00

Na tomto souboru se podíleli všichni. Každý u své "velké" funkce napsal svůj login,
aby šlo rozeznat, kdo dělal co
----------------------------------------------
Tento soubor dělá sematickou analýzu a volá konkrétní funkce pro pro generování výsledného kódu
podle průchodu AST, který obdrží

*/
#include <stdio.h>
#include "dynamic_string.h"
#include "generator.h"
#include "sem_analysis.h"
#include "tree.h"
#include "symtable.h"
#include "semantic.h"
#include "math.h"

// Pomocné proměnné
bool null_condtition = false;
char *filename = "output.ifjcode"; // Používali jsme pro výstup do souboru místo stdout při implemetaci projektu
TYPE ltst_type;
ScopeNode *scopeStackGlobal = NULL;
ScopeNode *scopeStackLocal = NULL;
Node *top_while = NULL;

/*
Speciální pomocná funkce, která se zavolá pouze, pokud se ve stromu prochází smyčka while
pokud se někde v těle deklaruje proměnná, tak to musí ve výsledném kódu být vegenerováno před návěstím while smyčky,
jiank by se deklarovaly znova a došlo by k chybě interpretu výsledného kódu.
Funkce projde celé tělo while a vygeneruje všechny deklarované a potřebné proměnné předem, samozřejmě se správným scopem
a také kontroluje, zda proměnná náhodou již neexistuje.

Autor: Jakub Smička - xsmickj00
*/
void ast_gen_vars(Node *node)
{
    if (!node)
    {
        return;
    }
    switch (node->type)
    {
    case NODE_VARIABLE_DECLARATION:
        if (strcmp(node->data.varDecl.id, "_") == 0)
        {
            fprintf(stderr, "Promenna s identifikatorem _ se nedeklaruje!\n");
            exit(5);
        }
        Symbol *symbol = findInScopes(node->data.varDecl.id, scopeStackLocal); // Kontrola existence
        if (symbol == NULL)
        {
            Symbol *localVar;
            if (node->data.varDecl.var_type == VAR_TYPE)
            {
                localVar = createSymbol(node->data.varDecl.id, VAR, TYPE_NONE);
            }
            else
            {
                localVar = createSymbol(node->data.varDecl.id, CONST, TYPE_NONE);
            }
            insertToCurrentScope(localVar, scopeStackLocal);
            gen_local_var_def(node->data.varDecl.id, localVar->symbol_scope_cnt);
        }
        else
        {
            fprintf(stderr, "Promenna %s jiz existuje!\n", node->data.varDecl.id);
            exit(5);
        }
        break;
    case NODE_IF:
        scopeStackLocal = pushScope(scopeStackLocal); // Musime pushnout scope i když zde jen definujeme proměnné předem, abychom neztatili jejich scope
        if (node->data.ifNode.id_null)
        {
            Symbol *id_null = createSymbol(node->data.ifNode.id_null, CONST, TYPE_NONE);
            insertToCurrentScope(id_null, scopeStackLocal);
            gen_null_var(node->data.ifNode.id_null, id_null->symbol_scope_cnt);
            gen_if_tmp(node->data.whileNode.cnt);
        }
        break;
    case NODE_ELSE_BODY:
        scopeStackLocal = pushScope(scopeStackLocal); // To samé jako u if
        break;
    case NODE_WHILE:
        if (node != top_while)
        {
            scopeStackLocal = pushScope(scopeStackLocal);
        }
        if (node->data.whileNode.id_null)
        {
            Symbol *id_null = createSymbol(node->data.whileNode.id_null, CONST, TYPE_NONE); // vytvoření proměnné id_beznull
            insertToCurrentScope(id_null, scopeStackLocal);
            gen_null_var(node->data.whileNode.id_null, id_null->symbol_scope_cnt);
            gen_while_tmp(node->data.whileNode.cnt); // Vytvoření pomocné proměnné pro vyhodnocení condition
        }
        break;
    default:
        break;
    }
    Node *child = node->children;
    while (child)
    {
        ast_gen_vars(child);
        child = child->sibling;
    }
    switch (node->type) // Predpripraveno, pokud by byla potreba delat neco se scopy
    {
    case NODE_IF_BODY:
        break;
    case NODE_ELSE_BODY:
        break;
    case NODE_WHILE:
        break;
    default:
        break;
    }
}

/*
Pomocná funkce, aby se do seznamu všech definovaných funkcí nahrály také vestavěné pro kontrolu jejich správného volání
Funkce kopírují nahrávání jako ty definované uživatelem, jen vše víme rovnou ze zadání, takže se vše rovnou udělá a nahraje.
Autor: Jakub Smička - xsmickj00
*/
void pushBuiltin()
{
    pushScope(scopeStackGlobal);
    Symbol *builtin = createSymbol(strdup("$$ifj_readstr"), FUNC, TYPE_U8_NULL);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_readi32"), FUNC, TYPE_I32_NULL);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_readf64"), FUNC, TYPE_F64_NULL);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_write"), FUNC, TYPE_VOID);
    addParameter(builtin, strdup("term"), TYPE_NONE);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_i2f"), FUNC, TYPE_F64);
    addParameter(builtin, strdup("term"), TYPE_I32);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_f2i"), FUNC, TYPE_I32);
    addParameter(builtin, strdup("term"), TYPE_F64);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_string"), FUNC, TYPE_U8);
    addParameter(builtin, strdup("term"), TYPE_NONE);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_length"), FUNC, TYPE_I32);
    addParameter(builtin, strdup("s"), TYPE_U8);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_concat"), FUNC, TYPE_U8);
    addParameter(builtin, strdup("s1"), TYPE_U8);
    addParameter(builtin, strdup("s2"), TYPE_U8);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_substring"), FUNC, TYPE_U8_NULL);
    addParameter(builtin, strdup("s"), TYPE_U8);
    addParameter(builtin, strdup("i"), TYPE_I32);
    addParameter(builtin, strdup("j"), TYPE_I32);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_strcmp"), FUNC, TYPE_I32);
    addParameter(builtin, strdup("s1"), TYPE_U8);
    addParameter(builtin, strdup("s2"), TYPE_U8);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_ord"), FUNC, TYPE_I32);
    addParameter(builtin, strdup("s"), TYPE_U8);
    addParameter(builtin, strdup("i"), TYPE_I32);
    insertToCurrentScope(builtin, scopeStackGlobal);

    pushScope(scopeStackGlobal);
    builtin = createSymbol(strdup("$$ifj_chr"), FUNC, TYPE_U8);
    addParameter(builtin, strdup("i"), TYPE_I32);
    insertToCurrentScope(builtin, scopeStackGlobal);
}

/*
Výkonná funkce funkce tohoto souboru (něco jako main)
průchodem této funkce se provede veškerá sémantika a generace kódu
je volán po kontrole syntaxe, v souboru syntax.c
@param ast_root ukazatel na hlavní kořen stromu vytvořeného parserem, který obsahuje celý kód k přeložení
Autor: Ondřej Šustr - xsustro00
*/
int sem_analysis_fn(Node *ast_root)
{
    initializeSemantic();
    if (!dynamic_string_init(&dyn_str))
    {
        return 1;
    }

    gen_header();
    gen_built_in_function();

    scopeStackGlobal = pushScope(scopeStackGlobal);
    pushBuiltin();
    Node *node = ast_root->children;
    if (ast_root->children == NULL)
    {
        fprintf(stderr, "Chybi funkce MAIN\n");
        exit(3);
    }
    Symbol *funcSymbol1 = createSymbol(node->data.function.id, FUNC, node->data.function.return_type);
    insertToCurrentScope(funcSymbol1, scopeStackGlobal);
    if (node->data.function.params != NULL)
    {
        Node *param = node->data.function.params;
        addParameter(funcSymbol1, param->data.parameter.id, param->data.parameter.type);
        while (param->sibling)
        {
            param = param->sibling;
            addParameter(funcSymbol1, param->data.parameter.id, param->data.parameter.type);
        }
    }
    while (node->sibling)
    {
        scopeStackGlobal = pushScope(scopeStackGlobal);
        node = node->sibling;
        Symbol *funcSymbol = createSymbol(node->data.function.id, FUNC, node->data.function.return_type);
        insertToCurrentScope(funcSymbol, scopeStackGlobal);
        if (node->data.function.params != NULL)
        {
            Node *param = node->data.function.params;
            addParameter(funcSymbol, param->data.parameter.id, param->data.parameter.type);
            while (param->sibling)
            {
                param = param->sibling;
                addParameter(funcSymbol, param->data.parameter.id, param->data.parameter.type);
            }
        }
    }
    Symbol *symbol = findInScopes("main", scopeStackGlobal);
    if (symbol == NULL)
    {
        fprintf(stderr, "Chzbi funkce MAIN!\n");
        exit(3);
    }
    else if (symbol->dataType != TYPE_VOID)
    {
        fprintf(stderr, "Funkce MAIN musi mit navratovou hodnotu VOID!\n");
        exit(4);
    }
    else if (symbol->parameters != NULL)
    {
        fprintf(stderr, "Funkce MAIN nesmi mit parametry!\n");
        exit(4);
    }

    process_ast(ast_root);

    gen_footer();

    dynamic_string_print_stdout(&dyn_str);

    dynamic_string_free(&dyn_str);

    return 0;
}

const char *ast_data_type_to_string(TYPE type)
{
    switch (type)
    {
    case TYPE_VOID:
        return "void";
    case TYPE_I32:
        return "i32";
    case TYPE_I32_NULL:
        return "?i32";
    case TYPE_F64:
        return "f64";
    case TYPE_F64_NULL:
        return "?f64";
    case TYPE_U8:
        return "[]u8";
    case TYPE_U8_NULL:
        return "?[]u8";
    default:
        return "unknown";
    }
}

const char *ast_operator_type_to_string(OPERATOR_TYPE type)
{
    switch (type)
    {
    case OP_PLUS:
        return "+";
    case OP_MINUS:
        return "-";
    case OP_STAR:
        return "*";
    case OP_SLASH:
        return "/";
    case OP_IDIV:
        return "/";
    case OP_EQUAL:
        return "==";
    case OP_NOT_EQUAL:
        return "!=";
    case OP_LESS:
        return "<";
    case OP_LESS_EQUAL:
        return "<=";
    case OP_GREATER:
        return ">";
    case OP_GREATER_EQUAL:
        return ">=";
    default:
        return "unknown";
    }
}

const char *ast_variable_type_to_string(VariableType type)
{
    switch (type)
    {
    case VAR_TYPE:
        return "var";
    case CONST_TYPE:
        return "const";
    default:
        return "unknown";
    }
}

/*
Pomocná funkce, která rozhoduje o datovém typu výrazu
Volá se pro rozpoznání datového typu argumentů volání funkce, deklarace proměnné, inicializace proměnné, returnu a podmínek u while a if
V některých částech se musí volat rekurzivně
@param node je ukazatel na daný uzel, který u kterého je potřeba zjistit datový typ z výrazu
Autor: Lukáš Gronich - xgronil00
*/
TYPE evaluateExpressionType(Node *node)
{
    if (node == NULL)
    {
        return TYPE_NONE; // Pokud není uzel, vrátíme neznámý typ
    }

    switch (node->type)
    {
    case NODE_EXPRESSION:
    {
        // Prvně je potřeba vyhodnotit levý a pak pravý operand
        Node *leftNode = node->children;
        Node *rightNode = node->children->sibling;

        TYPE leftType = evaluateExpressionType(leftNode);
        TYPE rightType = evaluateExpressionType(rightNode);

        if (leftNode->type == NODE_FACTOR && leftNode->data.factorNode.id != NULL)
        {
            // Pokud je operand id, musíme se podívat do tabulky symbolů, jestli existuje
            Symbol *symbol = findInScopes(leftNode->data.factorNode.id, scopeStackLocal);
            if (symbol == NULL)
            {
                fprintf(stderr, "Chyba 3: Proměnná %s není deklarována.\n", leftNode->data.factorNode.id);
                exit(3);
            }
            leftType = symbol->dataType;
        }

        // Kontrola, jestli pravý operand není id a potřebujeme zjistit jeho typ
        if (rightNode != NULL && rightNode->type == NODE_FACTOR && rightNode->data.factorNode.id != NULL)
        {
            // Pokud je operand id, musíme se podívat do tabulky symbolů, jestli existuje
            Symbol *symbol = findInScopes(rightNode->data.factorNode.id, scopeStackLocal);
            if (symbol == NULL)
            {
                fprintf(stderr, "Chyba 3: Proměnná %s není deklarována.\n", rightNode->data.factorNode.id);
                exit(3);
            }
            rightType = symbol->dataType;
        }
        // Kontrola operátoru a rozhodnutí o výsledném typu
        OPERATOR_TYPE operator= node->data.expressionNode.operator;

        // Operace mezi dvěma celými čísly vrací celé číslo
        if (leftType == TYPE_I32 && rightType == TYPE_I32)
        {
            // Celočíselné operace
            if (operator== OP_PLUS || operator== OP_MINUS ||
                operator== OP_STAR || operator== OP_IDIV || operator== OP_SLASH)
            {
                return TYPE_I32;
            }
        }

        // Operace mezi dvěma floaty vrací float
        if (leftType == TYPE_F64 && rightType == TYPE_F64)
        {
            if (operator== OP_PLUS || operator== OP_MINUS ||
                operator== OP_STAR || operator== OP_IDIV || operator== OP_SLASH)
            {
                return TYPE_F64;
            }
        }

        // Pokud levý nebo pravý operand je NULL, vracíme odpovídající typ s NULL hodnotou
        if (leftType == TYPE_I32_NULL || rightType == TYPE_I32_NULL)
        {
            fprintf(stderr, "Ve operacich se nesmi vyskytovat promenna, ktera muze obsahovat NULL!\n");
            exit(7);
        }
        if (leftType == TYPE_F64_NULL || rightType == TYPE_F64_NULL)
        {
            fprintf(stderr, "Ve operacich se nesmi vyskytovat promenna, ktera muze obsahovat NULL!\n");
            exit(7);
        }
        // Pokud neznáme nebo není kompatibilní
        return TYPE_NONE;
    }

    case NODE_FACTOR:
    {
        if (node->data.factorNode.id != NULL)
        {
            // Pokud je factor id, musíme se podívat do tabulky jestli existujem jinak error
            Symbol *factor = findInScopes(node->data.factorNode.id, scopeStackLocal);
            if (factor == NULL)
            {
                exit(3);
            }

            return factor->dataType;
        }
        else
        {
            // Pokud factor není id, vrátíme jeho typ
            return node->data.factorNode.factorType;
        }
    }

    case NODE_VARIABLE_DECLARATION:
    {
        // Pokud je to proměnná, vrátíme její datový typ
        Symbol *symbol = findInScopes(node->data.varDecl.id, scopeStackLocal);
        if (symbol != NULL)
        {
            return symbol->dataType;
        }
        return TYPE_NONE;
    }

    case NODE_CALL:
    {
        char *id;
        if (node->data.callNode.isBuildin == true)
        {
            // Pokud voláme buildin funkci, musíme id přidat prefix
            const char *prefix = "$$ifj_";
            size_t prefix_len = strlen(prefix);
            size_t func_name_len = strlen(node->data.callNode.id);
            char *new_name = malloc(prefix_len + func_name_len + 1);
            if (new_name == NULL)
            {
                fprintf(stderr, "Chyba: Nepodařilo se alokovat paměť.\n");
                exit(99);
            }
            strcpy(new_name, prefix);
            strcat(new_name, node->data.callNode.id);
            id = new_name;
        }
        else
        {
            // Pokud to není buildin funkce
            id = node->data.callNode.id;
        }
        // Zjistíme návratový typ funkce
        Symbol *functionSymbol = findInScopes(id, scopeStackGlobal);
        if (functionSymbol != NULL && functionSymbol->type == FUNC)
        {
            return functionSymbol->dataType;
        }
        return TYPE_NONE;
    }

    case NODE_CONDITION:
    {
        // Datový typ podmínky s NULL hodnotou vyhodnotíme podle levého operandu
        TYPE type = evaluateExpressionType(node->data.conditionNode.leftExpression);
        if (type == TYPE_F64_NULL)
        {
            return TYPE_F64;
        }
        else if (type == TYPE_I32_NULL)
        {
            return TYPE_I32;
        }
        else if (type == TYPE_U8_NULL)
        {
            return TYPE_U8;
        }
        return type;
    }

    default:
        return TYPE_NONE; // Defaultní typ nastavíme na none
    }
}

/*
@param arg ukazatel na node vstupního parametru (volání funkce)

slouží pro rekurzivní generování vstupních parametrů funkce

zavolá process_param_in na další parametr funkce, až dojde na konec parametrů (NULL),
začne volat generátor na tvoření kódu pro přípravu parametrů před zavoláním funkce
Autor: Ondřej Šustr - xsustro00
*/
void process_param_in(Node *arg)
{
    if (arg == NULL)
    {
        return;
    }

    process_param_in(arg->sibling);
    if (arg->data.factorNode.id)
    {
        Symbol *param_send = findInScopes(arg->data.factorNode.id, scopeStackLocal);
        if (param_send)
        {
            gen_param_in(arg->data.factorNode, param_send->symbol_scope_cnt);
        }
        else
        {
            fprintf(stderr, "Promenna %s neexistuje!\n", arg->data.factorNode.id);
            exit(3);
        }
    }
    else
    {
        gen_param_in(arg->data.factorNode, 0);
    }
}

/*
@param node ukazatel na node (expresion, nebo condition)

provede kontrolu datových typů obou dětí a zavola vhodnou funkci generátoru, pokud je konverze datových typů potřebná
exit(7), pokud dojde k problému
Autor: Ondřej Šustr - xsustro00
*/
void literal_conversion(Node *node)
{
    OPERATOR_TYPE operator;
    Node *left_expresion;
    Node *right_expresion;
    if (node == NULL)
        return;

    if (node->type == NODE_EXPRESSION)
    {
        operator= node->data.expressionNode.operator;
        left_expresion = node->children;
        right_expresion = node->children->sibling;
    }
    else if (node->type == NODE_CONDITION)
    {
        operator= node->data.conditionNode.operator;
        left_expresion = node->data.conditionNode.leftExpression;
        right_expresion = node->data.conditionNode.rightExpression;
    }
    else
    {
        return;
    }

    bool left_is_literal;
    TYPE left_type;
    bool right_is_literal;
    TYPE right_type;
    if (right_expresion->type == NODE_CONDITION || left_expresion->type == NODE_EXPRESSION ||
        (left_expresion->type == NODE_FACTOR && left_expresion->data.factorNode.id != NULL))
    {
        left_is_literal = false;
        left_type = evaluateExpressionType(left_expresion);
        // fprintf(stderr, "L_V %s ", ast_data_type_to_string(left_type));
    }
    else
    {
        left_is_literal = true;
        left_type = left_expresion->data.factorNode.factorType;
        // fprintf(stderr, "L_L %s ", ast_data_type_to_string(left_type));
    }

    if (right_expresion->type == NODE_CONDITION || right_expresion->type == NODE_EXPRESSION ||
        (right_expresion->type == NODE_FACTOR && right_expresion->data.factorNode.id != NULL))
    {
        right_is_literal = false;
        right_type = evaluateExpressionType(right_expresion);
        // fprintf(stderr, "R_V %s ", ast_data_type_to_string(right_type));
    }
    else
    {
        right_is_literal = true;
        right_type = right_expresion->data.factorNode.factorType;
        // fprintf(stderr, "R_L %s ", ast_data_type_to_string(right_type));
    }

    if (right_type == TYPE_U8 || right_type == TYPE_U8_NULL ||
        left_type == TYPE_U8 || left_type == TYPE_U8_NULL)
    {
        fprintf(stderr, "Chyba: type je rez.\n");
        exit(7);
    }

    if ((right_type == TYPE_NULL || left_type == TYPE_NULL ||
         right_type == TYPE_F64_NULL || left_type == TYPE_F64_NULL ||
         right_type == TYPE_I32_NULL || left_type == TYPE_I32_NULL) &&
        (operator!= OP_EQUAL && operator!= OP_NOT_EQUAL &&
         operator!= OP_PLUS && operator!= OP_MINUS &&
         operator!= OP_STAR && operator!= OP_SLASH && operator!= OP_IDIV))
    {
        fprintf(stderr, "Chyba: type muze mit null a neni spravny operator %s.\n", ast_operator_type_to_string(operator));
        exit(7);
    }

    if (right_type == TYPE_F64_NULL)
    {
        right_type = TYPE_F64;
    }
    else if (right_type == TYPE_I32_NULL)
    {
        right_type = TYPE_I32;
    }

    if (left_type == TYPE_F64_NULL)
    {
        left_type = TYPE_F64;
    }
    else if (left_type == TYPE_I32_NULL)
    {
        left_type = TYPE_I32;
    }

    if (left_is_literal == false && right_is_literal == true)
    {
        if (left_type == TYPE_F64 && right_type == TYPE_I32)
        {
            gen_literal_conversion_i2f();
            return;
        }
        else if (left_type == TYPE_I32 && right_type == TYPE_F64)
        {
            double intPart, fracPart;
            fracPart = modf(right_expresion->data.factorNode.value.f64, &intPart);
            if (fracPart == 0.0)
            {
                gen_literal_conversion_f2i();
                return;
            }
            else
            {
                exit(7);
            }
        }
    }

    if (left_is_literal == true && right_is_literal == false)
    {
        if (left_type == TYPE_I32 && right_type == TYPE_F64)
        {
            gen_pops_tmp();
            gen_literal_conversion_i2f();
            gen_pushs_tmp();
            return;
        }
        else if (left_type == TYPE_F64 && right_type == TYPE_I32)
        {
            double intPart, fracPart;
            fracPart = modf(right_expresion->data.factorNode.value.f64, &intPart);
            if (fracPart == 0.0)
            {
                gen_pops_tmp();
                gen_literal_conversion_f2i();
                gen_pushs_tmp();
                return;
            }
            else
            {
                exit(7);
            }
        }
    }

    if (right_type == left_type)
    {
        return;
    }

    fprintf(stderr, "Chyba: typ se i tak neshoduje, levy id je %s a typ %s, pravy id je %s a typ %s.\n", left_expresion->data.factorNode.id, ast_data_type_to_string(left_type), right_expresion->data.factorNode.id, ast_data_type_to_string(right_type));
    exit(7);
}

/*
@param node ukazatel na hlavní kořen stromu vytvořeného parserem, který obsahuje celý kód k přeložení

Funkce pro procházení a generování celého programu na vstupu (procházení AST)
Funkce generuje a zároveň kontroluje jednotlivé sématické chyby
Autoři:
Ondřej Šustr - xsustro00 (kostra),
Jakub Smička - xsmickj00 (scopování, if, while konstrukce, condition),
Lukáš Gronich - xgronil00 (většina sématických chyb, odvozování typů při odhalování sématických chyb, návrh procházení stromu)
*/
void process_ast(Node *node)
{
    Node *current_node = NULL;
    Node *arg = NULL;
    Symbol *symbol = NULL;
    if (!node)
    {
        return;
    }

    switch (node->type)
    {
    case NODE_MAIN:
        break;

    case NODE_FUNCTION:
        // case na deklaraci a inicializaci funkce
        scopeStackLocal = pushScope(scopeStackLocal);
        semantic.current_function = findInScopes(node->data.function.id, scopeStackGlobal); // Zjištění, jestli funkce existuje
        if (semantic.current_function == NULL)
        {
            fprintf(stderr, "Chyba: Funkce `%s` nebyla nalezena.\n", node->data.function.id);
            exit(3);
        }
        gen_function_start(node->data.function);
        if (node->data.function.params != NULL)
        {
            Node *param = node->data.function.params;

            while (param)
            {
                process_ast(param);
                param = param->sibling; // Průchod všech parametrů
            }
        }

        break;
        current_node = node->children;
        while (current_node)
        {
            process_ast(current_node);
            current_node = current_node->sibling; // Průchod těla funkce
        }
        gen_function_end(node->data.function);

        return;

    case NODE_CALL:
        // generuje přípravu vstupních parametrů a volání funkce (i built-in)
        if (node->data.callNode.isBuildin == true)
        {
            // Pro buildin funkce
            const char *prefix = "$$ifj_";
            size_t prefix_len = strlen(prefix);
            size_t func_name_len = strlen(node->data.callNode.id);
            char *new_name = malloc(prefix_len + func_name_len + 1);
            if (new_name == NULL)
            {
                fprintf(stderr, "Chyba: Nepodařilo se alokovat paměť.\n");
                exit(99);
            }
            strcpy(new_name, prefix);
            strcat(new_name, node->data.callNode.id);
            node->data.callNode.id = new_name;
        }
        symbol = findInScopes(node->data.callNode.id, scopeStackGlobal); // Hledání, jestli funkce existuje
        if (symbol == NULL)
        {
            fprintf(stderr, "Funkce %s neexistuje!\n", node->data.callNode.id);
            exit(3);
        }
        Parameter *expectedParam = symbol->parameters;
        Node *actualArg = node->data.callNode.args;
        int paramIndex = 1; // Pouze pro lepší výpis chyb

        while (expectedParam != NULL && actualArg != NULL)
        {
            // Zjistíme typ aktuálního argumentu
            TYPE actualArgType = evaluateExpressionType(actualArg);

            // Pokud typ argumentu neodpovídá očekávanému typu parametru
            if (actualArgType != TYPE_NONE && !node->data.callNode.isBuildin)
            {
                if (actualArgType != expectedParam->dataType)
                {
                    fprintf(stderr, "Chyba 4: Nesprávný typ parametru %d při volání funkce `%s`. Očekáván typ `%d`, ale nalezen typ `%d`.\n",
                            paramIndex, symbol->id, expectedParam->dataType, actualArgType);
                    exit(4);
                }
            }

            // Posuneme se na další parametr a argument
            expectedParam = expectedParam->next;
            actualArg = actualArg->sibling;
            paramIndex++;
        }

        // Pokud máme více parametrů než argumentů nebo více argumentů než parametrů
        if (expectedParam != NULL || actualArg != NULL)
        {
            fprintf(stderr, "Chyba 4: Nesprávný počet argumentů při volání funkce `%s`.\n", symbol->id);
            exit(4);
        }

        gen_function_params_frame();
        arg = node->data.callNode.args;
        process_param_in(arg);
        gen_call(node->data.callNode.id);

        break;

    case NODE_PARAMETER:
        // Vytvoření uzlu pro parametr
        Symbol *param = createSymbol(node->data.parameter.id, CONST, node->data.parameter.type);
        insertToCurrentScope(param, scopeStackLocal);
        gen_function_param(node->data.parameter, param->symbol_scope_cnt);

        break;

    case NODE_EXPRESSION:
        // node matematické operace (levá a pravá hodnota, +,-,*,/)
        process_ast(node->children);
        process_ast(node->children->sibling);
        literal_conversion(node);
        if (ltst_type == TYPE_I32 && node->data.expressionNode.operator== OP_SLASH)
        {
            gen_stack_operation(OP_IDIV);
        }
        else
        {
            gen_stack_operation(node->data.expressionNode.operator);
        }

        return;

    case NODE_RETURN:

        if (semantic.current_function->dataType == TYPE_VOID && node->data.returnNode.expression != NULL)
        {
            // Funkce typu void nesmí mít návratový výraz
            fprintf(stderr, "Chyba 4: Funkce `%s` typu `void` nesmí mít návratový výraz.\n", semantic.current_function->id);
            exit(6);
        }
        semantic.current_function->ret = true;

        TYPE returnType = evaluateExpressionType(node->data.returnNode.expression);
        TYPE expectedReturnType = semantic.current_function->dataType;
        if (expectedReturnType != TYPE_VOID && returnType == TYPE_NONE && node->data.returnNode.expression == NULL)
        {
            fprintf(stderr, "Chyba 6: Funkce `%s` očekává návratovou hodnotu, ale žádná není poskytnuta.\n", semantic.current_function->id);
            exit(6);
        }
        if (returnType != TYPE_NONE)
        {

            // Pokud funkce typu void má návratový výraz
            if (expectedReturnType == TYPE_VOID && returnType != TYPE_NONE)
            {
                fprintf(stderr, "Chyba 4: Funkce `%s` typu `void` nesmí mít návratový výraz.\n", semantic.current_function->id);
                exit(4);
            }

            // Pokud návratový typ neodpovídá očekávanému typu
            if (expectedReturnType != TYPE_VOID && returnType != TYPE_NONE && returnType != expectedReturnType)
            {
                fprintf(stderr, "Chyba 4: Nesprávný návratový typ ve funkci `%s`.\n", semantic.current_function->id);
                exit(4);
            }
        }
        // Pokud funkce očekává návratovou hodnotu, ale žádná není poskytnuta (chybí)

        process_ast(node->data.returnNode.expression);
        gen_return();

        break;

    case NODE_VARIABLE_DECLARATION:
        // deklarace a inicializace proměnné, pokud existuje exit(5), pokud problém s typem na vstupu exit(8)
        if (strcmp(node->data.varDecl.id, "_") == 0)
        {
            fprintf(stderr, "Promenna s identifikatorem _ se nedeklaruje!\n");
            exit(5);
        }
        symbol = findInScopes(node->data.varDecl.id, scopeStackLocal);
        if (!symbol)
        {
            Symbol *localVar;
            if (node->data.varDecl.var_type == VAR_TYPE)
            {
                if (node->data.varDecl.type == TYPE_NONE)
                {
                    TYPE varType = evaluateExpressionType(node->data.varDecl.expression); // Zjištění datového typu proměnné
                    // Kontrola správnosti proměnné
                    if (varType == TYPE_U8 && node->data.varDecl.expression->type != NODE_CALL)
                    {
                        fprintf(stderr, "Pro nahrani stringu do promenne se musi pouzit ifj.string!\n");
                        exit(8);
                    }
                    if (varType == TYPE_NULL)
                    {
                        fprintf(stderr, "Pri definovani promenne neslo odvodit typ!\n");
                        exit(8);
                    }
                    localVar = createSymbol(node->data.varDecl.id, VAR, varType);
                }
                else
                {
                    localVar = createSymbol(node->data.varDecl.id, VAR, node->data.varDecl.type);
                }
            }
            else
            {
                if (node->data.varDecl.type == TYPE_NONE)
                {
                    TYPE varType = evaluateExpressionType(node->data.varDecl.expression); // Zjištění datového typu konstanty
                    // Kontrola správnosti konstanty
                    if (varType == TYPE_U8 && node->data.varDecl.expression->type != NODE_CALL)
                    {
                        fprintf(stderr, "Pro nahrani stringu do promenne se musi pouzit ifj.string!\n");
                        exit(8);
                    }
                    if (varType == TYPE_NULL)
                    {
                        fprintf(stderr, "Pri definovani promenne neslo odvodit typ!\n");
                        exit(8);
                    }
                    localVar = createSymbol(node->data.varDecl.id, CONST, varType);
                }
                else
                {
                    localVar = createSymbol(node->data.varDecl.id, CONST, node->data.varDecl.type);
                }
            }
            insertToCurrentScope(localVar, scopeStackLocal);
            gen_local_var_def(node->data.varDecl.id, localVar->symbol_scope_cnt);
            process_ast(node->data.varDecl.expression);
            gen_local_var_init(node->data.varDecl.id, localVar->symbol_scope_cnt);
        }
        else if (symbol && top_while)
        {
            TYPE type = evaluateExpressionType(node->data.varDecl.expression);
            symbol->dataType = type;
            process_ast(node->data.varDecl.expression);
            gen_local_var_init(node->data.varDecl.id, symbol->symbol_scope_cnt);
        }
        else
        {
            // Proměnná/konstatna s tímto id už existuje
            fprintf(stderr, "Promenna je jiz deklarovana jinde!%s\n", node->data.varDecl.id);
            exit(5);
        }

        break;

    case NODE_IF:
        if (!top_while) // Pokud se nevyužila pomocná funkce, při procházení těla while
        {
            scopeStackLocal = pushScope(scopeStackLocal);
        }
        null_condtition = node->data.ifNode.id_null != NULL;

        process_ast(node->data.ifNode.condition);
        if (!null_condtition)
        {
            gen_if_defaultstart(node->data.ifNode.cnt);
            break;
        }
        else
        {
            Symbol *id_null;
            if (!top_while)
            {
                gen_if_tmp(node->data.ifNode.cnt);
                TYPE id_null_type = evaluateExpressionType(node->data.ifNode.condition);
                id_null = createSymbol(node->data.ifNode.id_null, CONST, id_null_type);
                insertToCurrentScope(id_null, scopeStackLocal);
                gen_null_var(node->data.ifNode.id_null, id_null->symbol_scope_cnt);
            }
            else
            {
                id_null = findInScopes(node->data.ifNode.id_null, scopeStackLocal);
                TYPE type = evaluateExpressionType(node->data.ifNode.condition);
                id_null->dataType = type;
            }
            gen_if_nullstart(node->data.ifNode.cnt, node->data.ifNode.id_null, id_null->symbol_scope_cnt);
        }
        break;

    case NODE_IF_BODY: // Nic se nedělá, jen se vygeneruje tělo funkce
        break;

    case NODE_ELSE_BODY:
        if (!top_while)
        {
            scopeStackLocal = pushScope(scopeStackLocal); // Pokud se nevyužila pomocná funkce, při procházení těla while
        }

        gen_if_else_start(node->data.elseBody.cnt); // Vygeneruje se návěstí těla else, pro skok, kdyby byla condition false
        break;

    case NODE_WHILE:
        if (!top_while)
        {
            scopeStackLocal = pushScope(scopeStackLocal); // Pokud se nevyužila pomocná funkce, při procházení těla while
        }
        if (!top_while) // Pokud se nevyužila pomocná funkce, tak je toto první while (nevnořený do dalšího) a musí se provést generování všech proměnných
        {
            top_while = node;
            ast_gen_vars(node);
        }
        if (node->data.whileNode.id_null == NULL)
        {
            gen_while_start(node->data.whileNode.cnt);
            null_condtition = false;
            process_ast(node->data.whileNode.condition);
            gen_while_after_exp(node->data.whileNode.cnt);
        }
        else
        {
            Symbol *id_null;
            if (!top_while)
            {
                TYPE id_null_type = evaluateExpressionType(node->data.ifNode.condition);
                id_null = createSymbol(node->data.whileNode.id_null, CONST, id_null_type);
                insertToCurrentScope(id_null, scopeStackLocal);
                gen_null_var(node->data.whileNode.id_null, id_null->symbol_scope_cnt);
                gen_while_tmp(node->data.whileNode.cnt);
            }
            else
            {
                id_null = findInScopes(node->data.ifNode.id_null, scopeStackLocal);
                TYPE type = evaluateExpressionType(node->data.ifNode.condition);
                id_null->dataType = type;
            }
            gen_while_startnull(node->data.whileNode.cnt);
            null_condtition = true;
            process_ast(node->data.whileNode.condition);
            gen_while_afternull(node->data.whileNode.cnt, node->data.whileNode.id_null, id_null->symbol_scope_cnt);
        }
        break;

    case NODE_CONDITION:
        process_ast(node->data.conditionNode.leftExpression);

        if (node->data.conditionNode.rightExpression != NULL && !null_condtition)
        {
            bool do_orequal = false; // Instrukcni sada neumi <= a >=, musim provest takto, at nevytvarim pomocne promenne
            if (node->data.conditionNode.operator== OP_GREATER_EQUAL)
            {
                node->data.conditionNode.operator= OP_GREATER;
                do_orequal = true;
            }
            else if (node->data.conditionNode.operator== OP_LESS_EQUAL)
            {
                node->data.conditionNode.operator= OP_LESS;
                do_orequal = true;
            }
            process_ast(node->data.conditionNode.rightExpression);
            literal_conversion(node);
            gen_stack_operation(node->data.conditionNode.operator);
            if (do_orequal)
            {
                process_ast(node->data.conditionNode.leftExpression);
                process_ast(node->data.conditionNode.rightExpression);
                gen_stack_operation(OP_EQUAL);
                gen_stack_operation(OP_OR);
            }
        }
        // Ošetrení správnosti výrazu
        else if (node->data.conditionNode.rightExpression != NULL && null_condtition)
        {
            fprintf(stderr, "Vyraz nema byt pravdivostni, ale s NULL!\n");
            exit(7);
        }
        else if (node->data.conditionNode.rightExpression == NULL && !null_condtition)
        {
            fprintf(stderr, "Vyraz neni pravdivostni\n");
            exit(7);
        }

        break;

    case NODE_VARIABLE_INITIALIZATION:
        // inicializace existující VAR proměnné, jinak exit(3), pokud problém s datovým typem na vstupu exit(7)
        process_ast(node->data.varDecl.expression);
        Symbol *init = findInScopes(node->data.varDecl.id, scopeStackLocal); // Zjistíme jestli id proměnné existuje
        TYPE assignedType = evaluateExpressionType(node->data.varDecl.expression);
        if (strcmp(node->data.varDecl.id, "_") != 0)
        {
            if (init == NULL)
            {
                fprintf(stderr, "Promenna neexistuje!\n");
                exit(3);
            }
            else if (init->type == VAR)
            {
                if (assignedType != TYPE_NONE && init->dataType != TYPE_NONE)
                {
                    // Ošetření správnosti přiřazení
                    if (assignedType != init->dataType)
                    {
                        if (!((init->dataType == TYPE_F64_NULL && (assignedType == TYPE_F64 || assignedType == TYPE_NULL)) || (init->dataType == TYPE_I32_NULL && (assignedType == TYPE_I32 || assignedType == TYPE_NULL)) || (init->dataType == TYPE_U8_NULL && assignedType == TYPE_NULL)))
                        {
                            fprintf(stderr, "Chyba 4: Nesprávný typ přiřazení do proměnné `%s`. Očekáván typ `%d`, nalezen typ `%d`.\n",
                                    node->data.varDecl.id, init->dataType, assignedType);
                            exit(7);
                        }
                    }
                    if (assignedType == TYPE_U8 && node->data.varDecl.expression->type != NODE_CALL)
                    {
                        fprintf(stderr, "Pro nahrani stringu do promenne se musi pouzit ifj.string!\n");
                        exit(7);
                    }
                }

                init->changed = true;
            }
            // Konstantu nelze měnit
            else if (init->type == CONST)
            {
                fprintf(stderr, "Promenna typu const se nesmi prepsat!\n");
                exit(5);
            }
            gen_local_var_init(node->data.varDecl.id, init->symbol_scope_cnt); // pops ze stacku
        }
        else
        {
            gen_flush();
        }

        break;

    case NODE_FACTOR:
        // volá funkci generátoru k PUSHnutí hodnoty/proměnné na stack
        if (node->data.factorNode.id != NULL)
        {
            // Pokud je ve výrazu id, musíme se zjistit jestli existuje
            Symbol *factor = findInScopes(node->data.factorNode.id, scopeStackLocal);
            if (factor == NULL)
            {
                exit(3);
            }
            gen_pushs_prom(node->data.factorNode.id, factor->symbol_scope_cnt);
            ltst_type = factor->dataType;
        }
        else
        {
            gen_pushs_literal(node->data.factorNode);
        }
        break;

    default:
        break;
    }
    Node *child = node->children;
    while (child)
    {
        process_ast(child);
        child = child->sibling;
    }
    switch (node->type) // Druhý switch slouží po vynořování v AST - kontrola sematických chyb, ukončování scopů a tvoření návěstí konců
    {
    case NODE_IF_BODY:
        checkUnusedSymbols(scopeStackLocal); // Kontorla použití a zmeěna porměnných
        gen_if_end(node->data.ifBody.cnt);
        scopeStackLocal = popScope(scopeStackLocal);
        break;

    case NODE_ELSE_BODY:
        checkUnusedSymbols(scopeStackLocal); // Kontorla použití a změna porměnných
        gen_if_else_end(node->data.elseBody.cnt);
        scopeStackLocal = popScope(scopeStackLocal);
        break;
    case NODE_WHILE:
        checkUnusedSymbols(scopeStackLocal); // Kontorla použití a změna porměnných
        gen_while_end(node->data.whileNode.cnt);
        scopeStackLocal = popScope(scopeStackLocal);
        if (node == top_while)
        {
            top_while = NULL; // Pokud jsme vylezli z nejvyššího while, tak musíme také naznačit, že už je celý while hotový a další by se musel opět řešit pomocnou funkcí gen vars
        }
        break;
    case NODE_FUNCTION:
        checkReturn(); // Kontrola, jestli je ve funkci return
        checkUnusedSymbols(scopeStackLocal);
        scopeStackLocal = popScope(scopeStackLocal);
        gen_function_end(node->data.function);
        break;
    default:
        break;
    }
}
