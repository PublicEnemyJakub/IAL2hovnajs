/*
Autor: Ondřej Šustr - xsustro00
*/
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "dynamic_string.h"

#define INITIAL_CAPACITY 16

extern char *filename;
char *buffer;

/*
@param dyn_str ukazatel na dynamický string

inicializace dynamického stringu, (alokuje základní paměť)
*/
bool dynamic_string_init(Dynamic_string *dyn_str)
{
    if (dyn_str == NULL)
    {
        return false; // Invalid input
    }

    dyn_str->str = (char *)malloc(INITIAL_CAPACITY * sizeof(char));
    if (dyn_str->str == NULL)
    {
        return false;
    }

    dyn_str->str[0] = '\0'; // Start with an empty string
    dyn_str->length = 0;
    dyn_str->capacity = INITIAL_CAPACITY;

    return true;
}

/*
@param dyn_str ukazatel na dynamický string
@param new_capacity nová délka stringu
*/
bool dynamic_string_resize(Dynamic_string *dyn_str, size_t new_capacity)
{
    char *new_str = (char *)realloc(dyn_str->str, new_capacity * sizeof(char));
    if (new_str == NULL)
    {
        return false;
    }
    dyn_str->str = new_str;
    dyn_str->capacity = new_capacity;
    return true;
}

/*
@param dyn_str ukazatel na dynamický string
@param c symbol k přidání na konec stringu
*/
bool dynamic_string_add_char(Dynamic_string *dyn_str, char c)
{
    if (dyn_str->length + 1 >= dyn_str->capacity)
    {
        if (!dynamic_string_resize(dyn_str, dyn_str->capacity * 2))
        {
            return false;
        }
    }
    dyn_str->str[dyn_str->length++] = c;
    dyn_str->str[dyn_str->length] = '\0';
    return true;
}

/*
@param input string
@return vrací string upravený o escape sekvence a další speciality ifj24 kódu
*/
char *dynamic_string_process_const_str(const char *input)
{
    // Délka vstupu a odhad délky výstupu
    size_t input_len = strlen(input);
    size_t output_len = input_len * 4; // Odhad pro případ maximální potřeby escape sekvencí
    char *output = malloc(output_len + 1);

    if (!output)
    {
        fprintf(stderr, "Chyba: Nepodarilo se alokovat pamet.\n");
        exit(99);
    }

    size_t j = 0; // Index pro výstupní řetězec
    for (size_t i = 0; i < input_len; ++i)
    {
        unsigned char c = input[i];

        // Znaky, které potřebují escape sekvenci
        if (c <= 32 || c == 35 || c == 92)
        {
            if (j + 4 >= output_len)
            {
                // Realokace, pokud nestačí paměť
                output_len *= 2;
                output = realloc(output, output_len + 1);
                if (!output)
                {
                    fprintf(stderr, "Chyba: Nepodařilo se realokovat paměť.\n");
                    exit(99);
                }
            }
            sprintf(&output[j], "\\%03d", c);
            j += 4; // Každá escape sekvence má 4 znaky
        }
        else
        {
            // Tisknutelné ASCII znaky kromě výjimek
            if (j + 1 >= output_len)
            {
                // Realokace, pokud nestačí paměť
                output_len *= 2;
                output = realloc(output, output_len + 1);
                if (!output)
                {
                    fprintf(stderr, "Chyba: Nepodarilo se realokovat pamet.\n");
                    exit(99);
                }
            }
            output[j++] = c;
        }
    }

    output[j] = '\0'; // Ukončení řetězce
    return output;
}

/*
@param dyn_str ukazatel na dynamický string
@param src string k přidání na konec stringu
*/
bool dynamic_string_add_const_str(Dynamic_string *dyn_str, const char *src)
{
    size_t src_len = strlen(src);
    while (dyn_str->length + src_len >= dyn_str->capacity)
    {
        if (!dynamic_string_resize(dyn_str, dyn_str->capacity * 2))
        {
            return false;
        }
    }
    strcat(dyn_str->str, src);
    dyn_str->length += src_len;
    return true;
}

/*
@param dyn_str dynamický string

vyprázdnění stringu
*/
void dynamic_string_clear(Dynamic_string *dyn_str)
{
    dyn_str->length = 0;
    dyn_str->str[dyn_str->length] = '\0';
}

/*
@param dyn_str dynamický string

uvolnění stringu (free)
*/
void dynamic_string_free(Dynamic_string *dyn_str)
{
    free(dyn_str->str);
    dyn_str->str = NULL;
    dyn_str->length = 0;
    dyn_str->capacity = 0;
}
/*
Funkce využitelná pro implementování - výstup jde do souboru místo stdout
@param dyn_str dynamický string
@param filename název souboru kam se má dyn_str uložit
*/
bool dynamic_string_write_to_file(Dynamic_string *dyn_str, const char *filename)
{
    if (dyn_str == NULL || dyn_str->str == NULL || filename == NULL)
    {
        return false; // Invalidní vstup
    }

    FILE *file = fopen(filename, "w");
    if (file == NULL)
    {
        return false;
    }

    size_t written = fwrite(dyn_str->str, sizeof(char), dyn_str->length, file);
    fclose(file);

    return (written == dyn_str->length);
}

/*
@param dyn_str dynamický string

vytištění dynamického stringu na stdout
*/
void dynamic_string_print_stdout(Dynamic_string *dyn_str)
{
    fprintf(stdout, "%s\n", dyn_str->str);
}
