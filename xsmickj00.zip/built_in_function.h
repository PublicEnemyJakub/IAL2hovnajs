/*
Autor: Ondřej Šustr - xsustro00
*/

/*
ze standartního vstupu načte jeden řádek ukončený odřádkováním
 nebo koncem souboru (EOF). Vrátí načtený řetězec
 bez symbolu konce řádku, při špatném formátu vrátí null
@return []u8 nebo nil@nil
*/
#define FUNCTION_READ_STR                                  \
    "\n # Built-in function ifj_readstr"                   \
    "\n LABEL $$$ifj_readstr"                              \
    "\n PUSHFRAME"                                         \
    "\n DEFVAR LF@retval"                                  \
    "\n MOVE LF@retval nil@nil"                            \
    "\n DEFVAR LF@input"                                   \
    "\n DEFVAR LF@type"                                    \
    "\n READ LF@input string"                              \
    "\n TYPE LF@type LF@input"                             \
    "\n JUMPIFNEQ $$ifj_readstr_end LF@type string@string" \
    "\n MOVE LF@retval LF@input"                           \
    "\n LABEL $$ifj_readstr_end"                           \
    "\n PUSHS LF@retval"                                   \
    "\n POPFRAME"                                          \
    "\n RETURN"

/*
ze standartního vstupu načte jeden řádek ukončený odřádkováním
 nebo koncem souboru (EOF). Vrátí celočíselnou hodnotu
 pokud byla na vstupu platná (neprázdná) f64/i32 hodnota
 (pokud f64, převede na i32 odříznutím desetinné části),
 jinak vrátí null
@return i32 nebo nil@nil
*/
#define FUNCTION_READ_I32                               \
    "\n # Built-in function ifj_readi32"                \
    "\n LABEL $$$ifj_readi32"                           \
    "\n PUSHFRAME"                                      \
    "\n DEFVAR LF@retval"                               \
    "\n MOVE LF@retval nil@nil"                         \
    "\n DEFVAR LF@input"                                \
    "\n DEFVAR LF@type"                                 \
    "\n READ LF@input int"                              \
    "\n TYPE LF@type LF@input"                          \
    "\n JUMPIFNEQ $$ifj_readi32_end LF@type string@int" \
    "\n MOVE LF@retval LF@input"                        \
    "\n LABEL $$ifj_readi32_end"                        \
    "\n PUSHS LF@retval"                                \
    "\n POPFRAME"                                       \
    "\n RETURN"

/*
ze standartního vstupu načte jeden řádek ukončený odřádkováním
 nebo koncem souboru (EOF). Vrátí desetinnou hodnotu
 pokud byla na vstupu platná (neprázdná) f64 hodnota,
 jinak vrátí null
@return f64 nebo nil@nil
*/
#define FUNCTION_READ_F64                                 \
    "\n # Built-in function ifj_readf64"                  \
    "\n LABEL $$$ifj_readf64"                             \
    "\n PUSHFRAME"                                        \
    "\n DEFVAR LF@retval"                                 \
    "\n MOVE LF@retval nil@nil"                           \
    "\n DEFVAR LF@input"                                  \
    "\n DEFVAR LF@type"                                   \
    "\n READ LF@input float"                              \
    "\n TYPE LF@type LF@input"                            \
    "\n JUMPIFNEQ $$ifj_readf64_end LF@type string@float" \
    "\n MOVE LF@retval LF@input"                          \
    "\n LABEL $$ifj_readf64_end"                          \
    "\n PUSHS LF@retval"                                  \
    "\n POPFRAME"                                         \
    "\n RETURN"

/*
vypíše hodnotu termu na standartní výstup ihned
 a bez žádných oddělovačů dle typu v patřičném formátu.
 Hodnota termu typu i32 bude vytištěna pomocí '%d',
 hodnota termu typu f64 pak pomocí '%a'. Hod
 nota null je tištěna jako literál "null"
@param term je typu (int, float, []u8, nil)
@return void
*/
#define FUNCTION_WRITE                                \
    "\n # Built-in function ifj_write"                \
    "\n LABEL $$$ifj_write"                           \
    "\n PUSHFRAME"                                    \
    "\n DEFVAR LF@param"                              \
    "\n POPS LF@param"                                \
    "\n DEFVAR LF@type"                               \
    "\n TYPE LF@type LF@param"                        \
    "\n JUMPIFEQ $$ifj_write_null LF@type string@nil" \
    "\n WRITE LF@param"                               \
    "\n JUMP $$ifj_write_end"                         \
    "\n LABEL $$ifj_write_null"                       \
    "\n WRITE string@null"                            \
    "\n LABEL $$ifj_write_end"                        \
    "\n POPFRAME"                                     \
    "\n RETURN"

/*
@param term celočíselná hodnota - typ i32
@return vrátí hodnotu celočíselného termu konvertovanou
 na desetinné číslo
*/
/*
ERROR hadling pri parametr neni int
*/
#define FUNCTION_I2F                 \
    "\n # Built-in function ifj_i2f" \
    "\n LABEL $$$ifj_i2f"            \
    "\n PUSHFRAME"                   \
    "\n DEFVAR LF@param"             \
    "\n POPS LF@param"               \
    "\n INT2FLOAT LF@param LF@param" \
    "\n LABEL $$ifj_i2f_end"         \
    "\n PUSHS LF@param"              \
    "\n POPFRAME"                    \
    "\n RETURN"
/*
    "\n MOVE LF@retval nil@nil"                   \
    "\n DEFVAR LF@type"                           \
    "\n TYPE LF@type LF@param"                    \
    "\n JUMPIFNEQ ifj_i2f_end LF@type string@int" \
*/

/*
@param term desetinná hodnota - typ f64
@return vrátí hodnotu desetinného termu konvertovanou
 na celé číslo, a to oříznutím desetinné části
*/
/*
ERROR hadling pri parametr neni float
*/
#define FUNCTION_F2I                 \
    "\n # Built-in function ifj_f2i" \
    "\n LABEL $$$ifj_f2i"            \
    "\n PUSHFRAME"                   \
    "\n DEFVAR LF@param"             \
    "\n POPS LF@param"               \
    "\n FLOAT2INT LF@param LF@param" \
    "\n LABEL $$ifj_f2i_end"         \
    "\n PUSHS LF@param"              \
    "\n POPFRAME"                    \
    "\n RETURN"

/*
    "\n MOVE LF@retval nil@nil"                     \
    "\n DEFVAR LF@type"                             \
    "\n TYPE LF@type LF@param"                      \
    "\n JUMPIFNEQ ifj_f2i_end LF@type string@float" \
*/

/*
@param term (je řetězový literál nebo řez)
@return řez - typ []u8
*/
/*
ERROR hadling pri parametr neni string
*/
#define FUNCTION_STRING                 \
    "\n # Built-in function ifj_string" \
    "\n LABEL $$$ifj_string"            \
    "\n PUSHFRAME"                      \
    "\n DEFVAR LF@param"                \
    "\n POPS LF@param"                  \
    "\n LABEL $$ifj_string_end"         \
    "\n PUSHS LF@param"                 \
    "\n POPFRAME"                       \
    "\n RETURN"

/*
"\n DEFVAR LF@type"                                 \
"\n TYPE LF@type LF@parm"                           \
"\n JUMPIFNEQ ifj_string_end LF@type string@string" \
*/
/*
@param s řez - typ []u8
@return vrátí délku řezu - typ i32
*/
#define FUNCTION_LENGTH                 \
    "\n # Built-in function ifj_length" \
    "\n LABEL $$$ifj_length"            \
    "\n PUSHFRAME"                      \
    "\n DEFVAR LF@param"                \
    "\n POPS LF@param"                  \
    "\n STRLEN LF@param LF@param"       \
    "\n LABEL $$ifj_length_end"         \
    "\n PUSHS LF@param"                 \
    "\n POPFRAME"                       \
    "\n RETURN"
/*
    "\n DEFVAR LF@type"                                 \
    "\n TYPE LF@type LF@param"                          \
    "\n JUMPIFNEQ ifj_length_end LF@type string@string" \
*/
/*
@param s1 řez
@param s2 řez, který bude následovat ten první
@return vrátí konkatenaci (spojení) řezů
*/
#define FUNCTION_CONCAT                       \
    "\n # Built-in function ifj_concat"       \
    "\n LABEL $$$ifj_concat"                  \
    "\n PUSHFRAME"                            \
    "\n DEFVAR LF@param1"                     \
    "\n DEFVAR LF@param2"                     \
    "\n POPS LF@param1"                       \
    "\n POPS LF@param2"                       \
    "\n DEFVAR LF@retval"                     \
    "\n CONCAT LF@retval LF@param1 LF@param2" \
    "\n LABEL $$ifj_concat_end"               \
    "\n PUSHS LF@retval"                      \
    "\n POPFRAME"                             \
    "\n RETURN"
/*
    "\n DEFVAR LF@type"                                 \
    "\n MOVE LF@param1 TF@%1"                           \
    "\n MOVE LF@param2 TF@%2l"                          \
    "\n TYPE LF@type LF@param1"                         \
    "\n JUMPIFNEQ ifj_concat_end LF@type string@string" \
    "\n TYPE LF@type LF@param2"                         \
    "\n JUMPIFNEQ ifj_concat_end LF@type string@string" \
*/
/*
@param s řez pole znaků - typ []u8
@param i index začátku podřetězce - typ i32
@param j index za posledním znakem podřetězce v  - typ i32
@return podřez z vloženého řezu (s[i] - s[j-1])
*/
#define FUNCTION_SUBSTRING                                \
    "\n # Built-in function ifj_substring"                \
    "\n LABEL $$$ifj_substring"                           \
    "\n PUSHFRAME"                                        \
    "\n DEFVAR LF@param1"                                 \
    "\n DEFVAR LF@param2"                                 \
    "\n DEFVAR LF@param3"                                 \
    "\n DEFVAR LF@retval"                                 \
    "\n DEFVAR LF@char"                                   \
    "\n MOVE LF@retval string@"                           \
    "\n POPS LF@param1"                                   \
    "\n POPS LF@param2"                                   \
    "\n POPS LF@param3"                                   \
    "\n LT GF@bool LF@param2 int@0"                       \
    "\n JUMPIFEQ $$ifj_substring_null GF@bool bool@true"  \
    "\n LT GF@bool LF@param3 int@0"                       \
    "\n JUMPIFEQ $$ifj_substring_null GF@bool bool@true"  \
    "\n GT GF@bool LF@param2 LF@param3"                   \
    "\n JUMPIFEQ $$ifj_substring_null GF@bool bool@true"  \
    "\n DEFVAR LF@strlen"                                 \
    "\n CREATEFRAME"                                      \
    "\n PUSHS LF@param1"                                  \
    "\n CALL $$$ifj_length"                               \
    "\n POPS LF@strlen"                                   \
    "\n LT GF@bool LF@param2 LF@strlen"                   \
    "\n JUMPIFEQ $$ifj_substring_null GF@bool bool@false" \
    "\n GT GF@bool LF@param3 LF@strlen"                   \
    "\n JUMPIFEQ $$ifj_substring_null GF@bool bool@true"  \
    "\n LABEL $$ifj_substring_loop"                       \
    "\n JUMPIFEQ $$ifj_substring_end LF@param2 LF@param3" \
    "\n GETCHAR LF@char LF@param1 LF@param2"              \
    "\n CONCAT LF@retval LF@retval LF@char"               \
    "\n ADD LF@param2 LF@param2 int@1"                    \
    "\n JUMP $$ifj_substring_loop"                        \
    "\n LABEL $$ifj_substring_null"                       \
    "\n MOVE LF@retval nil@nil"                           \
    "\n LABEL $$ifj_substring_end"                        \
    "\n PUSHS LF@retval"                                  \
    "\n POPFRAME"                                         \
    "\n RETURN"

/*
porovná 2 řezy polí znaků
@param s1 řez pole znaků - typ []u8
@param s2 řez pole znaků - typ []u8
@return vrátí (-1) pokud je s1 menší než s2, (1) pokud je s1 větší, (0) pokud se rovnají - typ i32
*/
#define FUNCTION_STRCMP                                  \
    "\n # Built-in function ifj_strcmp"                  \
    "\n LABEL $$$ifj_strcmp"                             \
    "\n PUSHFRAME"                                       \
    "\n DEFVAR LF@retval"                                \
    "\n DEFVAR LF@param1"                                \
    "\n DEFVAR LF@param2"                                \
    "\n DEFVAR LF@char1"                                 \
    "\n DEFVAR LF@char2"                                 \
    "\n DEFVAR LF@index"                                 \
    "\n DEFVAR LF@strlen1"                               \
    "\n DEFVAR LF@strlen2"                               \
    "\n MOVE LF@index int@0"                             \
    "\n POPS LF@param1"                                  \
    "\n POPS LF@param2"                                  \
    "\n CREATEFRAME"                                     \
    "\n PUSHS LF@param1"                                 \
    "\n CALL $$$ifj_length"                              \
    "\n POPS LF@strlen1"                                 \
    "\n CREATEFRAME"                                     \
    "\n PUSHS LF@param2"                                 \
    "\n CALL $$$ifj_length"                              \
    "\n POPS LF@strlen2"                                 \
    "\n LABEL $$ifj_strcmp_loop"                         \
    "\n JUMPIFEQ $$ifj_strcmp_less LF@index LF@strlen1"  \
    "\n JUMPIFEQ $$ifj_strcmp_more LF@index LF@strlen2"  \
    "\n GETCHAR LF@char1 LF@param1 LF@index"             \
    "\n GETCHAR LF@char2 LF@param2 LF@index"             \
    "\n LT GF@bool LF@char1 LF@char2"                    \
    "\n JUMPIFEQ $$ifj_strcmp_less GF@bool bool@true"    \
    "\n GT GF@bool LF@char1 LF@char2"                    \
    "\n JUMPIFEQ $$ifj_strcmp_more GF@bool bool@true"    \
    "\n ADD LF@index LF@index int@1"                     \
    "\n JUMP $$ifj_strcmp_loop"                          \
    "\n LABEL $$ifj_strcmp_less"                         \
    "\n JUMPIFEQ $$ifj_strcmp_equal LF@index LF@strlen2" \
    "\n MOVE LF@retval int@-1"                           \
    "\n JUMP $$ifj_strcmp_end"                           \
    "\n LABEL $$ifj_strcmp_more"                         \
    "\n MOVE LF@retval int@1"                            \
    "\n JUMP $$ifj_strcmp_end"                           \
    "\n LABEL $$ifj_strcmp_equal"                        \
    "\n MOVE LF@retval int@0"                            \
    "\n LABEL $$ifj_strcmp_end"                          \
    "\n PUSHS LF@retval"                                 \
    "\n POPFRAME"                                        \
    "\n RETURN"
/*
    "\n TYPE GF@type LF@param1"                         \
    "\n JUMPIFNEQ ifj_strcmp_end GF@type string@string" \
    "\n TYPE GF@type LF@param2"                         \
    "\n JUMPIFNEQ ifj_strcmp_end GF@type string@string" \
*/
/*
Převede i-tý znak v řezu na ordinální hodnotu podle ASCII tabulky
@param s1 řez pole znaků - typ []u8
@param i index - typ i32
@return ordinální hodnota (ASCII) - typ i32
*/
#define FUNCTION_ORD                               \
    "\n # Built-in function ifj_ord"               \
    "\n LABEL $$$ifj_ord"                          \
    "\n PUSHFRAME"                                 \
    "\n DEFVAR LF@retval"                          \
    "\n DEFVAR LF@param1"                          \
    "\n DEFVAR LF@param2"                          \
    "\n DEFVAR LF@strlen"                          \
    "\n POPS LF@param1"                            \
    "\n POPS LF@param2"                            \
    "\n MOVE LF@retval int@0"                      \
    "\n CREATEFRAME"                               \
    "\n PUSHS LF@param1"                           \
    "\n CALL $$$ifj_length"                        \
    "\n POPS LF@strlen"                            \
    "\n JUMPIFEQ $$ifj_ord_end LF@strlen int@0"    \
    "\n LT GF@bool LF@param2 int@0"                \
    "\n JUMPIFEQ $$ifj_ord_end GF@bool bool@true"  \
    "\n LT GF@bool LF@param2 LF@strlen"            \
    "\n JUMPIFEQ $$ifj_ord_end GF@bool bool@false" \
    "\n STRI2INT LF@retval LF@param1 LF@param2"    \
    "\n LABEL $$ifj_ord_end"                       \
    "\n PUSHS LF@retval"                           \
    "\n POPFRAME"                                  \
    "\n RETURN"
/*
    "\n TYPE GF@type LF@param1"                      \
    "\n JUMPIFNEQ ifj_ord_end LF@type string@string" \
    "\n JUMPIFNEQ ifj_ord_end LF@param1 string@"     \
*/
/*
Převede celočíselnou hodnotu na znak podle ASCII tabulky
@param i typ i32
@return []u8 jednoznakový řez se znakem
*/
#define FUNCTION_CHR                 \
    "\n # Built-in function ifj_chr" \
    "\n LABEL $$$ifj_chr"            \
    "\n PUSHFRAME"                   \
    "\n DEFVAR LF@retval"            \
    "\n DEFVAR LF@param"             \
    "\n POPS LF@param"               \
    "\n INT2CHAR LF@retval LF@param" \
    "\n LABEL $$ifj_chr_end"         \
    "\n PUSHS LF@retval"             \
    "\n POPFRAME"                    \
    "\n RETURN"
