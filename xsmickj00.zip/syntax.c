// Autori: xsmickj00 + xgronil00

// #define DEBUG 1
#ifndef DEBUG
// pro debuging
#define compile(s) sem_analysis_fn(s)
#else
#define compile(s) ast_print(s, 0)
#endif

#include "lex_analysis.h"
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>
#include "tree.h"
#include "sem_analysis.h"

#define STACK_MAX_SIZE 100

// Funkce pro LL rekurzi
void advance();
void unexpToken();
void match(TokenType expected, KeyType expected2);
void matchKey(KeyType expected);
bool check(TokenType expected, KeyType expected2);
bool checkKey(KeyType expected);
void parse_prolog();
void parse_code();
void parse_f_def();
void parse_params_in();
void parse_param();
void parse_next_params();
void parse_type();
void parse_next_param();
void parse_ret_type();
void parse_line();
void parse_var_dec();
void parse_re_type();
void parse_expression();
void parse_precedence_expression();
void parse_ifj_call();
void parse_fac_call();
void parse_param_send();
void parse_next_send();
void parse_call();
void parse_if();
void parse_if_more();
void parse_while();
void parse_while_more();
void parse_return();
void parse_condition();

// Typ symbolu podle precedenční tabulky
typedef enum
{
    VALUE,      // i
    PLUS,       // +
    MINUS,      // -
    MULTIPLY,   // *
    DIVIDE,     // /
    LPAREN,     // (
    RPAREN,     // )
    DOLLAR,     // $ imaginární token konce a začátku
    ALL_SYMBOLS // Počet symbolů (pro indexování)
} SymbolType;

// Ruzny hodnoty i at vim typf
typedef enum
{
    INT,
    FLOAT,
    ID,
} ValueType;

// Jeden symbol zasobniku
typedef struct
{
    SymbolType type;
    union
    {
        int int_value;
        double float_value;
        char *id_value;
    };
    bool stop;
    bool skip;
    ValueType val_type;
} StackSymbol;

// Precedence
typedef enum
{
    EQUAL,
    LESS,
    GREATER,
    INVALID,
} Precedence;

// Upravená precedenční tabulka
Precedence precedenceTable[ALL_SYMBOLS][ALL_SYMBOLS] = {
    ////////////     i        +         -         *         /         (         )         $   /////////////////////////
    /* i      */ {INVALID, GREATER, GREATER, GREATER, GREATER, INVALID, GREATER, GREATER},
    /* +      */ {LESS, GREATER, GREATER, LESS, LESS, LESS, GREATER, GREATER},
    /* -      */ {LESS, GREATER, GREATER, LESS, LESS, LESS, GREATER, GREATER},
    /* *      */ {LESS, GREATER, GREATER, GREATER, GREATER, LESS, GREATER, GREATER},
    /* /      */ {LESS, GREATER, GREATER, GREATER, GREATER, LESS, GREATER, GREATER},
    /* (      */ {LESS, LESS, LESS, LESS, LESS, LESS, EQUAL, INVALID},
    /* )      */ {INVALID, GREATER, GREATER, GREATER, GREATER, INVALID, GREATER, GREATER},
    /* $      */ {LESS, LESS, LESS, LESS, LESS, LESS, INVALID, EQUAL}};

// Funkce pro zjištění precedence
Precedence checkPrecedence(SymbolType row, SymbolType column)
{
    if (row < ALL_SYMBOLS && column < ALL_SYMBOLS)
    {
        return precedenceTable[row][column];
    }
    return INVALID; // Invalid je automaticky ERROR
}

typedef struct
{
    Node *nodes[STACK_MAX_SIZE];
    int latest;
} Current_StateStack;

typedef struct
{
    StackSymbol data[STACK_MAX_SIZE];
    int top;
} PrecedenceStack;

void stack_init(PrecedenceStack *stack)
{
    stack->top = -1;
}

int stack_is_empty(PrecedenceStack *stack)
{
    return stack->top == -1;
}

int stack_is_full(PrecedenceStack *stack)
{
    return stack->top == STACK_MAX_SIZE - 1;
}

void stack_push(PrecedenceStack *stack, StackSymbol symbol)
{
    if (stack_is_full(stack))
    {
        fprintf(stderr, "Stack overflow\n");
        exit(99);
    }
    stack->data[++stack->top] = symbol;
}

StackSymbol stack_pop(PrecedenceStack *stack)
{
    if (stack_is_empty(stack))
    {
        fprintf(stderr, "Stack underflow\n");
        exit(99);
    }
    return stack->data[stack->top--];
}

SymbolType stack_get_first_symbol(PrecedenceStack *stack)
{
    if (stack_is_empty(stack))
    {
        fprintf(stderr, "Stack is empty\n");
        exit(99);
    }
    int index = stack->top;
    while (stack->data[index].skip == true)
    {
        index--;
    }
    return stack->data[index].type;
}

StackSymbol stack_top(PrecedenceStack *stack)
{
    if (stack_is_empty(stack))
    {
        fprintf(stderr, "Stack is empty\n");
        exit(99);
    }
    return stack->data[stack->top];
}

void print_stack(PrecedenceStack *stack)
{
    printf("STACK: ");
    for (int i = 0; i < stack->top + 1; i++)
    {
        if (stack->data[i].skip)
        {
            printf("E");
        }
        else if (stack->data[i].stop)
        {
            printf("<");
        }
        else if (stack->data[i].type == VALUE)
        {
            printf("i");
        }
        else if (stack->data[i].type == PLUS)
        {
            printf("+");
        }
        else if (stack->data[i].type == MINUS)
        {
            printf("-");
        }
        else if (stack->data[i].type == MULTIPLY)
        {
            printf("*");
        }
        else if (stack->data[i].type == DIVIDE)
        {
            printf("/");
        }
        else if (stack->data[i].type == LPAREN)
        {
            printf("(");
        }
        else if (stack->data[i].type == RPAREN)
        {
            printf(")");
        }
        else if (stack->data[i].type == DOLLAR)
        {
            printf("$");
        }
    }
    printf("\n");
}

Token *current_token;
Token *temp_token;
bool temp_token_used = false;
Node *main_node;
Node *fn_node;
Node *param;
Node *condition;
Node *var_dec;
Node *expresion;
Node *call;
Current_StateStack current_state;
TYPE last_type;

void StateStack_init()
{
    current_state.latest = -1;
}

void StateStack_pop()
{
    current_state.latest--;
}

void StateStack_push(Node *node)
{
    current_state.latest++;
    current_state.nodes[current_state.latest] = node;
}

void AutoInsertNode(Node *node)
{
    InsertNode(current_state.nodes[current_state.latest], node);
}

void swap_tokens()
{
    Token *tmp = current_token;
    current_token = temp_token;
    temp_token = tmp;
}

void advance()
{
    // printf("%d\n", current_token->type);
    if (temp_token_used)
    {
        free(current_token);
        current_token = temp_token;
        temp_token_used = false;
    }
    else
    {
        free(current_token);
        current_token = getToken();
    }
}

void unexpToken()
{
    free(current_token);
    fprintf(stderr, "Unexpected Token! Syntax error.");
    exit(2);
}

void match(TokenType expected, KeyType expected2)
{
    if (current_token->type == expected)
    {
        if (expected == TOKEN_KEY)
        {
            matchKey(expected2);
        }
        else
        {
            advance();
        }
    }
    else
    {
        unexpToken();
    }
}
void matchKey(KeyType expected)
{
    if (current_token->key_value == expected)
    {
        advance();
    }
    else
    {
        unexpToken();
    }
}

bool check(TokenType expected, KeyType expected2)
{
    if (current_token->type == expected)
    {
        if (expected == TOKEN_KEY)
        {
            return checkKey(expected2);
        }
        else
        {
            return true;
        }
    }
    else
    {
        return false;
    }
}
bool checkKey(KeyType expected)
{
    if (current_token->key_value == expected)
    {
        return true;
    }
    else
    {
        return false;
    }
}
void parse_prolog()
{
    match(TOKEN_KEY, KEY_CONST);
    match(TOKEN_KEY, KEY_IFJ);
    match(TOKEN_EQUAL, NOT_KEY);
    match(TOKEN_KEY, KEY_IMPORT);
    match(TOKEN_LEFT_PAREN, NOT_KEY);
    if (strcmp(current_token->value, "ifj24.zig") != 0)
    {
        unexpToken();
    }
    match(TOKEN_STRING, NOT_KEY);
    match(TOKEN_RIGHT_PAREN, NOT_KEY);
    match(TOKEN_SEMICOLON, NOT_KEY);
}
void parse_code()
{
    if (check(TOKEN_KEY, KEY_PUB))
    {
        parse_f_def();
        parse_code();
    }
    else if (check(TOKEN_EOF, NOT_KEY))
    {
        return;
    }
    else
    {
        unexpToken();
    }
}

void parse_f_def()
{
    match(TOKEN_KEY, KEY_PUB);
    match(TOKEN_KEY, KEY_FN);
    if (check(TOKEN_IDENTIFIER, NOT_KEY))
    {
        fn_node = createFunctionNode(current_token->value, TYPE_NONE, NODE_FUNCTION);
    }
    StateStack_push(fn_node);
    match(TOKEN_IDENTIFIER, NOT_KEY);
    match(TOKEN_LEFT_PAREN, NOT_KEY);
    parse_params_in();
    match(TOKEN_RIGHT_PAREN, NOT_KEY);
    parse_ret_type();
    match(TOKEN_LEFT_BRACE, NOT_KEY);
    parse_line();
    match(TOKEN_RIGHT_BRACE, NOT_KEY);
    InsertNode(main_node, fn_node);
    StateStack_pop();
}
void parse_params_in()
{
    if (check(TOKEN_IDENTIFIER, NOT_KEY))
    {
        parse_param();
        parse_next_params();
    }
}

void parse_param()
{
    param = createParameterNode(current_token->value, TYPE_NONE, NODE_PARAMETER);
    match(TOKEN_IDENTIFIER, NOT_KEY);
    match(TOKEN_DOUBLE_DOT, NOT_KEY);
    parse_type();
    InsertParamNode(fn_node, param);
}

void parse_type()
{
    bool qmark = false;
    if (check(TOKEN_QMARK, NOT_KEY))
    {
        qmark = true;
        match(TOKEN_QMARK, NOT_KEY);
    }
    if (check(TOKEN_KEY, KEY_F64))
    {
        if (qmark)
        {
            last_type = TYPE_F64_NULL;
        }
        else
        {
            last_type = TYPE_F64;
        }
        match(TOKEN_KEY, KEY_F64);
    }
    else if (check(TOKEN_KEY, KEY_I32))
    {
        if (qmark)
        {
            last_type = TYPE_I32_NULL;
        }
        else
        {
            last_type = TYPE_I32;
        }
        match(TOKEN_KEY, KEY_I32);
    }
    else if (check(TOKEN_LEFT_BRACKET, NOT_KEY))
    {
        match(TOKEN_LEFT_BRACKET, NOT_KEY);
        match(TOKEN_RIGHT_BRACKET, NOT_KEY);
        match(TOKEN_KEY, KEY_U8);
        if (qmark)
        {
            last_type = TYPE_U8_NULL;
        }
        else
        {
            last_type = TYPE_U8;
        }
    }
    else
    {
        unexpToken();
    }
}
void parse_next_params()
{
    if (check(TOKEN_COMMA, NOT_KEY))
    {
        match(TOKEN_COMMA, NOT_KEY);
        parse_next_param();
    }
}
void parse_next_param()
{
    parse_params_in();
}
void parse_ret_type()
{
    if (check(TOKEN_KEY, KEY_VOID))
    {

        last_type = TYPE_VOID;
        match(TOKEN_KEY, KEY_VOID);
    }
    else
    {
        parse_type();
    }
    fn_node->data.function.return_type = last_type;
}

void parse_line()
{
    if (check(TOKEN_KEY, KEY_CONST) || check(TOKEN_KEY, KEY_VAR))
    {
        parse_var_dec();
        match(TOKEN_SEMICOLON, NOT_KEY);
        parse_line();
    }
    else if (check(TOKEN_KEY, KEY_IFJ))
    {
        parse_ifj_call();
        match(TOKEN_SEMICOLON, NOT_KEY);
        parse_line();
    }
    else if (check(TOKEN_IDENTIFIER, NOT_KEY))
    {
        parse_call();
        match(TOKEN_SEMICOLON, NOT_KEY);
        parse_line();
    }
    else if (check(TOKEN_KEY, KEY_IF))
    {
        parse_if();
        parse_line();
    }
    else if (check(TOKEN_KEY, KEY_WHILE))
    {
        parse_while();
        parse_line();
    }
    else if (check(TOKEN_KEY, KEY_RETURN))
    {
        parse_return();
        match(TOKEN_SEMICOLON, NOT_KEY);
        parse_line();
    }
}
void parse_var_dec()
{
    VariableType var_type;
    if (check(TOKEN_KEY, KEY_CONST))
    {
        match(TOKEN_KEY, KEY_CONST);
        var_type = 1;
    }
    else if (check(TOKEN_KEY, KEY_VAR))
    {
        match(TOKEN_KEY, KEY_VAR);
        var_type = 0;
    }
    var_dec = createVarDeclarationNode(current_token->value, TYPE_NONE, NULL, NODE_VARIABLE_DECLARATION);
    var_dec->data.varDecl.var_type = var_type;
    match(TOKEN_IDENTIFIER, NOT_KEY);
    parse_re_type();
    match(TOKEN_EQUAL, NOT_KEY);
    AutoInsertNode(var_dec);
    parse_expression();
    var_dec->data.varDecl.expression = expresion;
}
void parse_re_type()
{
    if (check(TOKEN_DOUBLE_DOT, NOT_KEY))
    {
        match(TOKEN_DOUBLE_DOT, NOT_KEY);
        parse_type();
        var_dec->data.varDecl.type = last_type;
    }
}

// Precedencni analyza vyrazu
void parse_precedence_expression()
{
    if (temp_token_used)
    {
        swap_tokens();
    }
    PrecedenceStack stack;
    Current_StateStack expr_nodes;
    expr_nodes.latest = -1;
    stack_init(&stack);
    StackSymbol symbol;
    symbol.skip = false;
    symbol.stop = false;
    symbol.type = DOLLAR;
    stack_push(&stack, symbol); // Nahraju pocatecni dollar
    bool expr_empty = true;
    int cnt_parens = 0;
    bool expr_end = false;
    bool loop_end = false;
    while (!loop_end)
    {
        StackSymbol symbol;
        symbol.skip = false;
        symbol.stop = false;
        // print_stack(&stack);
        if (!expr_end)
        {
            switch (current_token->type)
            {
            case TOKEN_IDENTIFIER:
            {
                symbol.type = VALUE;
                symbol.val_type = ID;
                symbol.id_value = current_token->value;
                expr_empty = false;
            }
            break;
            case TOKEN_INTEGER:
            {
                symbol.type = VALUE;
                symbol.val_type = INT;
                symbol.int_value = current_token->int_value;
                expr_empty = false;
            }
            break;
            case TOKEN_FLOAT:
            {
                symbol.type = VALUE;
                symbol.val_type = FLOAT;
                symbol.float_value = current_token->float_value;
                expr_empty = false;
            }
            break;
            case TOKEN_PLUS:
            {
                symbol.type = PLUS;
            }
            break;
            case TOKEN_MINUS:
            {
                symbol.type = MINUS;
            }
            break;
            case TOKEN_STAR:
            {
                symbol.type = MULTIPLY;
            }
            break;
            case TOKEN_SLASH:
            {
                symbol.type = DIVIDE;
            }
            break;
            case TOKEN_LEFT_PAREN:
            {
                symbol.type = LPAREN;
                cnt_parens++;
            }
            break;
            case TOKEN_RIGHT_PAREN:
            {
                if (cnt_parens == 0 && !expr_empty)
                {
                    expr_end = true;
                    break;
                }
                else
                {
                    symbol.type = RPAREN;
                }
            }
            break;
            default:
            {
                if (current_token->type == TOKEN_SEMICOLON)
                {
                    expr_end = true;
                    break;
                }
                else if (check(TOKEN_DOUBLE_EQUAL, NOT_KEY) || check(TOKEN_NOT_EQUAL, NOT_KEY) || check(TOKEN_GREATER, NOT_KEY) || check(TOKEN_GREATER_EQUAL, NOT_KEY) || check(TOKEN_LESS, NOT_KEY) || check(TOKEN_LESS_EQUAL, NOT_KEY))
                {
                    expr_end = true;
                    break;
                }
                else
                {
                    unexpToken();
                }
            }
            } // Nalezen symbol
        }
        if (expr_end)
        {
            symbol.type = DOLLAR;
            symbol.skip = false;
            symbol.stop = false;
        }
        Precedence prcd = checkPrecedence(stack_get_first_symbol(&stack), symbol.type);
        /*
        if (prcd == 0) printf("EQUAL\n");
        if (prcd == 1) printf("LESS\n");
        if (prcd == 2) printf("GREATER\n");
        if (prcd == 3){
            printf("INVALID\n");
            printf("Stack:%d Symbol:%d\n", stack_get_first_symbol(&stack), symbol.type);
        }
        */
        if (prcd == LESS)
        {
            StackSymbol temp = stack_top(&stack);
            if (temp.skip == true)
            {
                // Na topu je E
                temp = stack_pop(&stack);
                StackSymbol temp_symbol;
                temp_symbol.stop = true;
                temp_symbol.skip = false;
                stack_push(&stack, temp_symbol);
                stack_push(&stack, temp);
                stack_push(&stack, symbol);
            }
            else
            { // Na topu neni E, takze tam nahraju rovnou <i
                StackSymbol temp_symbol;
                temp_symbol.stop = true;
                temp_symbol.skip = false;
                stack_push(&stack, temp_symbol);
                stack_push(&stack, symbol);
            }
            advance();
        }
        else if (prcd == GREATER)
        {
            // REDUKCE: Odstraňujeme symboly a redukujeme
            StackSymbol top_symbol;
            StackSymbol reduced_symbol;

            do
            { // Hledame pravidla pro redukci
                top_symbol = stack_pop(&stack);
                if (top_symbol.skip)
                {
                    if (stack_top(&stack).type == PLUS)
                    {                                         // <E + E pravidlo?
                        StackSymbol op = stack_pop(&stack);   // Odeber operátor
                        StackSymbol left = stack_pop(&stack); // leve E
                        // Zkontroluj, zda je pravidlo správné
                        if (left.skip == false || top_symbol.skip == false)
                        {
                            unexpToken();
                        }
                        StackSymbol check = stack_pop(&stack);
                        if (!check.stop)
                        { // Kontrola < pred redukci
                            unexpToken();
                        }
                        Node *current_expression = createExpressionNode(OP_PLUS, expr_nodes.nodes[expr_nodes.latest - 1], expr_nodes.nodes[expr_nodes.latest], NODE_EXPRESSION);
                        expr_nodes.nodes[--expr_nodes.latest] = current_expression;
                    }
                    else if (stack_top(&stack).type == MINUS)
                    {                                         // <E - E pravidlo?
                        StackSymbol op = stack_pop(&stack);   // Odeber operátor
                        StackSymbol left = stack_pop(&stack); // leve E
                        // Zkontroluj, zda je pravidlo správné
                        if (left.skip == false || top_symbol.skip == false)
                        {
                            unexpToken();
                        }
                        StackSymbol check = stack_pop(&stack);
                        if (!check.stop)
                        { // Kontrola < pred redukci
                            unexpToken();
                        }
                        Node *current_expression = createExpressionNode(OP_MINUS, expr_nodes.nodes[expr_nodes.latest - 1], expr_nodes.nodes[expr_nodes.latest], NODE_EXPRESSION);
                        expr_nodes.nodes[--expr_nodes.latest] = current_expression;
                    }
                    else if (stack_top(&stack).type == MULTIPLY)
                    {                                         // <E * E pravidlo?
                        StackSymbol op = stack_pop(&stack);   // Odeber operátor
                        StackSymbol left = stack_pop(&stack); // leve E
                        // Zkontroluj, zda je pravidlo správné
                        if (left.skip == false || top_symbol.skip == false)
                        {
                            unexpToken();
                        }
                        StackSymbol check = stack_pop(&stack);
                        if (!check.stop)
                        { // Kontrola < pred redukci
                            unexpToken();
                        }
                        Node *current_expression = createExpressionNode(OP_STAR, expr_nodes.nodes[expr_nodes.latest - 1], expr_nodes.nodes[expr_nodes.latest], NODE_EXPRESSION);
                        expr_nodes.nodes[--expr_nodes.latest] = current_expression;
                    }
                    else if (stack_top(&stack).type == DIVIDE)
                    {                                         // <E / E pravidlo?
                        StackSymbol op = stack_pop(&stack);   // Odeber operátor
                        StackSymbol left = stack_pop(&stack); // leve E
                        // Zkontroluj, zda je pravidlo správné
                        if (left.skip == false || top_symbol.skip == false)
                        {
                            unexpToken();
                        }
                        StackSymbol check = stack_pop(&stack);
                        if (!check.stop)
                        { // Kontrola < pred redukci
                            unexpToken();
                        }
                        Node *current_expression = createExpressionNode(OP_SLASH, expr_nodes.nodes[expr_nodes.latest - 1], expr_nodes.nodes[expr_nodes.latest], NODE_EXPRESSION);
                        expr_nodes.nodes[--expr_nodes.latest] = current_expression;
                    }
                }
                else if (top_symbol.type == VALUE) // cisty E
                {
                    Node *factor = createFactorNode(NULL, 0, 0.0, NULL, TYPE_NONE, NODE_FACTOR);
                    if (top_symbol.val_type == INT)
                    {
                        factor->data.factorNode.value.i32 = top_symbol.int_value;
                        factor->data.factorNode.factorType = TYPE_I32;
                    }
                    else if (top_symbol.val_type == FLOAT)
                    {
                        factor->data.factorNode.value.f64 = top_symbol.float_value;
                        factor->data.factorNode.factorType = TYPE_F64;
                    }
                    else if (top_symbol.val_type == ID)
                    {
                        factor->data.factorNode.id = top_symbol.id_value;
                    }
                    expr_nodes.nodes[++expr_nodes.latest] = factor;
                    StackSymbol check = stack_pop(&stack);
                    if (!check.stop)
                    { // Na vrcholu bylo i, ale pred nim ne <
                        unexpToken();
                    }
                    break;
                }
                else if (top_symbol.type == RPAREN)
                { // <(E)
                    StackSymbol check = stack_pop(&stack);
                    if (!check.skip)
                    { // Na vrcholu bylo ), ale pred nim ne (E
                        unexpToken();
                    }
                    check = stack_pop(&stack);
                    if (check.type != LPAREN)
                    { // Na vrcholu bylo ), ale pred nim ne (E
                        unexpToken();
                    }
                    check = stack_pop(&stack);
                    if (!check.stop)
                    {
                        unexpToken();
                    }
                    break;
                }
            } while (!top_symbol.stop);

            // Po redukci vlož nový symbol E
            reduced_symbol.skip = true;         // Označ, že jde o redukovaný symbol E
            stack_push(&stack, reduced_symbol); // Vlož zpět na zásobník
        }
        else if (prcd == EQUAL)
        {
            if (symbol.type == RPAREN)
            {
                stack_push(&stack, symbol);
                cnt_parens--;
                advance();
            }
            else if (symbol.type == DOLLAR && !expr_empty)
            {
                loop_end = true;
                expresion = expr_nodes.nodes[0];
            }
        }
        else
        {
            unexpToken();
        }
    }
}
void parse_expression()
{
    if (check(TOKEN_KEY, KEY_IFJ))
    {
        match(TOKEN_KEY, KEY_IFJ);
        match(TOKEN_DOT, NOT_KEY);
        call = createCallNode(current_token->value, true, NODE_CALL);
        match(TOKEN_IDENTIFIER, NOT_KEY);
        match(TOKEN_LEFT_PAREN, NOT_KEY);
        parse_param_send();
        match(TOKEN_RIGHT_PAREN, NOT_KEY);
        expresion = call;
        return;
    }
    else if (check(TOKEN_KEY, KEY_NULL))
    {
        match(TOKEN_KEY, KEY_NULL);
        Node *factor = createFactorNode(NULL, 0, 0.0, NULL, TYPE_NULL, NODE_FACTOR);
        expresion = factor;
        return;
    }
    else if (check(TOKEN_STRING, NOT_KEY))
    {
        Node *factor = createFactorNode(NULL, 0, 0.0, current_token->value, TYPE_U8, NODE_FACTOR);
        expresion = factor;
        match(TOKEN_STRING, NOT_KEY);
        return;
    }
    else if (check(TOKEN_IDENTIFIER, NOT_KEY))
    {
        temp_token = current_token;
        current_token = getToken(); // Kouknu se na dalsi token
        temp_token_used = true;
        if (check(TOKEN_LEFT_PAREN, NOT_KEY))
        {
            temp_token_used = false;
            parse_fac_call();
            expresion = call;
            return;
        }
    }
    parse_precedence_expression();
}
void parse_ifj_call()
{
    match(TOKEN_KEY, KEY_IFJ);
    match(TOKEN_DOT, NOT_KEY);
    call = createCallNode(current_token->value, true, NODE_CALL);
    match(TOKEN_IDENTIFIER, NOT_KEY);
    match(TOKEN_LEFT_PAREN, NOT_KEY);
    parse_param_send();
    match(TOKEN_RIGHT_PAREN, NOT_KEY);
    AutoInsertNode(call);
}
void parse_fac_call()
{
    call = createCallNode(temp_token->value, false, NODE_CALL);
    free(temp_token);
    match(TOKEN_LEFT_PAREN, NOT_KEY);
    parse_param_send();
    match(TOKEN_RIGHT_PAREN, NOT_KEY);
    AutoInsertNode(call);
}
void parse_param_send()
{
    Node *param_send = createFactorNode(NULL, 0, 0.0, NULL, TYPE_NONE, NODE_FACTOR);
    if (check(TOKEN_IDENTIFIER, NOT_KEY))
    {
        param_send->data.factorNode.id = current_token->value;
        InsertCallArgument(call, param_send);
        match(TOKEN_IDENTIFIER, NOT_KEY);
        parse_next_send();
    }
    else if (check(TOKEN_INTEGER, NOT_KEY))
    {
        param_send->data.factorNode.value.i32 = current_token->int_value;
        param_send->data.factorNode.factorType = TYPE_I32;
        InsertCallArgument(call, param_send);
        match(TOKEN_INTEGER, NOT_KEY);
        parse_next_send();
    }
    else if (check(TOKEN_FLOAT, NOT_KEY))
    {
        param_send->data.factorNode.value.f64 = current_token->float_value;
        param_send->data.factorNode.factorType = TYPE_F64;
        InsertCallArgument(call, param_send);
        match(TOKEN_FLOAT, NOT_KEY);
        parse_next_send();
    }
    else if (check(TOKEN_STRING, NOT_KEY))
    {
        param_send->data.factorNode.value.u8 = current_token->value;
        param_send->data.factorNode.factorType = TYPE_U8;
        InsertCallArgument(call, param_send);
        match(TOKEN_STRING, NOT_KEY);
        parse_next_send();
    }
}
void parse_next_send()
{
    if (check(TOKEN_COMMA, NOT_KEY))
    {
        match(TOKEN_COMMA, NOT_KEY);
        parse_param_send();
    }
}
void parse_call()
{
    char *name = current_token->value;
    match(TOKEN_IDENTIFIER, NOT_KEY);
    if (check(TOKEN_EQUAL, NOT_KEY))
    {
        match(TOKEN_EQUAL, NOT_KEY);
        parse_expression();
        Node *init = createVarInitializationNode(name, TYPE_NONE, expresion, NODE_VARIABLE_INITIALIZATION);
        AutoInsertNode(init);
    }
    else if (check(TOKEN_LEFT_PAREN, NOT_KEY))
    {
        call = createCallNode(name, false, NODE_CALL);
        match(TOKEN_LEFT_PAREN, NOT_KEY);
        parse_param_send();
        match(TOKEN_RIGHT_PAREN, NOT_KEY);
        AutoInsertNode(call);
    }
    else
    {
        unexpToken();
    }
}

void parse_if()
{
    Node *if_node = createIfNode(NULL, NULL, NULL, NODE_IF);
    StateStack_push(if_node);
    match(TOKEN_KEY, KEY_IF);
    match(TOKEN_LEFT_PAREN, NOT_KEY);
    parse_condition();
    if_node->data.ifNode.condition = condition;
    match(TOKEN_RIGHT_PAREN, NOT_KEY);
    if (check(TOKEN_VERTICAL_BAR, NOT_KEY))
    {
        match(TOKEN_VERTICAL_BAR, NOT_KEY);
        if_node->data.ifNode.id_null = current_token->value;
        match(TOKEN_IDENTIFIER, NOT_KEY);
        match(TOKEN_VERTICAL_BAR, NOT_KEY);
    }
    match(TOKEN_LEFT_BRACE, NOT_KEY);
    Node *if_body = createIfBodyNode(NODE_IF_BODY);
    int if_counter = if_body->data.ifBody.cnt;
    InsertNode(if_node, if_body);
    StateStack_push(if_body);
    parse_line();
    match(TOKEN_RIGHT_BRACE, NOT_KEY);
    StateStack_pop();

    Node *else_body = createElseBodyNode(NODE_ELSE_BODY); // ELSE
    else_body->data.elseBody.cnt = if_counter;
    StateStack_push(else_body);
    InsertNode(if_node, else_body);
    match(TOKEN_KEY, KEY_ELSE);
    match(TOKEN_LEFT_BRACE, NOT_KEY);
    parse_line();
    match(TOKEN_RIGHT_BRACE, NOT_KEY);
    StateStack_pop();
    StateStack_pop();
    AutoInsertNode(if_node);
}

void parse_while()
{
    Node *while_node = createWhileNode(NULL, NULL, NULL, NODE_WHILE);
    StateStack_push(while_node);
    match(TOKEN_KEY, KEY_WHILE);
    match(TOKEN_LEFT_PAREN, NOT_KEY);
    parse_condition();
    while_node->data.whileNode.condition = condition;
    match(TOKEN_RIGHT_PAREN, NOT_KEY);
    if (check(TOKEN_VERTICAL_BAR, NOT_KEY))
    {
        match(TOKEN_VERTICAL_BAR, NOT_KEY);
        while_node->data.whileNode.id_null = current_token->value;
        match(TOKEN_IDENTIFIER, NOT_KEY);
        match(TOKEN_VERTICAL_BAR, NOT_KEY);
    }
    match(TOKEN_LEFT_BRACE, NOT_KEY);
    parse_line();
    match(TOKEN_RIGHT_BRACE, NOT_KEY);
    StateStack_pop();
    AutoInsertNode(while_node);
}

void parse_return()
{
    Node *ret = createReturnNode(NODE_RETURN);
    match(TOKEN_KEY, KEY_RETURN);
    if (check(TOKEN_SEMICOLON, NOT_KEY))
    {
        return;
    }
    parse_expression();
    ret->data.returnNode.expression = expresion;
    AutoInsertNode(ret);
}
void parse_condition()
{
    condition = createConditionNode(NULL, OP_EQUAL, NULL, NODE_CONDITION);
    parse_expression();
    condition->data.conditionNode.leftExpression = expresion;
    // Nejak dodelat operator
    if (check(TOKEN_DOUBLE_EQUAL, NOT_KEY) || check(TOKEN_NOT_EQUAL, NOT_KEY) || check(TOKEN_GREATER, NOT_KEY) || check(TOKEN_GREATER_EQUAL, NOT_KEY) || check(TOKEN_LESS, NOT_KEY) || check(TOKEN_LESS_EQUAL, NOT_KEY))
    {
        if (current_token->type == TOKEN_DOUBLE_EQUAL)
            condition->data.conditionNode.operator= OP_EQUAL;
        else if (current_token->type == TOKEN_NOT_EQUAL)
            condition->data.conditionNode.operator= OP_NOT_EQUAL;
        else if (current_token->type == TOKEN_GREATER)
            condition->data.conditionNode.operator= OP_GREATER;
        else if (current_token->type == TOKEN_GREATER_EQUAL)
            condition->data.conditionNode.operator= OP_GREATER_EQUAL;
        else if (current_token->type == TOKEN_LESS)
            condition->data.conditionNode.operator= OP_LESS;
        else if (current_token->type == TOKEN_LESS_EQUAL)
            condition->data.conditionNode.operator= OP_LESS_EQUAL;
        advance(); // Mozna predelat na match?
        parse_expression();
        condition->data.conditionNode.rightExpression = expresion;
    }
}
int main()
{
    StateStack_init();
    current_token = getToken();
    parse_prolog();
    main_node = createNode(NODE_MAIN);
    parse_code();
    compile(main_node);
    return 0;
}