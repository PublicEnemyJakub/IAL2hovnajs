#include <stdbool.h>
#include "tree.h"

#ifndef _GENERATOR_H
#define _GENERATOR_H

bool gen_header();

bool gen_flush();

bool gen_footer();

bool gen_main_start();

bool gen_main_end();

bool gen_built_in_function();

bool gen_local_var_def(char *data, unsigned int cnt);

bool gen_null_var(const char *id_bez_null, unsigned int cnt_scope);

bool gen_local_var_init(char *data, unsigned int cnt);

bool gen_label(const char *function_id);

bool gen_function_start(F_DEF data);

bool gen_function_params_frame();

bool gen_param_in(FACTOR data, unsigned int cnt);

bool gen_function_param(PARAMS_IN data, unsigned int cnt);

bool gen_function_end(F_DEF data);

bool gen_return();

bool gen_call(char *data);

bool gen_if_defaultstart(unsigned int cnt);

bool gen_if_nullstart(unsigned int cnt, const char *id_bez_null, unsigned int cnt_scope);

bool gen_if_start(unsigned int cnt);

bool gen_while_after_exp(unsigned int cnt);

bool gen_while_afternull(unsigned int cnt, const char *id_bez_null, unsigned int cnt_scope);

bool gen_if_end(unsigned int cnt);

bool gen_if_tmp(unsigned int cnt);

bool gen_while_tmp(unsigned int cnt);

bool gen_if_else_start(unsigned int cnt);

bool gen_if_else_end(unsigned int cnt);

bool gen_while_start(unsigned int cnt);

bool gen_while_startnull(unsigned int cnt);

bool gen_while_end(unsigned int cnt);

bool gen_pushs_prom(char *id, unsigned int cnt);

bool gen_pushs_literal(FACTOR data);

bool gen_literal_conversion_i2f();

bool gen_literal_conversion_f2i();

bool gen_pops_tmp();

bool gen_pushs_tmp();

bool gen_operation(OPERATOR_TYPE op);

bool gen_stack_operation(OPERATOR_TYPE st_op);

void process_ast(Node *node);

#endif