#ifndef SEM_H
#define SEM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

int sem_analysis_fn(Node *ast_root);
const char *ast_data_type_to_string(TYPE type);
const char *ast_operator_type_to_string(OPERATOR_TYPE type);
const char *ast_variable_type_to_string(VariableType type);
void process_param_in(Node *arg);
TYPE evaluateExpressionType(Node *node);
void literal_conversion(Node *node);
void process_ast(Node *node);

#endif // SEM_H