#ifndef SEM_H
#define SEM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

int sem_analysis_fn(Node *ast_root);
const char *ast_node_type_to_string(NodeType type);
const char *ast_data_type_to_string(TYPE type);
const char *ast_operator_type_to_string(OPERATOR_TYPE type);
const char *ast_variable_type_to_string(VariableType type);

#endif // SEM_H