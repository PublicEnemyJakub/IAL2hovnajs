#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "symtable.h"

int max(int a, int b) {
    return (a > b) ? a : b;
}

int height(AVLNode *node) {
    if (node == NULL)
        return 0;
    return node->height;
}

AVLNode *createAVLNode(Symbol *symbol) {
    AVLNode *node = (AVLNode *)malloc(sizeof(AVLNode));
    node->symbol = symbol;
    node->left = node->right = NULL;
    node->height = 1;
    return node;
}

AVLNode *rightRotate(AVLNode *y) {
    AVLNode *x = y->left;
    AVLNode *T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;

    return x;
}

AVLNode *leftRotate(AVLNode *x) {
    AVLNode *y = x->right;
    AVLNode *T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return y;
}

int getBalance(AVLNode *node) {
    if (node == NULL)
        return 0;
    return height(node->left) - height(node->right);
}

AVLNode *insert(AVLNode *node, Symbol *symbol) {
    if (node == NULL)
        return createAVLNode(symbol);

    if (strcmp(symbol->id, node->symbol->id) < 0)
        node->left = insert(node->left, symbol);
    else if (strcmp(symbol->id, node->symbol->id) > 0)
        node->right = insert(node->right, symbol);
    else // Duplicita není povolena
        return node;

    node->height = 1 + max(height(node->left), height(node->right));

    int balance = getBalance(node);

    // Levé levé
    if (balance > 1 && strcmp(symbol->id, node->left->symbol->id) < 0)
        return rightRotate(node);

    // Pravé pravé
    if (balance < -1 && strcmp(symbol->id, node->right->symbol->id) > 0)
        return leftRotate(node);

    // Levé pravé
    if (balance > 1 && strcmp(symbol->id, node->left->symbol->id) > 0) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    // Pravé levé
    if (balance < -1 && strcmp(symbol->id, node->right->symbol->id) < 0) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

Symbol *find(AVLNode *node, const char *id) {
    if (node == NULL)
        return NULL;

    if (strcmp(id, node->symbol->id) == 0)
        return node->symbol;
    else if (strcmp(id, node->symbol->id) < 0)
        return find(node->left, id);
    else
        return find(node->right, id);
}

Parameter *findParameter(Parameter *param, const char *name) {
    while (param != NULL) {
        if (strcmp(param->id, name) == 0) {
            return param;
        }
        param = param->next;
    }
    return NULL;
}

Symbol *createSymbol(const char *id, SymbolType type, TYPE dataType) {
    Symbol *symbol = (Symbol *)malloc(sizeof(Symbol));
    symbol->id = strdup(id);
    symbol->type = type;
    symbol->dataType = dataType;
    symbol->parameters = NULL; // Inicializace prázdného seznamu parametrů
    return symbol;
}

void addParameter(Symbol *funcSymbol, const char *paramid, TYPE paramDataType) {
    if (funcSymbol->type != FUNC) {
        printf("Chyba: Parametry lze přidávat pouze k funkcím.\n");
        return;
    }

    Parameter *newParam = (Parameter *)malloc(sizeof(Parameter));
    newParam->id = strdup(paramid);
    newParam->dataType = paramDataType;
    newParam->next = funcSymbol->parameters;
    funcSymbol->parameters = newParam;
}

void printParameters(Parameter *param) {
    while (param != NULL) {
        printf("    Parametr: %s, Typ: %d\n", param->id, param->dataType);
        param = param->next;
    }
}

void printSymbol(Symbol *symbol) {
    if (symbol == NULL) return;
    printf("Symbol: %s, Typ: %d, Datový typ: %d\n", symbol->id, symbol->type, symbol->dataType);
    if (symbol->type == FUNC) {
        printf("  Parametry:\n");
        printParameters(symbol->parameters);
    }
}

/*
int isBalanced(AVLNode *node) {
    if (node == NULL)
        return 1; // Prázdný strom je vyvážený

    int balance = getBalance(node);
    if (balance > 1 || balance < -1)
        return 0; // Pokud je rozdíl větší než 1 nebo menší než -1, strom není vyvážený

    // Rekurzivně kontroluj levý a pravý podstrom
    return isBalanced(node->left) && isBalanced(node->right);
}
*/

void insertToCurrentScope(Symbol *symbol, ScopeNode * scopeStack) {
    if (scopeStack == NULL) {
        printf("Chyba: Neexistuje žádný scope.\n");
        return;
    }
    scopeStack->symbolTree = insert(scopeStack->symbolTree, symbol);
}

ScopeNode * pushScope(ScopeNode *scopeStack) {
    ScopeNode *newScope = (ScopeNode *)malloc(sizeof(ScopeNode));
    newScope->symbolTree = NULL;
    newScope->next = scopeStack;
    return newScope;
}

ScopeNode * popScope(ScopeNode *scopeStack) {
    if (scopeStack == NULL) {
        printf("Chyba: Žádný scope k odstranění.\n");
        return NULL;
    }
    ScopeNode *temp = scopeStack->next;
    free(scopeStack);
    return temp;
}

Symbol *findInScopes(const char *name, ScopeNode *scopeStack) {
    ScopeNode *current = scopeStack;
    while (current != NULL) {
        Symbol *symbol = find(current->symbolTree, name);
        if (symbol != NULL) {
            return symbol;
        }
        AVLNode *node = current->symbolTree;
        while (node != NULL) {
            if (node->symbol->type == FUNC) {
                Parameter *param = findParameter(node->symbol->parameters, name);
                if (param != NULL) {
                    // Vytvoření dočasného symbolu pro parametr
                    Symbol *paramSymbol = createSymbol(param->id, VAR, param->dataType);
                    return paramSymbol;
                }
            }
            if (node->left) node = node->left;
            else node = node->right;
        }
        current = current->next;
    }
    return NULL;
}

void printSymbolTree(AVLNode *node, int level) {
    if (node == NULL) {
        return;
    }
    // Tisk pravého podstromu
    printSymbolTree(node->right, level + 1);
    
    // Tisk aktuálního uzlu s odsazením podle úrovně
    for (int i = 0; i < level; i++) {
        fprintf(stderr, "    ");
    }
    fprintf(stderr, "%s (Typ: %d)", node->symbol->id, node->symbol->type);
    
    // Tisk parametrů, pokud jde o funkci
    if (node->symbol->type == FUNC && node->symbol->parameters != NULL) {
        fprintf(stderr, ", Parametry: ");
        Parameter *param = node->symbol->parameters;
        while (param != NULL) {
            fprintf(stderr, "%s (Typ: %d)%s", param->id, param->dataType, param->next != NULL ? ", " : "");
            param = param->next;
        }
    }
    fprintf(stderr, "\n");

    // Tisk levého podstromu
    printSymbolTree(node->left, level + 1);
}

void printScopes(ScopeNode *scope) {
    int scopeLevel = 0;
    while (scope != NULL) {
        fprintf(stderr, "Scope Level %d:\n", scopeLevel);
        printSymbolTree(scope->symbolTree, 0);
        scope = scope->next;
        scopeLevel++;
    }
}


/*
int main() {

    scopeStackGlobal = pushScope(scopeStackGlobal);

    // Vytvoření a vložení symbolů do globálního scopu

    funcSymbol = createSymbol("main", FUNC, TYPE_VOID);
    insertToCurrentScope(funcSymbol, scopeStackGlobal);

    addParameter(funcSymbol, "a", TYPE_I32);
    addParameter(funcSymbol, "b", TYPE_F64);

    // Přidání nového scopu pro funkci "foo"
    scopeStackLocal = pushScope(scopeStackLocal);

    // Vytvoření lokálních proměnných pro funkci "foo"
    
    Symbol *localVar1 = createSymbol("skibid", VAR, TYPE_I32);
    insertToCurrentScope(localVar1, scopeStackLocal);

    Symbol *localVar2 = createSymbol("toilet", VAR, TYPE_F64);
    insertToCurrentScope(localVar2, scopeStackLocal);
    
    // Testování výpisu symbolů
    printf("Testování AVL stromu: \n");
    //printSymbol(findInScopes("x")); // Globální proměnná
    //printSymbol(findInScopes("PI")); // Globální konstanta
    printSymbol(findInScopes("main", scopeStackGlobal)); // Funkce
    printSymbol(findInScopes("skibid",scopeStackLocal)); // Lokální proměnná ve funkci "foo"
    printSymbol(findInScopes("toilet",scopeStackLocal)); // Lokální proměnná ve funkci "foo"

    printSymbol(findInScopes("a", scopeStackGlobal));

    // Vyhledání neexistujícího symbolu
    Symbol *notFoundSymbol = findInScopes("y", scopeStackLocal);
    if (notFoundSymbol == NULL) {
        printf("Symbol 'y' nenalezen\n");
    }

    
    // Odebrání lokálního scopu
    scopeStackLocal = pushScope(scopeStackLocal);


    funcSymbol = createSymbol("next_func", FUNC, TYPE_VOID);
    insertToCurrentScope(funcSymbol, scopeStackGlobal);

    addParameter(funcSymbol, "x", TYPE_I32);
    addParameter(funcSymbol, "d", TYPE_VOID);
    addParameter(funcSymbol, "lol", TYPE_VOID);

    
    // Vyhledání symbolu po odebrání lokálního scopu
    
    printSymbol(findInScopes("next_func", scopeStackGlobal));
    // Odebrání globálního scopu
    return 0;
}
*/