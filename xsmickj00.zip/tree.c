#include "tree.h"
#include <stdio.h>
#include <stdlib.h>
#include "sem_analysis.h"

Node *createNode(NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    return node;
}

// Function to create a new function node
Node *createFunctionNode(char *id, TYPE return_type, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.function.id = id;
    node->data.function.return_type = return_type;
    node->data.function.params = NULL;
    return node;
}

// Function to create a new parameter node
Node *createParameterNode(char *id, TYPE type, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.parameter.id = id;
    node->data.parameter.type = type;
    return node;
}

// Function to create a new variable declaration node
Node *createVarDeclarationNode(char *id, TYPE type, Node *expression, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.varDecl.id = id;
    node->data.varDecl.type = type;

    node->children = expression;
    return node;
}

// Function to create a new variable initialization node
Node *createVarInitializationNode(char *id, TYPE type, Node *expression, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.varDecl.id = id;
    node->data.varDecl.type = type;

    // Assign the expression as a child of this node
    node->data.varDecl.expression = expression;

    return node;
}

// Function to create a new operator node
Node *createExpressionNode(OPERATOR_TYPE operator, Node * leftOperand, Node *rightOperand, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    // Represent the operation and link operands
    node->data.expressionNode.operator= operator;
    node->children = leftOperand;

    if (leftOperand != NULL)
    {
        leftOperand->sibling = rightOperand;
    }

    return node;
}

// Function to create a new if node
Node *createIfNode(Node *condition, Node *exp_more, char *id_more, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    static unsigned int cnt = -1;
    cnt++;

    node->data.ifNode.condition = condition;
    node->data.ifNode.exp_null = exp_more;
    node->data.ifNode.id_null = id_more;
    node->data.ifNode.cnt = cnt;
    return node;
}

Node *createIfBodyNode(NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }

    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    static unsigned int cnt = -1;
    cnt++;
    node->data.ifBody.cnt = cnt;
    return node;
}

Node *createElseBodyNode(NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }

    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.elseBody.cnt = 0;
    return node;
}

// Function to create a new while node
Node *createWhileNode(Node *condition, Node *exp_more, char *id_more, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    static unsigned int cnt = -1;
    cnt++;
    node->data.whileNode.cnt = cnt;

    node->data.whileNode.condition = condition;
    node->data.whileNode.exp_null = exp_more;
    node->data.whileNode.id_null = id_more;
    return node;
}

// Function to create a new return node
Node *createReturnNode(NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;
    node->data.returnNode.expression = NULL;
    return node;
}

// Function to create a new call node
Node *createCallNode(char *id, bool buildin, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.callNode.id = id;
    node->data.callNode.isBuildin = buildin;
    node->data.callNode.args = NULL;
    return node;
}

// Function to create a new condition node
Node *createConditionNode(Node *leftExpression, OPERATOR_TYPE operator, Node * rightExpression, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.conditionNode.leftExpression = leftExpression;
    node->data.conditionNode.operator= operator;
    node->data.conditionNode.rightExpression = rightExpression;
    return node;
}

// Function to create a new factor node
Node *createFactorNode(char *id, int i32, double f64, char *u8, TYPE factorType, NodeType node_type)
{
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(EXIT_FAILURE);
    }
    node->type = node_type;
    node->sibling = NULL;
    node->children = NULL;

    node->data.factorNode.id = id;
    node->data.factorNode.factorType = factorType;
    if (factorType == TYPE_I32)
    {
        node->data.factorNode.value.i32 = i32;
    }
    else if (factorType == TYPE_F64)
    {
        node->data.factorNode.value.f64 = f64;
    }
    else if (factorType == TYPE_U8)
    {
        node->data.factorNode.value.u8 = strdup(u8);
    }
    return node;
}

bool InsertNode(Node *parent, Node *child)
{
    if (!parent || !child)
    {
        return false;
    }

    if (!parent->children)
    {
        // No children yet, set the child as the first child
        parent->children = child;
    }
    else
    {
        // Find the last sibling in the children list and add the new child at the end
        Node *current = parent->children;
        while (current->sibling)
        {
            current = current->sibling;
        }
        current->sibling = child;
    }

    return true;
}

bool InsertParamNode(Node *function, Node *param)
{
    if (!function || function->type != NODE_FUNCTION || !param || param->type != NODE_PARAMETER)
    {
        return false;
    }

    if (!function->data.function.params)
    {
        // No parameters yet, set the parameter as the first parameter
        function->data.function.params = param;
    }
    else
    {
        // Find the last parameter in the parameter list and add the new parameter at the end
        Node *current = function->data.function.params;
        while (current->sibling)
        {
            current = current->sibling;
        }
        current->sibling = param;
    }

    return true;
}

bool InsertCallArgument(Node *callNode, Node *arg)
{
    if (!callNode || callNode->type != NODE_CALL || !arg)
    {
        return false;
    }

    if (!callNode->data.callNode.args)
    {
        // No arguments yet, set the argument as the first argument
        callNode->data.callNode.args = arg;
    }
    else
    {
        // Find the last argument in the argument list and add the new argument at the end
        Node *current = callNode->data.callNode.args;
        while (current->sibling)
        {
            current = current->sibling;
        }
        current->sibling = arg;
    }

    return true;
}

void DeleteNode(Node *node)
{
    if (!node)
    {
        return;
    }

    // Delete children first
    Node *current = node->children;
    while (current)
    {
        Node *next = current->sibling;
        DeleteNode(current);
        current = next;
    }

    // If the node has allocated data (e.g., a string in the FactorNode), free it
    if (node->type == NODE_FACTOR && node->data.factorNode.factorType == TYPE_U8)
    {
        free(node->data.factorNode.value.u8);
    }

    // Free the node itself
    free(node);
}

void ast_print(Node *node, int depth)
{

    if (!node)
    {
        return;
    }

    for (int i = 0; i < depth; i++)
    {
        printf("    ");
    }

    printf("%s", ast_node_type_to_string(node->type));

    switch (node->type)
    {
    case NODE_FUNCTION:
        printf(" (Name: %s, Return Type: %s, Params: [\n",
               node->data.function.id,
               ast_data_type_to_string(node->data.function.return_type));
        ast_print(node->data.function.params, depth + 1);

        for (int i = 0; i < depth; i++)
        {
            printf("    ");
        }

        printf("])");
        break;
    case NODE_CALL:
        printf(" (Function Call: %s [\n", node->data.callNode.id);
        // Print the arguments for the function call
        Node *arg = node->data.callNode.args;
        while (arg)
        {
            ast_print(arg, depth + 1);
            arg = arg->sibling; // Traverse through all arguments (siblings)
        }
        for (int i = 0; i < depth; i++)
        {
            printf("    ");
        }
        printf("])\n");

        break;
    case NODE_PARAMETER:
        printf(" (Name: %s, Type: %s)", node->data.parameter.id, ast_data_type_to_string(node->data.parameter.type));

        printf("\n");
        ast_print(node->sibling, depth);
        return;
    case NODE_EXPRESSION:
        printf(" (Operator: %s [\n", ast_operator_type_to_string(node->data.expressionNode.operator));
        Node *operand = node->children;
        while (operand)
        {
            ast_print(operand, depth + 1);
            operand = operand->sibling; // Traverse through both operands (siblings)
        }
        for (int i = 0; i < depth; i++)
        {
            printf("    ");
        }
        printf("])\n");
        return;

    case NODE_RETURN:
        // Print the return expression
        ast_print(node->data.returnNode.expression, depth + 1);
        return;

    case NODE_VARIABLE_DECLARATION:
        printf(" (Type: %s, Variable Type: %s, Variable Name: %s) \n",
               ast_data_type_to_string(node->data.varDecl.type),
               ast_variable_type_to_string(node->data.varDecl.var_type),
               node->data.function.id);
        // node->data.varDecl.id ? node->data.varDecl.id : "NULL");
        ast_print(node->data.varDecl.expression, depth + 1);
        break;

    case NODE_IF:
        printf(" (Id_null: %s) ", node->data.ifNode.id_null);
        ast_print(node->data.ifNode.condition, depth + 1);
        break;

    case NODE_IF_BODY:
        printf(" (Counter: %d)", node->data.ifBody.cnt);
        break;

    case NODE_ELSE_BODY:
        printf(" (Counter: %d)", node->data.elseBody.cnt);
        break;

    case NODE_WHILE:
        printf(" (Id_null: %s) ", node->data.whileNode.id_null);
        ast_print(node->data.whileNode.condition, depth + 1);
        break;

    case NODE_CONDITION:
        printf(" (Left: [\n");
        ast_print(node->data.expressionNode.leftExpression, depth + 1);

        for (int i = 0; i < depth; i++)
        {
            printf("    ");
        }

        printf("], Operator: %s, Right: [\n", ast_operator_type_to_string(node->data.expressionNode.operator));

        ast_print(node->data.expressionNode.rightExpression, depth + 1);

        for (int i = 0; i < depth; i++)
        {
            printf("    ");
        }

        printf("])\n");
        break;
    case NODE_VARIABLE_INITIALIZATION:
        printf(" (Name: %s, Type: %s)\n", node->data.varDecl.id, ast_data_type_to_string(node->data.varDecl.type));
        // Print the initialization expression
        // ast_print(node->children, depth + 1);
        break;
    case NODE_FACTOR:
        printf(" (Factor Type: %s, ", ast_data_type_to_string(node->data.factorNode.factorType));
        if (node->data.factorNode.id != NULL)
        {
            // It's an identifier
            printf("Identifier: %s)\n", node->data.factorNode.id);
        }
        else
        {
            // It's a constant value
            if (node->data.factorNode.factorType == TYPE_I32)
            {
                printf("Value: %d)\n", node->data.factorNode.value.i32);
            }
            else if (node->data.factorNode.factorType == TYPE_F64)
            {
                printf("Value: %lf)\n", node->data.factorNode.value.f64);
            }
            else if (node->data.factorNode.factorType == TYPE_U8)
            {
                printf("Value: %s)\n", node->data.factorNode.value.u8);
            }
        }
        break;
    default:
        break;
    }

    printf("\n");

    Node *child = node->children;
    while (child)
    {
        ast_print(child, depth + 1);
        child = child->sibling;
    }
}
/*
int main()
{
    // Step 1: Create the root of the AST which will be a function definition
    Node *rootFunction = createFunctionNode("f", TYPE_VOID, NODE_FUNCTION); // main node

    // Step 2: Add parameters to the function
    Node *param1 = createParameterNode("a", TYPE_I32, NODE_PARAMETER);
    Node *param2 = createParameterNode("b", TYPE_F64, NODE_PARAMETER);
    InsertParamNode(rootFunction, param1);
    InsertParamNode(rootFunction, param2);

    // Step 3: Create a variable declaration and initialization inside the function body
    Node *varDecl = createVarDeclarationNode("x", TYPE_I32, NODE_VARIABLE_DECLARATION);
    InsertNode(rootFunction, varDecl);

    Node *varValue = createFactorNode(NULL, 10, 0.0, NULL, TYPE_I32, NODE_FACTOR);
    Node *varInit = createVarInitializationNode("x", TYPE_I32, varValue, NODE_VARIABLE_INITIALIZATION);
    InsertNode(rootFunction, varInit);

    // Step 4: Add a return statement returning a variable
    Node *returnNode = createReturnNode(NODE_RETURN);
    returnNode->data.returnNode.expression = createFactorNode("x", 0, 0.0, NULL, TYPE_I32, NODE_FACTOR);
    InsertNode(rootFunction, returnNode);

    // Step 5: Add a condition (if statement) to the function body
    Node *conditionExpr = createConditionNode(varValue, LESS, createFactorNode(NULL, 20, 0.0, NULL, TYPE_I32, NODE_FACTOR), NODE_CONDITION);
    Node *ifNode = createIfNode(conditionExpr, NODE_IF);
    InsertNode(rootFunction, ifNode);
    InsertNode(ifNode, conditionExpr);

    Node *body1 = createIfBodyNode(NODE_IF_BODY);
    InsertNode(ifNode, body1);

    Node *body2 = createElseBodyNode(NODE_ELSE_BODY);
    InsertNode(ifNode, body2);

    Node *vrValue = createFactorNode(NULL, 69, 0.0, NULL, TYPE_I32, NODE_FACTOR);
    Node *vrInit = createVarInitializationNode("L", TYPE_I32, vrValue, NODE_VARIABLE_INITIALIZATION);
    InsertNode(body1, vrInit);

    Node *fnc = createFunctionNode("F", TYPE_VOID, NODE_FUNCTION);
    InsertNode(body2, fnc);

    Node *param3 = createParameterNode("c", TYPE_I32, NODE_PARAMETER);
    Node *param4 = createParameterNode("d", TYPE_F64, NODE_PARAMETER);
    InsertParamNode(fnc, param3);
    InsertParamNode(fnc, param4);

    // Step 6: Add a loop (while statement) to the function body
    Node *whileCondition = createConditionNode(varValue, LESS_EQUAL, createFactorNode(NULL, 100, 0.0, NULL, TYPE_I32, NODE_FACTOR), NODE_CONDITION);
    Node *whileNode = createWhileNode(whileCondition, NODE_WHILE);
    InsertNode(rootFunction, whileNode);
    InsertNode(whileNode, whileCondition);

    Node *callNode = createCallNode("g", false, NODE_CALL); // This represents calling a function named 'g'
    InsertNode(rootFunction, callNode);
    Node *arg1 = createFactorNode(NULL, 42, 0.0, NULL, TYPE_I32, NODE_FACTOR);
    Node *arg2 = createFactorNode(NULL, 43, 0.0, NULL, TYPE_I32, NODE_FACTOR);
    InsertCallArgument(callNode, arg1);
    InsertCallArgument(callNode, arg2);

    Node *leftFactor = createFactorNode(NULL, 5, 0.0, NULL, TYPE_I32, NODE_FACTOR);
    Node *rightFactor = createFactorNode(NULL, 3, 0.0, NULL, TYPE_I32, NODE_FACTOR);
    Node *operatorNode = createOperatorNode(PLUS, leftFactor, rightFactor, NODE_OPERATOR);
    InsertNode(rootFunction, operatorNode);

    Node *leftId = createFactorNode("a", 0, 0.0, NULL, TYPE_I32, NODE_FACTOR);  // Identifier `a`
    Node *rightId = createFactorNode("b", 0, 0.0, NULL, TYPE_F64, NODE_FACTOR); // Identifier `b`
    Node *addIdsOperator = createOperatorNode(PLUS, leftId, rightId, NODE_OPERATOR);
    InsertNode(rootFunction, addIdsOperator);

    Node *callNode2 = createCallNode("g", false, NODE_CALL); // Create a new instance of the call node for use in an expression

    // Step 12: Add arguments to the second call node
    InsertCallArgument(callNode2, createFactorNode(NULL, 32, 0.0, NULL, TYPE_I32, NODE_FACTOR));
    InsertCallArgument(callNode2, createFactorNode(NULL, 0, 3.14, NULL, TYPE_F64, NODE_FACTOR));

    // Step 13: Create an operator node for a function call + constant (e.g., `g() + 5`)
    Node *constantFactor = createFactorNode(NULL, 5, 0.0, NULL, TYPE_I32, NODE_FACTOR); // Constant `5`
    Node *callPlusConstant = createOperatorNode(PLUS, callNode2, constantFactor, NODE_OPERATOR);
    InsertNode(rootFunction, callPlusConstant);

    // Step 7: Print the constructed AST
    printf("Abstract Syntax Tree:\n");
    ast_print(rootFunction, 0);

    // Clean up the allocated nodes
    DeleteNode(rootFunction);

    return 0;
}
*/