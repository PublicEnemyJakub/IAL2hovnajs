#ifndef SYMTABLE_H
#define SYMTABLE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tree.h"

// Typy symbolů
typedef enum { VAR, CONST, FUNC } SymbolType;

/*
typedef enum
{
    TYPE_NONE,
    TYPE_VOID,
    TYPE_U8,
    TYPE_I32,
    TYPE_F64,
    TYPE_U8_NULL,
    TYPE_I32_NULL,
    TYPE_F64_NULL,
} TYPE;
*/

typedef struct Parameter {
    char *id;
    TYPE dataType;
    struct Parameter *next;
} Parameter;

// Struktura symbolu
typedef struct Symbol {
    char *id;
    SymbolType type;
    // Další informace o symbolu, jako typ dat, hodnota, parametry funkce atd.
    TYPE dataType;
    Parameter *parameters;
} Symbol;


typedef struct AVLNode {
    Symbol *symbol;
    struct AVLNode *left;
    struct AVLNode *right;
    int height;
} AVLNode;

typedef struct ScopeNode {
    AVLNode *symbolTree;
    struct ScopeNode *next;
} ScopeNode;

int max(int a, int b);
int height(AVLNode *node);
AVLNode *createAVLNode(Symbol *symbol);
AVLNode *rightRotate(AVLNode *y);
AVLNode *leftRotate(AVLNode *x);
int getBalance(AVLNode *node);
AVLNode *insert(AVLNode *node, Symbol *symbol);
Symbol *find(AVLNode *node, const char *id);
Parameter *findParameter(Parameter *param, const char *name);
Symbol *createSymbol(const char *id, SymbolType type, TYPE dataType);
void addParameter(Symbol *funcSymbol, const char *paramid, TYPE paramDataType);
void printParameters(Parameter *param);
void printSymbol(Symbol *symbol);
void insertToCurrentScope(Symbol *symbol, ScopeNode *scopeStack);
ScopeNode * pushScope(ScopeNode *scopeStack);
ScopeNode * popScope(ScopeNode *scopeStack);
Symbol *findInScopes(const char *name, ScopeNode *scopeStack);
void printSymbolTree(AVLNode *node, int level);
void printScopes(ScopeNode *scope);


#endif // SYMTABLE_H