/*
Autoři: Ondřej Šustr - xsustro00 (celková konstrukce a většina funkcí)
        Jakub Smička - xsmickj00 (výsledné úpravy pro podporu scopování, správné chování if, while, countery)
*/
#include <stdio.h>
#include "dynamic_string.h"
#include "generator.h"
#include "built_in_function.h"
#include "tree.h"

Dynamic_string dyn_str;
OPERATOR_TYPE op;
TYPE type;
const char *function_id = "skibidi";
int label_depth = 1;
int label_index = 22;
bool gf_tmp_empty = true;

#define MAX_DIGITS_INT 40
#define MAX_DIGITS_FLOAT 512

// makro, přidá na konec dynamického stringu nový řádek a na něj zapíše string "_line"
#define ADD_LINE(_line)                                        \
    if (!dynamic_string_add_const_str(&dyn_str, ("\n" _line))) \
    return false

// makro, přidá na konec dynamického stringu string "_to"
#define ADD_TOLINE(_to)                               \
    if (!dynamic_string_add_const_str(&dyn_str, _to)) \
    return false

// makro, přidá na konec dynamického stringu celočíselní číslo "_to" ve formě stringu
#define ADD_INT(_to)              \
    do                            \
    {                             \
        char str[MAX_DIGITS_INT]; \
        sprintf(str, "%d", _to);  \
        ADD_TOLINE(str);          \
    } while (0)

// makro, přidá na konec dynamického stringu desetinné číslo "_to" ve formě stringu
#define ADD_FLOAT(_to)              \
    do                              \
    {                               \
        char str[MAX_DIGITS_FLOAT]; \
        sprintf(str, "%a", _to);    \
        ADD_TOLINE(str);            \
    } while (0)

// vygeneruje hlavičku a deklaruje globální proměnné
bool gen_header()
{
    ADD_LINE("#Start of the program");
    ADD_LINE(".IFJCode24");

    ADD_LINE("# Declaration of global variables");
    ADD_LINE("DEFVAR GF@bool");
    ADD_LINE("DEFVAR GF@type");
    ADD_LINE("DEFVAR GF@tmp");
    ADD_LINE("DEFVAR GF@$$FLUSH$$");

    ADD_LINE("CREATEFRAME");
    ADD_LINE("CALL $main");
    ADD_LINE("JUMP $$END");
    return true;
}

bool gen_flush()
{
    ADD_LINE("POPS GF@$$FLUSH$$"); // Pomocná proměnná - využita jako obdoba speciální proměnné _
    return true;
}

// vygeneruje návěští konce kódu
bool gen_footer()
{
    ADD_LINE("LABEL $$END"); // Konec pro skok po vykonání funkce main v programu na vstupu

    return true;
}

// vygeneruje návěstí a těla všech built-in funkcí
bool gen_built_in_function()
{
    ADD_LINE(FUNCTION_READ_STR);
    ADD_LINE(FUNCTION_READ_I32);
    ADD_LINE(FUNCTION_READ_F64);
    ADD_LINE(FUNCTION_WRITE);
    ADD_LINE(FUNCTION_I2F);
    ADD_LINE(FUNCTION_F2I);
    ADD_LINE(FUNCTION_STRING);
    ADD_LINE(FUNCTION_LENGTH);
    ADD_LINE(FUNCTION_CONCAT);
    ADD_LINE(FUNCTION_SUBSTRING);
    ADD_LINE(FUNCTION_STRCMP);
    ADD_LINE(FUNCTION_ORD);
    ADD_LINE(FUNCTION_CHR);
    return true;
}

// vygeneruje deklaraci lokalní proměnné
bool gen_local_var_def(char *id, unsigned int cnt)
{
    ADD_LINE("DEFVAR LF@");
    ADD_TOLINE(id);
    ADD_TOLINE("$");
    ADD_INT(cnt);
    return true;
}

// vygeneruje inicializaci lokální proměnné (POPS)
bool gen_local_var_init(char *id, unsigned int cnt)
{
    ADD_LINE("POPS LF@");
    ADD_TOLINE(id);
    ADD_TOLINE("$");
    ADD_INT(cnt);
    return true;
}
bool gen_null_var(const char *id_bez_null, unsigned int cnt_scope) // Pomocná funkce pro generování id_beznull pro konstrukce if a while
{
    ADD_LINE("DEFVAR LF@");
    ADD_TOLINE(id_bez_null);
    ADD_TOLINE("$");
    ADD_INT(cnt_scope);
    return true;
}

bool gen_if_tmp(unsigned int cnt) // Pomocná proměnná využita pro vyhodnocení condition
{
    ADD_LINE("DEFVAR LF@tmp");
    ADD_TOLINE("$");
    ADD_INT(cnt);
    return true;
}

bool gen_while_tmp(unsigned int cnt)
{
    ADD_LINE("DEFVAR LF@tmpwhile");
    ADD_TOLINE("$");
    ADD_INT(cnt);
    return true;
}

// vygeneruje návěští
bool gen_label(const char *function_id)
{
    ADD_LINE("LABEL $");
    ADD_TOLINE(function_id);

    return true;
}

// vygeneruje začátek funkce (návěští + PUSHFRAME)
bool gen_function_start(F_DEF data)
{
    ADD_LINE("\n#Function start");
    ADD_LINE("LABEL $");
    ADD_TOLINE(data.id);
    ADD_LINE("PUSHFRAME");
    return true;
}

// vygeneruje frame pro funkci (CREATEFRAME)
bool gen_function_params_frame()
{
    ADD_LINE("CREATEFRAME");
    return true;
}

// vygeneruje připravení parametru pro funkci (PUSHS)
bool gen_param_in(FACTOR data, unsigned int cnt)
{
    if (data.id != NULL)
    {
        ADD_LINE("PUSHS LF@");
        ADD_TOLINE(data.id);
        ADD_TOLINE("$");
        ADD_INT(cnt);
    }
    else
    {
        gen_pushs_literal(data);
    }
    return true;
}

// vygeneruje deklaraci a inicializaci parametru (DEFVAR + POPS)
bool gen_function_param(PARAMS_IN data, unsigned int cnt)
{
    ADD_LINE("DEFVAR LF@");
    ADD_TOLINE(data.id);
    ADD_TOLINE("$");
    ADD_INT(cnt);
    ADD_LINE("POPS LF@");
    ADD_TOLINE(data.id);
    ADD_TOLINE("$");
    ADD_INT(cnt);
    return true;
}

// vygeneruje zakončení funkce (POPFRAME + RETURN)
bool gen_function_end(F_DEF data)
{
    ADD_LINE("\n#Function end");
    ADD_LINE("LABEL ");
    ADD_TOLINE(data.id);
    ADD_TOLINE("_end");
    ADD_LINE("POPFRAME");
    ADD_LINE("RETURN");
    return true;
}
bool gen_return()
{
    ADD_LINE("POPFRAME");
    ADD_LINE("RETURN");
    return true;
}

// vygeneruje volání funkce
bool gen_call(char *id)
{
    ADD_LINE("CALL $");
    ADD_TOLINE(id);
    ADD_TOLINE("\n");
    return true;
}

bool gen_if_defaultstart(unsigned int cnt)
{
    ADD_LINE("\n#If start");
    ADD_LINE("PUSHS bool@true");
    ADD_LINE("JUMPIFNEQS else$start$");
    ADD_INT(cnt);
    return true;
}
bool gen_if_nullstart(unsigned int cnt, const char *id_bez_null, unsigned int cnt_scope) // TO DO ZKONTROLOVAT
{
    ADD_LINE("\n# If null-check start");

    // Zkontrolujeme, zda je výraz null
    ADD_LINE("POPS LF@tmp$");
    ADD_INT(cnt);
    ADD_LINE("PUSHS LF@tmp$");
    ADD_INT(cnt);
    ADD_LINE("PUSHS nil@nil");
    ADD_LINE("JUMPIFEQS else$start$");
    ADD_INT(cnt);

    // Pokud není null, uložíme hodnotu do id_bez_null
    ADD_LINE("PUSHS LF@tmp$");
    ADD_INT(cnt);
    ADD_LINE("POPS LF@");
    ADD_TOLINE(id_bez_null);
    ADD_TOLINE("$");
    ADD_INT(cnt_scope);
    return true;
}

bool gen_if_end(unsigned int cnt)
{
    ADD_LINE("\n#If end");
    ADD_LINE("JUMP else$end$");
    ADD_INT(cnt);

    return true;
}

bool gen_if_else_start(unsigned int cnt)
{
    ADD_LINE("LABEL else$start$");
    ADD_INT(cnt);
    return true;
}

bool gen_if_else_end(unsigned int cnt)
{
    ADD_LINE("LABEL else$end$");
    ADD_INT(cnt);
    return true;
}

bool gen_while_start(unsigned int cnt)
{
    ADD_LINE("# While start");
    ADD_LINE("LABEL $while$start$");
    ADD_INT(cnt);
    return true;
}

bool gen_while_startnull(unsigned int cnt) // TODO otestovat
{
    ADD_LINE("# While null start");
    ADD_LINE("LABEL $while$start$");
    ADD_INT(cnt);
    return true;
}

bool gen_while_afternull(unsigned int cnt, const char *id_bez_null, unsigned int cnt_scope)
{
    ADD_LINE("POPS LF@tmpwhile$");
    ADD_INT(cnt);
    ADD_LINE("PUSHS LF@tmpwhile$");
    ADD_INT(cnt);
    ADD_LINE("PUSHS nil@nil");
    ADD_LINE("JUMPIFEQS $while$end$");
    ADD_INT(cnt);

    // Pokud není null, uložíme hodnotu do id_bez_null
    ADD_LINE("PUSHS LF@tmpwhile$");
    ADD_INT(cnt);
    ADD_LINE("POPS LF@");
    ADD_TOLINE(id_bez_null);
    ADD_TOLINE("$");
    ADD_INT(cnt_scope);

    return true;
}

bool gen_while_after_exp(unsigned int cnt)
{
    ADD_LINE("PUSHS bool@true");
    ADD_LINE("JUMPIFNEQS $while$end$");
    ADD_INT(cnt);
    return true;
}

bool gen_while_end(unsigned int cnt)
{
    ADD_LINE("JUMP");
    ADD_TOLINE(" $while$start$");
    ADD_INT(cnt);
    ADD_LINE("LABEL $while$end$");
    ADD_INT(cnt);
    return true;
}

// vygeneruje načtení proměnné na stack (PUSHS)
bool gen_pushs_prom(char *id, unsigned int cnt)
{
    ADD_LINE("PUSHS LF@");
    ADD_TOLINE(id);
    ADD_TOLINE("$");
    ADD_INT(cnt);
    return true;
}

// vygeneruje načtení literálu na stack (PUSHS)
bool gen_pushs_literal(FACTOR data)
{
    switch (data.factorType)
    {
    case TYPE_I32:
        ADD_LINE("PUSHS int@");
        ADD_INT(data.value.i32);
        break;

    case TYPE_F64:
        ADD_LINE("PUSHS float@");
        ADD_FLOAT(data.value.f64);
        break;

    case TYPE_U8:
        ADD_LINE("PUSHS string@");
        ADD_TOLINE(dynamic_string_process_const_str(data.value.u8));
        break;

    case TYPE_NULL:
        ADD_LINE("PUSHS nil@nil");
        break;

    default:
        return false;
    }

    return true;
}

// vygeneruje volání konverze z i32 na f64
bool gen_literal_conversion_i2f()
{
    ADD_LINE(" # type conversion i2f");
    ADD_LINE("CREATEFRAME");
    ADD_LINE("CALL $$$ifj_i2f");
    ADD_LINE("");
    return true;
}

// vygeneruje volání konverze z f64 na i32
bool gen_literal_conversion_f2i()
{
    ADD_LINE(" # type conversion f2i");
    ADD_LINE("CREATEFRAME");
    ADD_LINE("CALL $$$ifj_f2i");
    ADD_LINE("");
    return true;
}

// vygeneruje načtení z globální tmp proměnné pokud není prázdná (POPS)
bool gen_pops_tmp()
{
    if (gf_tmp_empty == false)
    {
        printf("dojde ke ztrate gf_tmp");
        exit(100);
    }
    gf_tmp_empty = false;
    ADD_LINE(" # tmp pops");
    ADD_LINE("POPS GF@tmp");
    ADD_LINE("");
    return true;
}

// vygeneruje náčtení na globální tmp proměnnou pokud je prázdná (PUSHS)
bool gen_pushs_tmp()
{
    if (gf_tmp_empty == true)
    {
        printf("v gf_tmp neni hodnota");
        exit(100);
    }
    gf_tmp_empty = true;
    ADD_LINE(" # tmp pushs");
    ADD_LINE("PUSHS GF@tmp");
    ADD_LINE("");
    return true;
}

// vygeneruje operátor
bool gen_operation(OPERATOR_TYPE op)
{
    switch (op)
    {
    case OP_PLUS:
        ADD_LINE("ADD");
        break;

    case OP_MINUS:
        ADD_LINE("SUB");
        break;

    case OP_STAR:
        ADD_LINE("MUL");
        break;

    case OP_SLASH:
        ADD_LINE("DIV");
        break;

    case OP_IDIV:
        ADD_LINE("IDIV");
        break;

    case OP_EQUAL:
        ADD_LINE("EQ");
        break;

    case OP_NOT_EQUAL:
        ADD_LINE("EQ");
        ADD_LINE("NOT");
        break;

    case OP_LESS:
        ADD_LINE("LT");
        break;

    case OP_GREATER:
        ADD_LINE("GT");
        break;

    default:
        break;
    }

    return true;
}

// vygeneruje operátor stacku
bool gen_stack_operation(OPERATOR_TYPE st_op)
{
    switch (st_op)
    {
    case OP_PLUS:
        ADD_LINE("ADDS");
        break;

    case OP_MINUS:
        ADD_LINE("SUBS");
        break;

    case OP_STAR:
        ADD_LINE("MULS");
        break;

    case OP_SLASH:
        ADD_LINE("DIVS");
        break;

    case OP_IDIV:
        ADD_LINE("IDIVS");
        break;

    case OP_EQUAL:
        ADD_LINE("EQS");
        break;

    case OP_NOT_EQUAL:
        ADD_LINE("EQS");
        ADD_LINE("NOTS");
        break;

    case OP_LESS:
        ADD_LINE("LTS");
        break;

    case OP_GREATER:
        ADD_LINE("GTS");
        break;

    case OP_OR:
        ADD_LINE("ORS");
        break;

    default:
        break;
    }

    return true;
}
