#include <stdio.h>

#include "dynamic_string.h"
#include "generator.h"
#include "built_in_function.h"
#include "tree.h"

Dynamic_string dyn_str;
OPERATOR_TYPE op;
TYPE type;
const char *function_id = "skibidi";
int label_depth = 1;
int label_index = 22;

#define MAX_DIGITS_INT 40
#define MAX_DIGITS_FLOAT 512

#define ADD_LINE(_line)                                        \
    if (!dynamic_string_add_const_str(&dyn_str, ("\n" _line))) \
    return false

#define ADD_TOLINE(_to)                               \
    if (!dynamic_string_add_const_str(&dyn_str, _to)) \
    return false

#define ADD_INT(_to)              \
    do                            \
    {                             \
        char str[MAX_DIGITS_INT]; \
        sprintf(str, "%d", _to);  \
        ADD_TOLINE(str);          \
    } while (0)

#define ADD_FLOAT(_to)              \
    do                              \
    {                               \
        char str[MAX_DIGITS_FLOAT]; \
        sprintf(str, "%a", _to);    \
        ADD_TOLINE(str);            \
    } while (0)

bool gen_header()
{
    ADD_LINE("#Start of the program");
    ADD_LINE(".IFJCode24");

    ADD_LINE("# Declaration of global variables");
    ADD_LINE("DEFVAR GF@bool");
    ADD_LINE("DEFVAR GF@type");

    ADD_LINE("CREATEFRAME");
    ADD_LINE("CALL $main");
    ADD_LINE("JUMP $$END");
    return true;
}

bool gen_footer()
{
    ADD_LINE("LABEL $$END");

    return true;
}

bool gen_built_in_function()
{
    ADD_LINE(FUNCTION_READ_STR);
    ADD_LINE(FUNCTION_READ_I32);
    ADD_LINE(FUNCTION_READ_F64);
    ADD_LINE(FUNCTION_WRITE);
    ADD_LINE(FUNCTION_I2F);
    ADD_LINE(FUNCTION_F2I);
    ADD_LINE(FUNCTION_STRING);
    ADD_LINE(FUNCTION_LENGTH);
    ADD_LINE(FUNCTION_CONCAT);
    ADD_LINE(FUNCTION_SUBSTRING);
    ADD_LINE(FUNCTION_STRCMP);
    ADD_LINE(FUNCTION_ORD);
    ADD_LINE(FUNCTION_CHR);
    return true;
}

bool gen_local_var_def(char *id)
{
    ADD_LINE("DEFVAR LF@");
    ADD_TOLINE(id);
    return true;
}

bool gen_local_var_init(char *id)
{
    ADD_LINE("POPS LF@");
    ADD_TOLINE(id);
    return true;
}

bool gen_label(const char *function_id)
{
    ADD_LINE("LABEL $");
    ADD_TOLINE(function_id);

    return true;
}

bool gen_function_start(F_DEF data)
{
    ADD_LINE("\n#Function start");
    ADD_LINE("LABEL $");
    ADD_TOLINE(data.id);
    ADD_LINE("PUSHFRAME");
    return true;
}

bool gen_function_params_frame()
{
    ADD_LINE("CREATEFRAME");
    return true;
}

bool gen_param_in(FACTOR data)
{
    if (data.id != NULL)
    {
        ADD_LINE("PUSHS LF@");
        ADD_TOLINE(data.id);
    }
    else
    {
        gen_pushs_const(data);
    }
    return true;
}

bool gen_function_param(PARAMS_IN data)
{
    ADD_LINE("DEFVAR LF@");
    ADD_TOLINE(data.id);
    ADD_LINE("POPS LF@");
    ADD_TOLINE(data.id);
    return true;
}

bool gen_function_end(F_DEF data)
{
    ADD_LINE("\n#Function end");
    ADD_LINE("LABEL ");
    ADD_TOLINE(data.id);
    ADD_TOLINE("_end");
    ADD_LINE("POPFRAME");
    ADD_LINE("RETURN");
    return true;
}

bool gen_call(char *id)
{
    ADD_LINE("CALL $");
    ADD_TOLINE(id);
    ADD_TOLINE("\n");
    return true;
}

bool gen_if_defaultstart(unsigned int cnt)
{
    ADD_LINE("\n#If start");
    ADD_LINE("PUSHS bool@true");
    ADD_LINE("JUMPIFNEQS else$start$");
    ADD_INT(cnt);
    return true;
}
bool gen_if_nullstart(unsigned int cnt, const char *id_bez_null) // TO DO ZKONTROLOVAT
{
    ADD_LINE("\n# If null-check start");

    // Zkontrolujeme, zda je výraz null
    ADD_LINE("DEFVAR LF@tmp$");
    ADD_INT(cnt);
    ADD_LINE("POPS LF@tmp$");
    ADD_INT(cnt);
    ADD_LINE("PUSHS LF@tmp$");
    ADD_INT(cnt);
    ADD_LINE("PUSHS nil@nil");
    ADD_LINE("JUMPIFEQS else$start$");
    ADD_INT(cnt);

    // Pokud není null, uložíme hodnotu do id_bez_null
    ADD_LINE("DEFVAR LF@");
    ADD_TOLINE(id_bez_null);
    // ADD_TOLINE("$"); TODO: udelat az bude fungovat scopovani
    // ADD_INT(cnt); //
    ADD_LINE("PUSHS LF@tmp$");
    ADD_INT(cnt);
    ADD_LINE("POPS LF@");
    ADD_TOLINE(id_bez_null);
    // ADD_TOLINE("$"); TODO: udelat az bude fungovat scopovani
    // ADD_INT(cnt);
    return true;
}

bool gen_if_end(unsigned int cnt)
{
    ADD_LINE("\n#If end");
    ADD_LINE("JUMP else$end$");
    ADD_INT(cnt);

    return true;
}

bool gen_if_else_start(unsigned int cnt)
{
    ADD_LINE("LABEL else$start$");
    ADD_INT(cnt);
    return true;
}

bool gen_if_else_end(unsigned int cnt)
{
    ADD_LINE("LABEL else$end$");
    ADD_INT(cnt);
    return true;
}

bool gen_while_start(unsigned int cnt)
{
    ADD_LINE("# While start");
    ADD_LINE("LABEL $while$start$");
    ADD_INT(cnt);
    return true;
}

bool gen_while_startnull(unsigned int cnt, const char *id_bez_null) // TODO otestovat
{
    ADD_LINE("# While null start");
    ADD_LINE("DEFVAR LF@tmpwhile$");
    ADD_INT(cnt);
    ADD_LINE("DEFVAR LF@");
    ADD_TOLINE(id_bez_null);
    // ADD_TOLINE("$"); TODO: udelat az bude fungovat scopovani
    // ADD_INT(cnt);
    ADD_LINE("LABEL $while$start$");
    ADD_INT(cnt);
}

bool gen_while_afternull(unsigned int cnt, const char *id_bez_null)
{
    ADD_LINE("POPS LF@tmpwhile$");
    ADD_INT(cnt);
    ADD_LINE("PUSHS LF@tmpwhile$");
    ADD_INT(cnt);
    ADD_LINE("PUSHS nil@nil");
    ADD_LINE("JUMPIFEQS $while$end$");
    ADD_INT(cnt);

    // Pokud není null, uložíme hodnotu do id_bez_null
    ADD_LINE("PUSHS LF@tmpwhile$");
    ADD_INT(cnt);
    ADD_LINE("POPS LF@");
    ADD_TOLINE(id_bez_null);
    // ADD_TOLINE("$"); TODO: udelat az bude fungovat scopovani
    // ADD_INT(cnt);

    return true;
}

bool gen_while_after_exp(unsigned int cnt)
{
    ADD_LINE("PUSHS bool@true");
    ADD_LINE("JUMPIFNEQS $while$end$");
    ADD_INT(cnt);
    return true;
}

bool gen_while_end(unsigned int cnt)
{
    ADD_LINE("JUMP");
    ADD_TOLINE(" $while$start$");
    ADD_INT(cnt);
    ADD_LINE("LABEL $while$end$");
    ADD_INT(cnt);
    return true;
}

bool gen_pushs_prom(char *id)
{
    ADD_LINE("PUSHS LF@");
    ADD_TOLINE(id);
    return true;
}

bool gen_pushs_const(FACTOR data)
{
    switch (data.factorType)
    {
    case TYPE_I32:
        ADD_LINE("PUSHS int@");
        ADD_INT(data.value.i32);
        break;

    case TYPE_F64:
        ADD_LINE("PUSHS float@");
        ADD_FLOAT(data.value.f64);
        break;

    case TYPE_U8:
        ADD_LINE("PUSHS string@");
        ADD_TOLINE(dynamic_string_process_const_str(data.value.u8));
        break;

    case TYPE_NULL:
        ADD_LINE("PUSHS nil@nil");
        break;

    default:
        return false;
    }

    return true;
}

bool gen_operation(OPERATOR_TYPE op)
{
    switch (op)
    {
    case OP_PLUS:
        ADD_LINE("ADD");
        break;

    case OP_MINUS:
        ADD_LINE("SUB");
        break;

    case OP_STAR:
        ADD_LINE("MUL");
        break;

    case OP_SLASH:
        ADD_LINE("DIV");
        break;

    case OP_IDIV:
        ADD_LINE("IDIV");
        break;

    case OP_EQUAL:
        ADD_LINE("EQ");
        break;

    case OP_NOT_EQUAL:
        ADD_LINE("EQ");
        ADD_LINE("NOT");
        break;

    case OP_LESS:
        ADD_LINE("LT");
        break;

    case OP_GREATER:
        ADD_LINE("GT");
        break;

    case OP_LESS_EQUAL:

        break;

    case OP_GREATER_EQUAL:

        break;

    default:
        break;
    }

    return true;
}

bool gen_stack_operation(OPERATOR_TYPE st_op)
{
    switch (st_op)
    {
    case OP_PLUS:
        ADD_LINE("ADDS");
        break;

    case OP_MINUS:
        ADD_LINE("SUBS");
        break;

    case OP_STAR:
        ADD_LINE("MULS");
        break;

    case OP_SLASH:
        ADD_LINE("DIVS");
        break;

    case OP_IDIV:
        ADD_LINE("IDIVS");
        break;

    case OP_EQUAL:
        ADD_LINE("EQS");
        break;

    case OP_NOT_EQUAL:
        ADD_LINE("EQS");
        ADD_LINE("NOTS");
        break;

    case OP_LESS:
        ADD_LINE("LTS");
        break;

    case OP_GREATER:
        ADD_LINE("GTS");
        break;

    case OP_LESS_EQUAL:
        ADD_LINE("POPS GF@tmp_2");
        ADD_LINE("POPS GF@tmp_1");
        ADD_LINE("PUSHS GF@tmp_2");
        ADD_LINE("PUSHS GF@tmp_1");
        ADD_LINE("LTS");
        ADD_LINE("PUSHS GF@tmp_2");
        ADD_LINE("PUSHS GF@tmp_1");
        ADD_LINE("EQS");
        ADD_LINE("ORS");
        break;

    case OP_GREATER_EQUAL:
        ADD_LINE("POPS GF@tmp_op1");
        ADD_LINE("POPS GF@tmp_op2");
        ADD_LINE("PUSHS GF@tmp_op2");
        ADD_LINE("PUSHS GF@tmp_op1");
        ADD_LINE("GTS");
        ADD_LINE("PUSHS GF@tmp_op2");
        ADD_LINE("PUSHS GF@tmp_op1");
        ADD_LINE("EQS");
        ADD_LINE("ORS");
        break;

    default:
        break;
    }

    return true;
}
