// Autor: Lukáš Gronich - xgronil00
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "semantic.h"
#include "symtable.h"
#include "tree.h"

extern ScopeNode *scopeStackGlobal; // Globální scope pro definice funkcí
extern ScopeNode *scopeStackLocal;  // Lokální scope pro rozsahy proměnných
Semantic semantic;

void initializeSemantic()
{
    semantic.current_function = NULL;
}

void checkUnusedSymbols(ScopeNode *scope)
{
    AVLNode *node = scope->symbolTree;
    checkUnusedSymbolsInTree(node);
}

void checkUnusedSymbolsInTree(AVLNode *node)
{
    if (node == NULL)
    {
        return;
    }

    checkUnusedSymbolsInTree(node->left);
    if (node->symbol->used == false)
    {
        exit(9); // Kontrola jestli byl symbol alespoň jednou použit
    }
    else if (node->symbol->type == VAR && node->symbol->changed == false)
    {
        exit(9); // Kontrola jestli byl var alespoň jednou přepsán
    }

    checkUnusedSymbolsInTree(node->right);
}

void checkReturn()
{
    if (semantic.current_function->dataType != TYPE_VOID && semantic.current_function->ret == false)
    {
        exit(6); // Ve funkci nebyla vrácena hodnota
    }
}

void checkParamsTypes(int numArgs, Node *args)
{
    for (int i = 0; i < numArgs; i++)
    {
        if (semantic.current_function->parameters->dataType != args->data.factorNode.factorType)
        {
            exit(4); // špatný typ parametrů
        }
    }
}
