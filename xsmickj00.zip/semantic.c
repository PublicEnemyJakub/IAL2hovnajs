#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "semantic.h"
#include "symtable.h"
#include "tree.h"

static Semantic semantic;

extern ScopeNode *scopeStackGlobal;
extern ScopeNode *scopeStackLocal;

void checkSemanticError(const char *id, SymbolType expectedType, TYPE ret_type, int numArgs){ // Neco upravit na nodes???
    Symbol *symbol = findInScopes(id, scopeStackLocal);
    if(symbol == NULL){
        symbol = findInScopes(id, scopeStackGlobal);
    }
    if(symbol == NULL){ // nedefinovaná funkce či proměnná
        printf("3\n");
        exit (3);
    }
    
    else if(expectedType == FUNC){
        Parameter *param = symbol->parameters;
        int paramCnt = 0;
        while (param != NULL){
            paramCnt++;
            param = param->next;
        }
        if(paramCnt != numArgs){    // špatný počet argumentů
            printf("4\n");
            exit (4);
        }
        
       
        if(symbol->dataType != ret_type) { // špatný typ či nepovolené zahození návratové hodnoty z funkce
            exit (4); 
        }
        
    }
    
    else if(symbol->dataType != ret_type){ // Redefinice
        printf("5\n");
        exit (5);
    }
    else if(symbol->type == CONST){ // přiřazení do nemodifikovatelné proměnné
        printf("5\n");
        exit (5);
    }
}

void checkReturnSemanticError(TYPE returnValue){
     if (semantic.current_function == NULL) {
        printf("6\n");
        exit(6);
    }
    // Kontrola návratového typu
    TYPE expectedReturnType = semantic.current_function->dataType;
    if (expectedReturnType != returnValue) {
        // Funkce typu void nesmí mít návratový výraz
        printf("6\n");
        exit(6);
    }
}

void checkParamsTypes(int numArgs, Node *args){
    for(int i=0; i < numArgs; i++){
        if(semantic.current_function->parameters->dataType != args->data.factorNode.factorType){     // špatný typ parametrů
            exit (4);
        }
    }
}

/*
void testSemanticChecks() {
    memset(&semantic, 0, sizeof(Semantic));
    scopeStackGlobal = pushScope(scopeStackGlobal);

    // Přidání nové funkce do globálního scopu
    Symbol *funcSymbol1 = createSymbol("foo", FUNC, TYPE_VOID);
    insertToCurrentScope(funcSymbol1, scopeStackGlobal);
    semantic.current_function = funcSymbol1;
    // Test 1: Definice funkce a následná kontrola správnosti počtu argumentů
    /*
    printf("Test 1: Volání funkce 'foo' se špatným počtem argumentů\n");
    checkSemanticError("foo", FUNC, TYPE_NONE, 1);
    */
    /*
    // Přidání nového lokálního scopu pro funkci "foo"
    scopeStackLocal = pushScope(scopeStackLocal);

    // Vložení konstanty do lokálního scopu
    Symbol *constSymbol = createSymbol("b", CONST, TYPE_I32);
    insertToCurrentScope(constSymbol, scopeStackLocal);

    // Test 2: Pokus o přiřazení do konstanty (měl by nastat semantický error)
    /*
    printf("Test 2: Pokus o přiřazení do konstanty 'b'\n");
    checkSemanticError("b", VAR, TYPE_NONE, 0);
    popScope(scopeStackLocal);
    */
    /*
    // Vložení proměnné do lokálního scopu
    Symbol *varSymbol = createSymbol("a", VAR, TYPE_I32);
    insertToCurrentScope(varSymbol, scopeStackLocal);
    /*
    // Test 3: Definice proměnné 'a' a následná redefinice ve stejném scopu (měl by nastat semantický error)
    printf("\nTest 3: Pokus o redefinici proměnné 'a'\n");
    checkSemanticError("a", VAR, TYPE_F64, 0);
    */
    
    /*
    // Test 5: Přístup k lokální proměnné mimo její scope (měl by nastat semantický error)
    printf("\nTest 5: Přístup k lokální proměnné 'a' mimo její scope\n");
    scopeStackLocal = popScope(scopeStackLocal); // Odebrání lokálního scopu
    checkSemanticError("a", VAR, TYPE_NONE, 0);
    */
    /*
    checkReturnSemanticError(TYPE_F64);
}
*/

/*
int main() {
    // Spuštění testovacích scénářů
    testSemanticChecks();
    return 0;
}
*/