// Autor: Lukáš Gronich - xgronil00
#ifndef TREE_H
#define TREE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef enum
{
    TYPE_NONE,
    TYPE_VOID,
    TYPE_U8,
    TYPE_I32,
    TYPE_F64,
    TYPE_U8_NULL,
    TYPE_I32_NULL,
    TYPE_F64_NULL,
    TYPE_NULL,
} TYPE;

typedef enum
{
    VAR_TYPE,
    CONST_TYPE,
} VariableType;

typedef enum
{
    OP_PLUS,
    OP_MINUS,
    OP_STAR,
    OP_SLASH,
    OP_IDIV,
    OP_EQUAL,
    OP_NOT_EQUAL,
    OP_LESS,
    OP_GREATER,
    OP_LESS_EQUAL,
    OP_GREATER_EQUAL,
    OP_OR,
} OPERATOR_TYPE;

typedef enum
{
    NODE_MAIN,
    NODE_FUNCTION,
    NODE_PARAMETER,
    NODE_VARIABLE_DECLARATION,
    NODE_VARIABLE_INITIALIZATION,
    NODE_EXPRESSION,
    NODE_IF,
    NODE_IF_BODY,
    NODE_ELSE_BODY,
    NODE_WHILE,
    NODE_CONDITION,
    NODE_RETURN,
    NODE_CALL,
    NODE_FACTOR,
} NodeType;

typedef struct FunctionNode
{
    char *id;
    TYPE return_type;
    struct Node *params;
} F_DEF;

typedef struct ParameterNode
{
    char *id;
    TYPE type;
} PARAMS_IN;

typedef struct VariableDeclarationNode
{
    char *id;
    TYPE type;
    VariableType var_type;
    struct Node *expression;
} VAR_DEC;

typedef struct IfNode
{
    struct Node *condition;
    struct Node *exp_null;
    char *id_null;
    unsigned int cnt;
} IF;

typedef struct Ifbody
{
    unsigned int cnt;
} IF_BODY;

typedef struct ElseBody
{
    unsigned int cnt;
} ELSE_BODY;

typedef struct WhileNode
{
    struct Node *condition;
    struct Node *exp_null;
    char *id_null;
    unsigned int cnt;
} WHILE;

typedef struct ReturnNode
{
    struct Node *expression;
} RETURN;

typedef struct CallNode
{
    char *id;
    bool isBuildin;
    struct Node *args;
} CALL;

typedef struct ConditionNode
{
    struct Node *leftExpression;
    OPERATOR_TYPE operator;
    struct Node *rightExpression;
} CONDITION;

typedef struct ExpressionNode
{
    struct Node *leftExpression;
    OPERATOR_TYPE operator;
    struct Node *rightExpression;
} EXPRESSION;

typedef struct FactorNode
{
    TYPE factorType;
    char *id;
    union
    {
        int i32;
        double f64;
        char *u8;
    } value;
} FACTOR;

typedef struct Node
{
    NodeType type;         // Typ uzlu
    struct Node *sibling;  // Ukazatel na sourozence uzlu
    struct Node *children; // Ukazatel na dítě uzlu
    union
    {
        F_DEF function;            // Uzel funkce
        PARAMS_IN parameter;       // Uzel parametru
        VAR_DEC varDecl;           // Uzel deklarace proměnné
        IF ifNode;                 // Uzel if
        IF_BODY ifBody;            // Uzel těla if
        ELSE_BODY elseBody;        // Uzel těla else
        WHILE whileNode;           // Uzel while
        RETURN returnNode;         // Uzel return
        CALL callNode;             // Uzel volání funkce
        CONDITION conditionNode;   // Uzel podmínky
        EXPRESSION expressionNode; // Uzel výrazu
        FACTOR factorNode;         // Uzel pro hodnotu/proměnnou
    } data;                        // Data uzlu
} Node;

Node *createNode(NodeType node_type);                                                                                // Funkce pro vytvoření obecného uzlu
Node *createFunctionNode(char *id, TYPE return_type, NodeType node_type);                                            // Funkce pro vytvoření uzlu definice funkce
Node *createParameterNode(char *id, TYPE type, NodeType node_type);                                                  // Funkce pro vytvoření uzlu parametru funkce
Node *createVarDeclarationNode(char *id, TYPE type, Node *expression, NodeType node_type);                           // Funkce pro vytvoření uzlu deklarace proměnné
Node *createVarInitializationNode(char *id, TYPE type, Node *expression, NodeType node_type);                        // Funkce pro vytvoření uzlu při inicializaci proměnné
Node *createExpressionNode(OPERATOR_TYPE operator, Node * leftOperand, Node *rightOperand, NodeType node_type);      // Funkce pro vytvoření uzlu výrazu
Node *createIfNode(Node *condition, Node *exp_more, char *id_more, NodeType node_type);                              // Funkce pro vytvoření uzlu if
Node *createIfBodyNode(NodeType node_type);                                                                          // Funkce pro vytvoření uzlu těla if
Node *createElseBodyNode(NodeType node_type);                                                                        // Funkce pro vytvoření uzlu  těla else
Node *createWhileNode(Node *condition, Node *exp_more, char *id_more, NodeType node_type);                           // Funkce pro vytvoření uzlu while
Node *createReturnNode(NodeType node_type);                                                                          // Funkce pro vytvoření uzlu return
Node *createCallNode(char *id, bool buildin, NodeType node_type);                                                    // Funkce pro vytvoření uzlu volání funkce
Node *createConditionNode(Node *leftExpression, OPERATOR_TYPE operator, Node * rightExpression, NodeType node_type); // Funkce pro vytvoření uzlu podmínky
Node *createFactorNode(char *id, int i32, double f64, char *u8, TYPE factorType, NodeType node_type);                // Funkce pro vytvoření uzlu pro hodnotu/proměnnou
bool InsertNode(Node *parent, Node *child);                                                                          // Funkce pro vložení uzlu jako dítě do uzlu rodiče
bool InsertParamNode(Node *function, Node *param);                                                                   // Funkce pro vložení uzlu parametru do uzlu funkce při deklaraci
bool InsertCallArgument(Node *callNode, Node *arg);                                                                  //  Funkce pro vložení uzlu parametru do funkce při volání funkce

#endif // TREE_H