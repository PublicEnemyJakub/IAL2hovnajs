#include <stdio.h>
#include "dynamic_string.h"
#include "generator.h"
#include "sem_analysis.h"
#include "tree.h"
#include "symtable.h"
#include "semantic.h"

bool null_condtition = false;
char *filename = "output.ifjcode";

ScopeNode *scopeStackGlobal = NULL;
ScopeNode *scopeStackLocal = NULL;

int sem_analysis_fn(Node *ast_root)
{

    if (!dynamic_string_init(&dyn_str, filename))
    {
        return 1;
    }

    gen_header();
    gen_built_in_function();

    // ast_print(ast_root, 0);
    // exit(0);

    scopeStackGlobal = pushScope(scopeStackGlobal);
    Node *node = ast_root->children;
    Symbol *funcSymbol1 = createSymbol(node->data.function.id, FUNC, node->data.function.return_type);
    insertToCurrentScope(funcSymbol1, scopeStackGlobal);
    if (node->data.function.params != NULL)
    {
        Node *param = node->data.function.params;
        addParameter(funcSymbol1, param->data.parameter.id, param->data.parameter.type);
        while (param->sibling)
        {
            param = param->sibling;
            addParameter(funcSymbol1, param->data.parameter.id, param->data.parameter.type);
        }
    }
    while (node->sibling)
    {
        scopeStackGlobal = pushScope(scopeStackGlobal);
        node = node->sibling;
        Symbol *funcSymbol = createSymbol(node->data.function.id, FUNC, node->data.function.return_type);
        insertToCurrentScope(funcSymbol, scopeStackGlobal);
        if (node->data.function.params != NULL)
        {
            Node *param = node->data.function.params;
            addParameter(funcSymbol, param->data.parameter.id, param->data.parameter.type);
            while (param->sibling)
            {
                param = param->sibling;
                addParameter(funcSymbol, param->data.parameter.id, param->data.parameter.type);
            }
        }
        // printScopes(scopeStackGlobal);
    }
    Symbol *symbol = findInScopes("main", scopeStackGlobal);
    if (symbol == NULL)
    {
        exit(3);
    }
    else if (symbol->dataType != TYPE_VOID)
    {
        exit(4);
    }
    else if (symbol->parameters != NULL)
    {
        exit(4);
    }
    process_ast(ast_root);
    // printScopes(scopeStackGlobal);


    gen_footer();
    // dynamic_string_write_to_file(&dyn_str, filename);

    // dynamic_string_print(&dyn_str);

    dynamic_string_print_stdout(&dyn_str);

    dynamic_string_free(&dyn_str);

    return 0;
}

const char *ast_node_type_to_string(NodeType type)
{
    switch (type)
    {
    case NODE_FUNCTION:
        return "FUNC DEF";
    case NODE_CALL:
        return "CALL";
    case NODE_PARAMETER:
        return "PARAM";
    case NODE_CONDITION:
        return "CONDITION";
    case NODE_EXPRESSION:
        return "BINARY OPERATOR";
    case NODE_VARIABLE_INITIALIZATION:
        return "VAR INIT";
    case NODE_VARIABLE_DECLARATION:
        return "VAR DEC";
    case NODE_RETURN:
        return "RETURN";
    case NODE_IF:
        return "IF";
    case NODE_IF_BODY:
        return "IF BODY";
    case NODE_ELSE_BODY:
        return "ELSE BODY";
    case NODE_WHILE:
        return "WHILE";
    case NODE_FACTOR:
        return "FACTOR";
    default:
        return "UNKNOWN NODE";
    }
}

const char *ast_data_type_to_string(TYPE type)
{
    switch (type)
    {
    case TYPE_VOID:
        return "void";
    case TYPE_I32:
        return "i32";
    case TYPE_I32_NULL:
        return "?i32";
    case TYPE_F64:
        return "f64";
    case TYPE_F64_NULL:
        return "?f64";
    case TYPE_U8:
        return "[]u8";
    case TYPE_U8_NULL:
        return "?[]u8";
    default:
        return "unknown";
    }
}

const char *ast_operator_type_to_string(OPERATOR_TYPE type)
{
    switch (type)
    {
    case OP_PLUS:
        return "+";
    case OP_MINUS:
        return "-";
    case OP_STAR:
        return "*";
    case OP_SLASH:
        return "/";
    case OP_IDIV:
        return "/";
    case OP_EQUAL:
        return "==";
    case OP_NOT_EQUAL:
        return "!=";
    case OP_LESS:
        return "<";
    case OP_LESS_EQUAL:
        return "<=";
    case OP_GREATER:
        return ">";
    case OP_GREATER_EQUAL:
        return ">=";
    default:
        return "unknown";
    }
}

const char *ast_variable_type_to_string(VariableType type)
{
    switch (type)
    {
    case VAR_TYPE:
        return "var";
    case CONST_TYPE:
        return "const";
    default:
        return "unknown";
    }
}

void process_param_in(Node *arg)
{
    if (arg == NULL)
    {
        return;
    }

    // printf(" (Name: %s)", arg->data.factorNode.id);
    // printf("\n");

    process_param_in(arg->sibling);

    gen_param_in(arg->data.factorNode);
}

void process_ast(Node *node)
{
    Node *current_node = NULL;
    Node *arg = NULL;
    if (!node)
    {
        return;
    }
    //  printf("%s\n", ast_node_type_to_string(node->type));

    switch (node->type)
    {
    case NODE_MAIN:
        break;

    case NODE_FUNCTION:
        // hotovo
        scopeStackLocal = pushScope(scopeStackLocal);
        // printf(" (Name: %s, Return Type: %s, Params: [\n",
        //       node->data.function.id,
        //       ast_data_type_to_string(node->data.function.return_type));

        gen_function_start(node->data.function);
        // parametry
        // ast_print(node->data.function.params, 0);
        // exit(0);
        if (node->data.function.params != NULL)
        {
            Node *param = node->data.function.params;

            while (param)
            {
                process_ast(param);
                param = param->sibling;
            }
        }

        break;
        current_node = node->children;
        while (current_node)
        {
            process_ast(current_node);
            current_node = current_node->sibling;
        }
        gen_function_end(node->data.function);
        return;

    case NODE_CALL:

        if (node->data.callNode.isBuildin == true)
        {
            const char *prefix = "ifj_";
            size_t prefix_len = strlen(prefix);
            size_t func_name_len = strlen(node->data.callNode.id);
            char *new_name = malloc(prefix_len + func_name_len + 1);
            if (new_name == NULL)
            {
                fprintf(stderr, "Chyba: Nepodařilo se alokovat paměť.\n");
                exit(99);
            }
            strcpy(new_name, prefix);
            strcat(new_name, node->data.callNode.id);
            node->data.callNode.id = new_name;
        }
        else
        {
            Symbol *symbol = findInScopes(node->data.callNode.id, scopeStackGlobal);
            if (symbol == NULL)
            {
                exit(3);
            }
        }

        gen_function_params_frame(); // "\n CREATEFRAME"

        // printf(" (Function Call: %s [\n", node->data.callNode.id);
        //  Print the arguments for the function call
        arg = node->data.callNode.args;
        process_param_in(arg);

        // printf("])\n");
        gen_call(node->data.callNode.id); //  "\n CALL $ifj_strlen"
        break;

    case NODE_PARAMETER:
        // hotovo
        // printf(" (Name: %s)", node->data.parameter.id);
        // printf("\n");

        gen_function_param(node->data.parameter);

        break;

    case NODE_EXPRESSION:
        // hotovo
        // printf(" (Operator: %s [\n", ast_operator_type_to_string(node->data.expressionNode.operator));

        // printf("levy expresion\n");
        process_ast(node->children);
        // printf("pravy expresion\n");
        process_ast(node->children->sibling);

        gen_stack_operation(node->data.expressionNode.operator); // TODO PORESIT ZE DELENI BERE POUZE FLOATY
        // printf("po operatoru\n");
        // printf("])\n");

        return;

    case NODE_RETURN:
        // hotovo
        //  Print the return expression
        // nedelat!!! gen_return_def();
        process_ast(node->data.returnNode.expression);
        // nedelat!!! gen_return_init(node->data.returnNode.expression)

        break;

    case NODE_VARIABLE_DECLARATION:
        // hotovo
        Symbol *symbol = findInScopes(node->data.varDecl.id, scopeStackLocal);
        if (symbol == NULL)
        {
            Symbol *localVar = createSymbol(node->data.varDecl.id, node->data.varDecl.var_type, TYPE_NONE);
            insertToCurrentScope(localVar, scopeStackLocal);
            // printScopes(scopeStackLocal);
        }
        else
        {
            exit(5);
        }
        gen_local_var_def(node->data.varDecl.id);
        // printf(" (Type: %s, Variable Type: %s, Variable Name: %s)\n",
        //        ast_data_type_to_string(node->data.varDecl.type),
        //        ast_variable_type_to_string(node->data.varDecl.var_type),
        //        node->data.function.id);

        // printf("expresion\n");
        process_ast(node->data.varDecl.expression);
        // if (node->sibling)
        // {
        //     if (node->sibling->type == NODE_CALL)
        //     {
        //         ignore_next_call = true;
        //     }
        // }
        //   node->data.varDecl.id ? node->data.varDecl.id : "NULL");
        gen_local_var_init(node->data.varDecl.id); // pops ze stacku

        break;

    case NODE_IF:
        null_condtition = node->data.ifNode.id_null != NULL;

        process_ast(node->data.ifNode.condition);
        if (!null_condtition)
        {
            gen_if_defaultstart(node->data.ifNode.cnt);
            break;
        }
        else
        {
            gen_if_nullstart(node->data.ifNode.cnt, node->data.ifNode.id_null);
        }
        break;

    case NODE_IF_BODY:
        scopeStackLocal = pushScope(scopeStackLocal);
        // fprintf(stderr, " (Counter: %d)", node->data.ifBody.cnt);
        break;

    case NODE_ELSE_BODY:
        scopeStackLocal = pushScope(scopeStackLocal);

        // fprintf(stderr, " (Counter: %d)", node->data.elseBody.cnt);
        gen_if_else_start(node->data.elseBody.cnt);
        break;

    case NODE_WHILE:
        scopeStackLocal = pushScope(scopeStackLocal);
        if (node->data.whileNode.id_null == NULL)
        {
            gen_while_start(node->data.whileNode.cnt);
            null_condtition = false;
            process_ast(node->data.whileNode.condition);
            gen_while_after_exp(node->data.whileNode.cnt);
        }
        else
        {
            gen_while_startnull(node->data.whileNode.cnt, node->data.whileNode.id_null);
            null_condtition = true;
            process_ast(node->data.whileNode.condition);
            gen_while_afternull(node->data.whileNode.cnt, node->data.whileNode.id_null);
        }
        break;

    case NODE_CONDITION: // DOPLNIT SEMATICKE CHYBY
        // printf(" (Left: [\n");
        process_ast(node->data.conditionNode.leftExpression);

        if (node->data.conditionNode.rightExpression != NULL && !null_condtition)
        {
            process_ast(node->data.conditionNode.rightExpression);
            gen_stack_operation(node->data.conditionNode.operator);
            // printf("], Operator: %s, Right: [\n", ast_operator_type_to_string(node->data.conditionNode.operator));
            // printf("])\n");
        }
        else if (node->data.conditionNode.rightExpression != NULL && null_condtition)
        {
            exit(7);
        }
        else if (node->data.conditionNode.rightExpression == NULL && !null_condtition)
        {
            exit(7);
        }
        // gen_if_jump_logic();
        break;

    case NODE_VARIABLE_INITIALIZATION:
        // hotovo
        // printf(" (Name: %s, Type: %s)\n", node->data.varDecl.id, ast_data_type_to_string(node->data.varDecl.type));
        // Print the initialization expression
        process_ast(node->data.varDecl.expression);

        gen_local_var_init(node->data.varDecl.id); // pops ze stacku

        break;

    case NODE_FACTOR:

        // hotovo
        // printf(" (Factor Type: %s, ", ast_data_type_to_string(node->data.factorNode.factorType));
        if (node->data.factorNode.id != NULL)
        {
            gen_pushs_prom(node->data.factorNode.id);
        }
        else
        {
            gen_pushs_const(node->data.factorNode);
        }
        break;

    default:
        break;
    }
    Node *child = node->children;
    while (child)
    {
        process_ast(child);
        child = child->sibling;
    }
    switch (node->type)
    {

    case NODE_IF_BODY:

        gen_if_end(node->data.ifBody.cnt);
        scopeStackLocal = popScope(scopeStackLocal);
        break;

    case NODE_ELSE_BODY:
        gen_if_else_end(node->data.elseBody.cnt);
        scopeStackLocal = popScope(scopeStackLocal);
        break;
    case NODE_WHILE:
        gen_while_end(node->data.whileNode.cnt);
        scopeStackLocal = popScope(scopeStackLocal);
        break;
    case NODE_FUNCTION:
        scopeStackLocal = popScope(scopeStackLocal);
        gen_function_end(node->data.function);
        break;
    }
}
