#ifndef SEMANTIC_H
#define SEMANTIC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symtable.h"

typedef struct
{
    Symbol *current_function;
} Semantic;

#endif // SEMANTIC_H