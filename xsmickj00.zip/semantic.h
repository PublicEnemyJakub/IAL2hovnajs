// Autor: Lukáš Gronich - xgronil00
#ifndef SEMANTIC_H
#define SEMANTIC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symtable.h"

typedef struct
{
    Symbol *current_function; // Ukazatel na aktuální funkci
} Semantic;

extern Semantic semantic;

void initializeSemantic();                      // Funkce pro nastavení počáteční hodnoty aktuální funkce na null
void checkUnusedSymbols(ScopeNode *scope);      // Funkce pro zjištění, jestli byli všechny symboly ve scopu použity
void checkUnusedSymbolsInTree(AVLNode *node);   // Funkce pro zjištění, jestlu byli všechny symboly v tablce symbolů využity
void checkReturn();                             // Funkce pro zjištění returnu funkce
void checkParamsTypes(int numArgs, Node *args); // Funkce pro zjištění správnosti parametrů, při volání funkce

#endif // SEMANTIC_H