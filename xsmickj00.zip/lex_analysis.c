/*
Lexikalni analyzator
Autor: Jakub Smička (xsmickj00)
*/

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>
#include "lex_analysis.h"
#include <math.h>

// Funkce pro chybu v lexikalni analyze
void lexError()
{
    fprintf(stderr, "Chybna struktura lexemu!\n");
    exit(1);
}

/*
 *Funkce pro získání tokenu,
 * Funkce vrací alokovaný token, pokud správně proběhne alokace
 * a do Tokenu je nahráno vše potřebné podle typu.
 * Funkce postupně načítá jednotlivé znaky dokud nerozpozná jakýkoliv typ Tokenu
 * podle switch algoritmu.
 */
Token *getToken()
{
    int c;                            // Aktuální znak
    char next_char;                   // Pomocný znak
    bool token_found = false;         // Bool pro ukončení loopu, pokud se našel token
    Token *t = malloc(sizeof(Token)); // Alokace tokenu
    if (t == NULL)
    { // Kontrola alokace
        fprintf(stderr, "Chyba alokace tokenu");
        exit(99);
    }

    while (!token_found && (c = fgetc(stdin)) != EOF)
    { // Loop pro hledání tokenu
        while (isspace(c))
        {
            c = fgetc(stdin); // Bílé znaky ignorujeme
        }

        switch (c)
        {
        case '+':
        {
            token_found = true;
            t->type = TOKEN_PLUS;
        }
        break;

        case '-':
        {
            token_found = true;
            t->type = TOKEN_MINUS;
        }
        break;

        case '*':
        {
            token_found = true;
            t->type = TOKEN_STAR;
        }
        break;

        case '=':
        {
            next_char = fgetc(stdin); // Přečteme následující znak

            if (next_char == '=')
            { // Jedná se o ==
                t->type = TOKEN_DOUBLE_EQUAL;
            }
            else
            {
                t->type = TOKEN_EQUAL;
                ungetc(next_char, stdin); // Nejednalo se o ==, pomocný znak vrátíme zpět na další zpracování
            }
            token_found = true;
            break;
        }

        case '!':
            next_char = fgetc(stdin); // Přečteme následující znak

            if (next_char == '=')
            {
                t->type = TOKEN_NOT_EQUAL;
            }
            else
            {
                t->type = TOKEN_NOT;      // Neni treba, max u BOOLTHEN rozsireni, tak tu nechavam
                ungetc(next_char, stdin); // Analogie u ==
            }
            token_found = true;
            break;

        case '<':
            next_char = fgetc(stdin); // Přečteme následující znak

            if (next_char == '=')
            {
                t->type = TOKEN_LESS_EQUAL;
            }
            else
            {
                t->type = TOKEN_LESS;
                ungetc(next_char, stdin); // Analogie u ==
            }
            token_found = true;
            break;

        case '/':
            next_char = fgetc(stdin); // Přečteme následující znak

            if (next_char == '/')
            {
                while (c != '\n')
                {
                    c = fgetc(stdin); // Ignorujeme znaky do konce radku
                }
                continue;
            }
            else
            {
                token_found = true;
                t->type = TOKEN_SLASH;
                ungetc(next_char, stdin); // Zapomenel jsem vratit na druhem odevzdani
            }
            break;

        case '>':
            next_char = fgetc(stdin); // Přečteme následující znak

            if (next_char == '=')
            {
                t->type = TOKEN_GREATER_EQUAL;
            }
            else
            {
                t->type = TOKEN_GREATER;
                ungetc(next_char, stdin); // Analogie u ==
            }
            token_found = true;
            break;

        case '(':
        {
            t->type = TOKEN_LEFT_PAREN;
        }
            token_found = true;
            break;

        case ')':
        {
            t->type = TOKEN_RIGHT_PAREN;
        }
            token_found = true;
            break;

        case '{':
        {
            t->type = TOKEN_LEFT_BRACE;
        }
            token_found = true;
            break;

        case '}':
        {
            t->type = TOKEN_RIGHT_BRACE;
        }
            token_found = true;
            break;

        case '[':
        {
            t->type = TOKEN_LEFT_BRACKET;
        }
            token_found = true;
            break;

        case ']':
        {
            t->type = TOKEN_RIGHT_BRACKET;
        }
            token_found = true;
            break;

        case ';':
        {
            t->type = TOKEN_SEMICOLON;
        }
            token_found = true;
            break;

        case ':':
        {
            t->type = TOKEN_DOUBLE_DOT;
        }
            token_found = true;
            break;

        case '.':
        {
            t->type = TOKEN_DOT;
        }
            token_found = true;
            break;

        case ',':
        {
            t->type = TOKEN_COMMA;
        }
            token_found = true;
            break;
        case '?':
        {
            t->type = TOKEN_QMARK;
        }
            token_found = true;
            break;
        case '|':
        {
            t->type = TOKEN_VERTICAL_BAR;
        }
            token_found = true;
            break;
        case '"':
        {
            size_t size = 256;                          // Počáteční velikost
            char *string = malloc(size * sizeof(char)); // Alokace paměti pro dynamický řetězec
            if (string == NULL)
            {
                fprintf(stderr, "Chyba pri alokaci pameti pro retezec.\n");
                exit(99);
            }

            int index = 0;
            c = fgetc(stdin);
            do
            {
                if (c == '"')
                {
                    break; // Prazdny retezec
                }
                if (c == '\n')
                {
                    fprintf(stderr, "Retezec by nemel obsahovat odradkovani!\n");
                    lexError();
                }
                if (c == EOF)
                {
                    fprintf(stderr, "Ukoncen vstup uprostred retezce!\n");
                    lexError();
                }
                if (c == '\\')
                {
                    c = fgetc(stdin);
                    switch (c) // Escape sekvence
                    {
                    case '"':
                        c = '"';
                        break;
                    case 'n':
                        c = '\n';
                        break;
                    case 'r':
                        c = '\r';
                        break;
                    case 't':
                        c = '\t';
                        break;
                    case '\\':
                        c = '\\';
                        break;
                    case 'x':
                    {
                        // hexadec. sekvence
                        char hex[3] = {fgetc(stdin), fgetc(stdin), '\0'};
                        if (!isxdigit(hex[0]) || !isxdigit(hex[1]))
                        {
                            fprintf(stderr, "Neplatna escape sekvence \\xXX!\n");
                            lexError();
                        }
                        c = (char)strtol(hex, NULL, 16);
                        break;
                    }
                    case '\n': // Víceřádkový řetězec
                        while (isspace(c = fgetc(stdin)))
                        {
                            // Ignorace bilych radku
                        }
                        if (c != '\\' || (c = fgetc(stdin)) != '\\')
                        {
                            fprintf(stderr, "Spatne pokracovani viceradkoveho retezce!\n");
                            lexError();
                        }
                        c = '\n'; // Zahrň nový řádek
                        break;
                    default:
                        fprintf(stderr, "Neplatna escape sekvence\n");
                        lexError();
                    }
                }
                if (index >= (int)size - 1)
                {
                    size *= 2; // Rozšíříme string
                    string = realloc(string, size * sizeof(char));
                    if (string == NULL)
                    {
                        fprintf(stderr, "Chyba pri realokaci pameti pro retezec.\n");
                        exit(99);
                    }
                }
                string[index++] = c; // Přidání znaku do identifikátoru
                c = fgetc(stdin);

            } while (c != '"');
            string[index] = '\0'; // Ukončení řetězce
            t->type = TOKEN_STRING;
            t->value = string;
        }
            token_found = true;
            break;

        case '\\': // Začátek víceřádkového řetězce
        {
            if (fgetc(stdin) != '\\')
            {
                lexError();
            }
            size_t size = 256;                          // Počáteční velikost
            char *string = malloc(size * sizeof(char)); // Alokace paměti pro dynamický řetězec
            if (string == NULL)
            {
                fprintf(stderr, "Chyba pri alokaci pameti pro retezec.\n");
                exit(99);
            }
            int index = 0;
            c = fgetc(stdin);
            bool end_of_line = false;
            bool end_of_string = false;
            do
            {
                if (end_of_line)
                {
                    while (isspace(c))
                    {
                        c = fgetc(stdin);
                    }
                    if (c == '\\')
                    {
                        c = fgetc(stdin);
                        if (c == '\\')
                        {
                            string[index++] = '\n'; // Přidání odradkovani
                            c = fgetc(stdin);
                            end_of_line = false;
                            continue;
                        }
                        else
                        {
                            lexError();
                        }
                    }
                    else
                    {
                        ungetc(c, stdin);
                        end_of_string = true;
                        continue;
                    }
                }
                if (c == '\n')
                { // Narazili jsme na odradkovani, to nepridavame a jdeme dal
                    end_of_line = true;
                    continue;
                }
                if (index >= (int)size - 1)
                {
                    size *= 2; // Rozšíříme string
                    string = realloc(string, size * sizeof(char));
                    if (string == NULL)
                    {
                        fprintf(stderr, "Chyba pri realokaci pameti pro retezec.\n");
                        exit(99);
                    }
                }
                string[index++] = c; // Přidání znaku do identifikátoru
                c = fgetc(stdin);
            } while (!end_of_string);
            string[index] = '\0'; // Ukončení řetězce
            t->type = TOKEN_STRING;
            t->value = string;
        }
            token_found = true;
            break;
        case '@':
        {
            char string[256];
            int index = 0;
            do
            {
                string[index++] = c; // Přidání znaku do identifikátoru
                c = fgetc(stdin);
            } while (isalpha(c));
            string[index] = '\0'; // Ukončení řetězce
            ungetc(c, stdin);
            if (strcmp(string, "@import") == 0)
            {
                t->type = TOKEN_KEY;
                t->key_value = KEY_IMPORT;
            }
            else
            {
                t->type = TOKEN_AT;
                t->value = strdup(string);
            }
        }
            token_found = true;
            break;
        default:
            if (isdigit(c))
            {
                int value = c - '0'; // Inicializace čísla
                bool is_float = false;
                double float_value = 0.0;
                bool is_exponent = false;
                int exponent_value = 0;
                bool exponent_sign = false; // Ukazuje, zda je exponent s znaménkem

                // Kontrola, zda číslo nezačíná nulou (pokud není nulové)
                if (value == 0)
                {
                    c = fgetc(stdin);
                    if (isdigit(c))
                    {
                        fprintf(stderr, "Chyba: Celociselnz literal nesmí zacinat nulou!\n");
                        lexError();
                    }
                    ungetc(c, stdin); // Vrátíme zpět znak, protože není součástí čísla
                }

                // Načítání celého čísla
                while (isdigit(c = fgetc(stdin)))
                {
                    value = value * 10 + (c - '0');
                }

                // Zpracování desetinné části
                if (c == '.')
                {
                    is_float = true;
                    double value2 = 0.0;
                    int divisor = 10;
                    c = fgetc(stdin);
                    while (isdigit(c))
                    {
                        value2 += (c - '0') / (double)divisor;
                        divisor *= 10;
                        c = fgetc(stdin);
                    }
                    float_value = value2;
                }

                // Zpracování exponentu
                if (c == 'e' || c == 'E')
                {
                    is_exponent = true;
                    c = fgetc(stdin);
                    if (c == '+' || c == '-')
                    {
                        exponent_sign = (c == '-');
                        c = fgetc(stdin);
                    }

                    if (!isdigit(c))
                    {
                        fprintf(stderr, "Chyba: Po exponentu musi nasledovat cislice!\n");
                        lexError();
                    }

                    exponent_value = c - '0';
                    while (isdigit(c = fgetc(stdin)))
                    {
                        exponent_value = exponent_value * 10 + (c - '0');
                    }
                }

                // Vracíme zpět poslední přečtený znak do vstupu (c)
                ungetc(c, stdin);

                if (is_float)
                { // Pokud je to float
                    t->type = TOKEN_FLOAT;
                    // Kombinace celého a desetinného čísla
                    float_value += value; // Přičteme celé číslo
                    if (is_exponent)
                    {
                        // Použití exponentu
                        if (exponent_sign)
                        {
                            float_value /= pow(10, exponent_value); // Záporný exponent
                        }
                        else
                        {
                            float_value *= pow(10, exponent_value); // Kladný exponent
                        }
                    }
                    t->float_value = float_value;
                }
                else
                { // Jinak je to celé číslo
                    t->type = TOKEN_INTEGER;
                    t->int_value = value;
                }

                token_found = true;
            }
            else if (isalpha(c) || c == '_')
            { // Hledání identifikátorů, klíčových slov
                char identifier[256];
                int index = 0;
                do
                {
                    identifier[index++] = c; // Přidání znaku do identifikátoru
                    c = fgetc(stdin);
                } while (isalpha(c) || isdigit(c) || c == '_'); // Kontrola jesli je další znak opět písmeno/číslo/_
                identifier[index] = '\0'; // Ukončení řetězce
                ungetc(c, stdin);

                if (strcmp(identifier, "const") == 0)
                { // Porovnávání s kličovými slovami
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_CONST;
                }
                else if (strcmp(identifier, "else") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_ELSE;
                }
                else if (strcmp(identifier, "fn") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_FN;
                }
                else if (strcmp(identifier, "if") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_IF;
                }
                else if (strcmp(identifier, "i32") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_I32;
                }
                else if (strcmp(identifier, "f64") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_F64;
                }
                else if (strcmp(identifier, "null") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_NULL;
                }
                else if (strcmp(identifier, "pub") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_PUB;
                }
                else if (strcmp(identifier, "return") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_RETURN;
                }
                else if (strcmp(identifier, "u8") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_U8;
                }
                else if (strcmp(identifier, "var") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_VAR;
                }
                else if (strcmp(identifier, "void") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_VOID;
                }
                else if (strcmp(identifier, "while") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_WHILE;
                }
                else if (strcmp(identifier, "ifj") == 0)
                {
                    t->type = TOKEN_KEY;
                    t->key_value = KEY_IFJ;
                }
                else
                { // Pokud nebylo detekováno klíčové slovo, jedná se o identifikátor.
                    t->type = TOKEN_IDENTIFIER;

                    t->value = strdup(identifier);
                    if (t->value == NULL)
                    {
                        exit(99);
                    }
                }
                token_found = true;
            }
            else if (c == EOF)
            {
                t->type = TOKEN_EOF;
                token_found = true;
            }
            else
            {
                lexError();
            }
        }
    }
    if (c == EOF)
    {
        t->type = TOKEN_EOF;
        token_found = true;
    }
    if (token_found)
    {
        return t; // Vrati ukazatel na token
    }
    else
    {
        lexError();
    }
    return NULL;
}